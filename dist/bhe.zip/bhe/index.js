"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("./util");
const exceptions_1 = require("./exceptions");
const SVG_NS_URI = 'http://www.w3.org/2000/svg';
class BetterHTMLElement {
    constructor(elemOptions) {
        this._isSvg = false;
        this._listeners = {};
        this._cachedChildren = {};
        let { tag, cls, setid, html, htmlElement, byid, query, children } = elemOptions;
        if ([tag, byid, query, htmlElement].filter(x => x !== undefined).length > 1) {
            throw new exceptions_1.MutuallyExclusiveArgs({
                byid, query, htmlElement, tag
            }, 'Either wrap an existing element by passing one of `byid` / `query` / `htmlElement`, or create a new one by passing `tag`.');
        }
        if (util_1.anyDefined([tag, cls, setid]) && util_1.anyDefined([children, byid, htmlElement, query])) {
            throw new exceptions_1.MutuallyExclusiveArgs([
                { tag, cls, setid },
                { children, byid, htmlElement, query }
            ], `Can't have args from both sets`);
        }
        if (util_1.allUndefined([tag, byid, htmlElement, query])) {
            throw new exceptions_1.NotEnoughArgs(1, { tag, byid, htmlElement, query }, 'either');
        }
        if (tag !== undefined) {
            if (['svg', 'path'].includes(tag.toLowerCase())) {
                this._isSvg = true;
                this._htmlElement = document.createElementNS(SVG_NS_URI, tag);
            }
            else {
                this._htmlElement = document.createElement(tag);
            }
        }
        else {
            if (byid !== undefined) {
                if (byid.startsWith('#')) {
                    console.warn(`param 'byid' starts with '#', stripping it: ${byid}`);
                    byid = byid.substr(1);
                }
                this._htmlElement = document.getElementById(byid);
            }
            else {
                if (query !== undefined) {
                    this._htmlElement = document.querySelector(query);
                }
                else {
                    if (htmlElement !== undefined) {
                        this._htmlElement = htmlElement;
                    }
                }
            }
        }
        if (!util_1.bool(this._htmlElement)) {
            throw new Error(`${this} constructor ended up with no 'this._htmlElement'. Passed options: ${exceptions_1.summary(elemOptions)}`);
        }
        if (cls !== undefined) {
            this.class(cls);
        }
        if (html !== undefined) {
            this.html(html);
        }
        if (children !== undefined) {
            this.cacheChildren(children);
        }
        if (setid !== undefined) {
            this.id(setid);
        }
    }
    get e() {
        return this._htmlElement;
    }
    static wrapWithBHE(element) {
        const tag = element.tagName.toLowerCase();
        if (tag === 'div') {
            return div({ htmlElement: element });
        }
        else if (tag === 'a') {
            return anchor({ htmlElement: element });
        }
        else if (tag === 'p') {
            return paragraph({ htmlElement: element });
        }
        else if (tag === 'img') {
            return img({ htmlElement: element });
        }
        else if (tag === 'input') {
            if (element.type === "text") {
                return new TextInput({ htmlElement: element });
            }
            else if (element.type === "checkbox") {
                return new CheckboxInput({ htmlElement: element });
            }
            else {
                return input({ htmlElement: element });
            }
        }
        else if (tag === 'button') {
            return button({ htmlElement: element });
        }
        else if (tag === 'span') {
            return span({ htmlElement: element });
        }
        else if (tag === 'select') {
            return select({ htmlElement: element });
        }
        else {
            return elem({ htmlElement: element });
        }
    }
    toString() {
        var _a, _b;
        const proto = Object.getPrototypeOf(this);
        const protoStr = proto.constructor.toString();
        let str = protoStr.substring(6, protoStr.indexOf('{') - 1);
        let tag = (_a = this._htmlElement) === null || _a === void 0 ? void 0 : _a.tagName;
        let id = this.id();
        let classList = (_b = this._htmlElement) === null || _b === void 0 ? void 0 : _b.classList;
        if (util_1.anyTruthy([id, classList, tag])) {
            str += ` (`;
            if (tag) {
                str += `<${tag.toLowerCase()}>`;
            }
            if (id) {
                str += `#${id}`;
            }
            if (classList) {
                str += `.${classList}`;
            }
            str += `)`;
        }
        return str;
    }
    wrapSomethingElse(newHtmlElement) {
        this._cachedChildren = {};
        if (newHtmlElement instanceof BetterHTMLElement) {
            this._htmlElement.replaceWith(newHtmlElement.e);
            this._htmlElement = newHtmlElement.e;
            for (let [_key, _cachedChild] of util_1.enumerate(newHtmlElement._cachedChildren)) {
                this._cache(_key, _cachedChild);
            }
            if (Object.keys(this._cachedChildren).length
                !== Object.keys(newHtmlElement._cachedChildren).length
                ||
                    Object.values(this._cachedChildren).filter(v => v !== undefined).length
                        !== Object.values(newHtmlElement._cachedChildren).filter(v => v !== undefined).length) {
                console.warn(`wrapSomethingElse this._cachedChildren length !== newHtmlElement._cachedChildren.length`, {
                    this: this,
                    newHtmlElement
                });
            }
            this.on(Object.assign(Object.assign({}, this._listeners), newHtmlElement._listeners));
        }
        else {
            this.on(this._listeners);
            this._htmlElement.replaceWith(newHtmlElement);
            this._htmlElement = newHtmlElement;
        }
        return this;
    }
    html(html) {
        if (html === undefined) {
            return this._htmlElement.innerHTML;
        }
        else {
            this._htmlElement.innerHTML = html;
            return this;
        }
    }
    text(txt) {
        if (txt === undefined) {
            return this._htmlElement.innerText;
        }
        else {
            this._htmlElement.innerText = txt;
            return this;
        }
    }
    id(id) {
        var _a;
        if (id === undefined) {
            return (_a = this._htmlElement) === null || _a === void 0 ? void 0 : _a.id;
        }
        else {
            this._htmlElement.id = id;
            return this;
        }
    }
    css(css) {
        if (typeof css === 'string') {
            return this._htmlElement.style[css];
        }
        else {
            for (let [styleAttr, styleVal] of util_1.enumerate(css)) {
                this._htmlElement.style[styleAttr] = styleVal;
            }
            return this;
        }
    }
    uncss(...removeProps) {
        let css = {};
        for (let prop of removeProps) {
            css[prop] = '';
        }
        return this.css(css);
    }
    class(cls) {
        if (cls === undefined) {
            return Array.from(this._htmlElement.classList);
        }
        else if (util_1.isFunction(cls)) {
            return Array.from(this._htmlElement.classList).find(cls);
        }
        else {
            if (this._isSvg) {
                this._htmlElement.classList = [cls];
            }
            else {
                this._htmlElement.className = cls;
            }
            return this;
        }
    }
    addClass(cls, ...clses) {
        this._htmlElement.classList.add(cls);
        for (let c of clses) {
            this._htmlElement.classList.add(c);
        }
        return this;
    }
    removeClass(cls, ...clses) {
        if (util_1.isFunction(cls)) {
            this._htmlElement.classList.remove(this.class(cls));
            for (let c of clses) {
                this._htmlElement.classList.remove(this.class(c));
            }
        }
        else {
            this._htmlElement.classList.remove(cls);
            for (let c of clses) {
                this._htmlElement.classList.remove(c);
            }
        }
        return this;
    }
    replaceClass(oldToken, newToken) {
        if (util_1.isFunction(oldToken)) {
            this._htmlElement.classList.replace(this.class(oldToken), newToken);
        }
        else {
            this._htmlElement.classList.replace(oldToken, newToken);
        }
        return this;
    }
    toggleClass(cls, force) {
        if (util_1.isFunction(cls)) {
            this._htmlElement.classList.toggle(this.class(cls), force);
        }
        else {
            this._htmlElement.classList.toggle(cls, force);
        }
        return this;
    }
    hasClass(cls) {
        if (util_1.isFunction(cls)) {
            return this.class(cls) !== undefined;
        }
        else {
            return this._htmlElement.classList.contains(cls);
        }
    }
    after(...nodes) {
        for (let node of nodes) {
            if (node instanceof BetterHTMLElement) {
                this._htmlElement.after(node.e);
            }
            else {
                this._htmlElement.after(node);
            }
        }
        return this;
    }
    insertAfter(node) {
        if (node instanceof BetterHTMLElement) {
            node._htmlElement.after(this._htmlElement);
        }
        else {
            node.after(this._htmlElement);
        }
        return this;
    }
    append(...nodes) {
        for (let node of nodes) {
            if (node instanceof BetterHTMLElement) {
                this._htmlElement.append(node.e);
            }
            else {
                if (node instanceof Node) {
                    this._htmlElement.append(node);
                }
                else {
                    if (Array.isArray(node)) {
                        this.cacheAppend([node]);
                    }
                    else {
                        this.cacheAppend(node);
                    }
                }
            }
        }
        return this;
    }
    appendTo(node) {
        if (node instanceof BetterHTMLElement) {
            node._htmlElement.append(this._htmlElement);
        }
        else {
            node.append(this._htmlElement);
        }
        return this;
    }
    before(...nodes) {
        for (let node of nodes) {
            if (node instanceof BetterHTMLElement) {
                this._htmlElement.before(node.e);
            }
            else {
                this._htmlElement.before(node);
            }
        }
        return this;
    }
    insertBefore(node) {
        if (node instanceof BetterHTMLElement) {
            node._htmlElement.before(this._htmlElement);
        }
        else {
            node.before(this._htmlElement);
        }
        return this;
    }
    replaceChild(newChild, oldChild) {
        this._htmlElement.replaceChild(newChild, oldChild);
        return this;
    }
    cacheAppend(keyChildPairs) {
        const _cacheAppend = (_key, _child) => {
            this.append(_child);
            this._cache(_key, _child);
        };
        if (Array.isArray(keyChildPairs)) {
            for (let [key, child] of keyChildPairs) {
                _cacheAppend(key, child);
            }
        }
        else {
            for (let [key, child] of util_1.enumerate(keyChildPairs)) {
                _cacheAppend(key, child);
            }
        }
        return this;
    }
    _cls() {
        return BetterHTMLElement;
    }
    child(selector, bheCls) {
        const htmlElement = this._htmlElement.querySelector(selector);
        if (htmlElement === null) {
            console.warn(`${this}.child(${selector}): no child. returning undefined`);
            return undefined;
        }
        let bhe;
        if (bheCls === undefined) {
            bhe = this._cls().wrapWithBHE(htmlElement);
        }
        else {
            bhe = new bheCls({ htmlElement });
        }
        return bhe;
    }
    children(selector) {
        let childrenVanilla;
        let childrenCollection;
        if (selector === undefined) {
            childrenCollection = this._htmlElement.children;
        }
        else {
            childrenCollection = this._htmlElement.querySelectorAll(selector);
        }
        childrenVanilla = Array.from(childrenCollection);
        return childrenVanilla.map(this._cls().wrapWithBHE);
    }
    clone(deep) {
        console.warn(`${this}.clone() doesnt return a matching BHE subtype, but a regular BHE`);
        return new BetterHTMLElement({ htmlElement: this._htmlElement.cloneNode(deep) });
    }
    cacheChildren(childrenObj) {
        for (let [key, value] of util_1.enumerate(childrenObj)) {
            let type = typeof value;
            if (util_1.isObject(value)) {
                if (value instanceof BetterHTMLElement) {
                    this._cache(key, value);
                }
                else {
                    let entries = Object.entries(value);
                    if (entries[1] !== undefined) {
                        console.warn(`cacheChildren() received recursive obj with more than 1 selector for a key. Using only 0th selector`, {
                            key,
                            "multiple selectors": entries.map(e => e[0]),
                            value,
                            this: this
                        });
                    }
                    let [selector, obj] = entries[0];
                    if (util_1.isFunction(obj)) {
                        let bhe = this.child(selector, obj);
                        this._cache(key, bhe);
                    }
                    else {
                        this._cache(key, this.child(selector));
                        this[key].cacheChildren(obj);
                    }
                }
            }
            else if (type === "string") {
                let match = /<(\w+)>$/.exec(value);
                if (match) {
                    let tagName = match[1];
                    const htmlElements = [...this._htmlElement.getElementsByTagName(tagName)];
                    let bhes = [];
                    for (let htmlElement of htmlElements) {
                        bhes.push(this._cls().wrapWithBHE(htmlElement));
                    }
                    this._cache(key, bhes);
                }
                else {
                    this._cache(key, this.child(value));
                }
            }
            else {
                console.warn(`cacheChildren, bad value type: "${type}". key: "${key}", value: "${value}". childrenObj:`, childrenObj);
            }
        }
        return this;
    }
    empty() {
        while (this._htmlElement.firstChild) {
            this._htmlElement.removeChild(this._htmlElement.firstChild);
        }
        return this;
    }
    remove() {
        this._htmlElement.remove();
        return this;
    }
    on(evTypeFnPairs, options) {
        for (let [evType, evFn] of util_1.enumerate(evTypeFnPairs)) {
            const _f = function _f(evt) {
                evFn(evt);
            };
            this._htmlElement.addEventListener(evType, _f, options);
            this._listeners[evType] = _f;
        }
        return this;
    }
    touchstart(fn, options) {
        this._htmlElement.addEventListener('touchstart', function _f(ev) {
            ev.preventDefault();
            fn(ev);
            if (options && options.once) {
                this.removeEventListener('touchstart', _f);
            }
        }, options);
        return this;
    }
    pointerdown(fn, options) {
        let action;
        try {
            action = window.PointerEvent ? 'pointerdown' : 'mousedown';
        }
        catch (e) {
            action = 'mousedown';
        }
        const _f = function _f(ev) {
            ev.preventDefault();
            fn(ev);
            if (options && options.once) {
                this.removeEventListener(action, _f);
            }
        };
        this._htmlElement.addEventListener(action, _f, options);
        this._listeners.pointerdown = _f;
        return this;
    }
    click(fn, options) {
        if (fn === undefined) {
            this._htmlElement.click();
            return this;
        }
        else {
            return this.on({ click: fn }, options);
        }
    }
    blur(fn, options) {
        if (fn === undefined) {
            this._htmlElement.blur();
            return this;
        }
        else {
            return this.on({ blur: fn }, options);
        }
    }
    focus(fn, options) {
        if (fn === undefined) {
            this._htmlElement.focus();
            return this;
        }
        else {
            return this.on({ focus: fn }, options);
        }
    }
    change(fn, options) {
        return this.on({ change: fn }, options);
    }
    contextmenu(fn, options) {
        return this.on({ contextmenu: fn }, options);
    }
    dblclick(fn, options) {
        if (fn === undefined) {
            const dblclick = new MouseEvent('dblclick', {
                'view': window,
                'bubbles': true,
                'cancelable': true
            });
            this._htmlElement.dispatchEvent(dblclick);
            return this;
        }
        else {
            return this.on({ dblclick: fn }, options);
        }
    }
    mouseenter(fn, options) {
        if (fn === undefined) {
            const mouseenter = new MouseEvent('mouseenter', {
                'view': window,
                'bubbles': true,
                'cancelable': true
            });
            this._htmlElement.dispatchEvent(mouseenter);
            return this;
        }
        else {
            return this.on({ mouseenter: fn }, options);
        }
    }
    keydown(fn, options) {
        return this.on({ keydown: fn }, options);
    }
    mouseout(fn, options) {
        return this.on({ mouseout: fn }, options);
    }
    mouseover(fn, options) {
        return this.on({ mouseover: fn });
    }
    off(event) {
        this._htmlElement.removeEventListener(event, this._listeners[event]);
        return this;
    }
    allOff() {
        for (let i = 0; i < Object.keys(this._listeners).length; i++) {
            let event = this._listeners[i];
            this.off(event);
        }
        return this;
    }
    attr(attrValPairs) {
        if (typeof attrValPairs === 'string') {
            return this._htmlElement.getAttribute(attrValPairs);
        }
        else {
            for (let [attr, val] of util_1.enumerate(attrValPairs)) {
                this._htmlElement.setAttribute(attr, val);
            }
            return this;
        }
    }
    removeAttr(qualifiedName, ...qualifiedNames) {
        let _removeAttribute;
        if (this._isSvg) {
            _removeAttribute = (qualifiedName) => this._htmlElement.removeAttributeNS(SVG_NS_URI, qualifiedName);
        }
        else {
            _removeAttribute = (qualifiedName) => this._htmlElement.removeAttribute(qualifiedName);
        }
        _removeAttribute(qualifiedName);
        for (let qn of qualifiedNames) {
            _removeAttribute(qn);
        }
        return this;
    }
    getdata(key, parse = true) {
        const data = this._htmlElement.getAttribute(`data-${key}`);
        if (parse === true) {
            return JSON.parse(data);
        }
        else {
            return data;
        }
    }
    _cache(key, child) {
        const oldchild = this._cachedChildren[key];
        if (oldchild !== undefined) {
            console.warn(`Overwriting this._cachedChildren[${key}]!`, `old child: ${oldchild}`, `new child: ${child}`, `are they different?: ${oldchild == child}`);
        }
        this[key] = child;
        this._cachedChildren[key] = child;
    }
}
exports.BetterHTMLElement = BetterHTMLElement;
class Div extends BetterHTMLElement {
    constructor(divOpts) {
        const { setid, cls, text, html, byid, query, htmlElement, children } = divOpts;
        if (text !== undefined && html !== undefined) {
            throw new exceptions_1.MutuallyExclusiveArgs({ text, html });
        }
        if (htmlElement !== undefined) {
            super({ htmlElement, children });
        }
        else if (byid !== undefined) {
            super({ byid, children });
        }
        else if (query !== undefined) {
            super({ query, children });
        }
        else {
            super({ tag: "div", setid, cls, html });
            if (text !== undefined) {
                this.text(text);
            }
        }
    }
}
exports.Div = Div;
class Paragraph extends BetterHTMLElement {
    constructor(pOpts) {
        const { setid, cls, text, html, byid, query, htmlElement, children } = pOpts;
        if (text !== undefined && html !== undefined) {
            throw new exceptions_1.MutuallyExclusiveArgs({ text, html });
        }
        if (htmlElement !== undefined) {
            super({ htmlElement, children });
        }
        else if (byid !== undefined) {
            super({ byid, children });
        }
        else if (query !== undefined) {
            super({ query, children });
        }
        else {
            super({ tag: "p", setid, cls, html });
            if (text !== undefined) {
                this.text(text);
            }
        }
    }
}
exports.Paragraph = Paragraph;
class Span extends BetterHTMLElement {
    constructor(spanOpts) {
        const { setid, cls, text, html, byid, query, htmlElement, children } = spanOpts;
        if (text !== undefined && html !== undefined) {
            throw new exceptions_1.MutuallyExclusiveArgs({ text, html });
        }
        if (htmlElement !== undefined) {
            super({ htmlElement, children });
        }
        else if (byid !== undefined) {
            super({ byid, children });
        }
        else if (query !== undefined) {
            super({ query, children });
        }
        else {
            super({ tag: "span", setid, cls, html });
            if (text !== undefined) {
                this.text(text);
            }
        }
    }
}
exports.Span = Span;
class Img extends BetterHTMLElement {
    constructor(imgOpts) {
        const { cls, setid, src, byid, query, htmlElement, children } = imgOpts;
        if (htmlElement !== undefined) {
            super({ htmlElement, children });
        }
        else if (byid !== undefined) {
            super({ byid, children });
        }
        else if (query !== undefined) {
            super({ query, children });
        }
        else {
            super({ tag: "img", setid, cls });
            if (src !== undefined) {
                this.src(src);
            }
        }
    }
    src(src) {
        if (src === undefined) {
            return this._htmlElement.src;
        }
        else {
            this._htmlElement.src = src;
            return this;
        }
    }
}
exports.Img = Img;
class Anchor extends BetterHTMLElement {
    constructor({ setid, cls, text, html, href, target, byid, query, htmlElement, children }) {
        if (text !== undefined && html !== undefined) {
            throw new exceptions_1.MutuallyExclusiveArgs({ text, html });
        }
        if (htmlElement !== undefined) {
            super({ htmlElement, children });
        }
        else if (byid !== undefined) {
            super({ byid, children });
        }
        else if (query !== undefined) {
            super({ query, children });
        }
        else {
            super({ tag: "a", setid, cls, html });
            if (text !== undefined) {
                this.text(text);
            }
            if (href !== undefined) {
                this.href(href);
            }
            if (target !== undefined) {
                this.target(target);
            }
        }
    }
    href(val) {
        if (val === undefined) {
            return this.attr('href');
        }
        else {
            return this.attr({ href: val });
        }
    }
    target(val) {
        if (val === undefined) {
            return this.attr('target');
        }
        else {
            return this.attr({ target: val });
        }
    }
}
exports.Anchor = Anchor;
class Form extends BetterHTMLElement {
    get disabled() {
        return this._htmlElement.disabled;
    }
    disable() {
        this._htmlElement.disabled = true;
        return this;
    }
    enable() {
        this._htmlElement.disabled = false;
        return this;
    }
    toggleEnabled(on) {
        if (util_1.isObject(on)) {
            this._softErr(new exceptions_1.BHETypeError({ faultyValue: { on }, expected: "primitive", where: "toggleEnabled()" }));
            return this;
        }
        if (util_1.bool(on)) {
            return this.enable();
        }
        else {
            return this.disable();
        }
    }
    value(val) {
        var _a;
        if (val === undefined) {
            return _a = this._htmlElement.value, (_a !== null && _a !== void 0 ? _a : undefined);
        }
        else {
            if (util_1.isObject(val)) {
                this._softErr(new exceptions_1.BHETypeError({ faultyValue: { val }, expected: "primitive", where: "value()" }));
                return this;
            }
            this._htmlElement.value = val;
            return this;
        }
    }
    async flashBad() {
        this.addClass('bad');
        await util_1.wait(2000);
        this.removeClass('bad');
    }
    async flashGood() {
        this.addClass('good');
        await util_1.wait(2000);
        this.removeClass('good');
    }
    clear() {
        return this.value(null);
    }
    _beforeEvent(thisArg) {
        let self = this === undefined ? thisArg : this;
        return self.disable();
    }
    _onEventSuccess(ret, thisArg) {
        let self = this === undefined ? thisArg : this;
        if (self.flashGood) {
            self.flashGood();
        }
        return self;
    }
    async _softErr(e, thisArg) {
        console.error(`${e.name}:\n${e.message}`);
        let self = this === undefined ? thisArg : this;
        if (self.flashBad) {
            await self.flashBad();
        }
        return self;
    }
    async _softWarn(e, thisArg) {
        console.warn(`${e.name}:\n${e.message}`);
        let self = this === undefined ? thisArg : this;
        if (self.flashBad) {
            await self.flashBad();
        }
        return self;
    }
    _afterEvent(thisArg) {
        let self = this === undefined ? thisArg : this;
        return self.enable();
    }
    async _wrapFnInEventHooks(asyncFn, event) {
        try {
            this._beforeEvent();
            const ret = await asyncFn(event);
            await this._onEventSuccess(ret);
        }
        catch (e) {
            await this._softErr(e);
        }
        finally {
            this._afterEvent();
        }
    }
}
exports.Form = Form;
class Button extends Form {
    constructor(buttonOpts) {
        const { setid, cls, text, html, byid, query, htmlElement, children, click } = buttonOpts;
        if (text !== undefined && html !== undefined) {
            throw new exceptions_1.MutuallyExclusiveArgs({ text, html });
        }
        if (htmlElement !== undefined) {
            super({ htmlElement, children });
        }
        else if (byid !== undefined) {
            super({ byid, children });
        }
        else if (query !== undefined) {
            super({ query, children });
        }
        else {
            super({ tag: "button", setid, cls, html });
            if (text !== undefined) {
                this.text(text);
            }
            if (click !== undefined) {
                this.click(click);
            }
        }
    }
    click(_fn) {
        if (_fn !== undefined) {
            const fn = async (event) => {
                await this._wrapFnInEventHooks(_fn, event);
            };
            return super.click(fn);
        }
        return super.click();
    }
}
exports.Button = Button;
class Input extends Form {
    constructor(inputOpts) {
        const { setid, cls, type, byid, query, htmlElement, children } = inputOpts;
        if (htmlElement !== undefined) {
            super({ htmlElement, children });
        }
        else if (byid !== undefined) {
            super({ byid, children });
        }
        else if (query !== undefined) {
            super({ query, children });
        }
        else {
            super({ tag: "input", cls, setid });
            if (type !== undefined) {
                this._htmlElement.type = type;
            }
        }
    }
}
exports.Input = Input;
class TextInput extends Input {
    constructor(opts) {
        opts.type = 'text';
        super(opts);
        const { placeholder } = opts;
        if (placeholder !== undefined) {
            this.placeholder(placeholder);
        }
    }
    placeholder(val) {
        if (val === undefined) {
            return this._htmlElement.placeholder;
        }
        else {
            this._htmlElement.placeholder = val;
            return this;
        }
    }
    keydown(_fn) {
        const fn = async (event) => {
            if (event.key !== 'Enter') {
                return;
            }
            let val = this.value();
            if (!util_1.bool(val)) {
                this._softWarn(new exceptions_1.ValueError({ faultyValue: { val }, expected: "truthy", where: "keydown()" }));
                return;
            }
            await this._wrapFnInEventHooks(_fn, event);
        };
        return super.keydown(fn);
    }
}
exports.TextInput = TextInput;
class Changable extends Input {
    change(_fn) {
        const fn = async (event) => {
            await this._wrapFnInEventHooks(_fn, event);
        };
        return super.change(fn);
    }
}
exports.Changable = Changable;
class CheckboxInput extends Changable {
    constructor(opts) {
        opts.type = 'checkbox';
        super(opts);
    }
    get checked() {
        return this._htmlElement.checked;
    }
    check() {
        this._htmlElement.checked = true;
        return this;
    }
    uncheck() {
        this._htmlElement.checked = false;
        return this;
    }
    toggleChecked(on) {
        if (util_1.isObject(on)) {
            this._softErr(new exceptions_1.BHETypeError({ faultyValue: { on }, expected: "primitive", where: "toggleChecked()" }));
            return this;
        }
        if (util_1.bool(on)) {
            return this.check();
        }
        else {
            return this.uncheck();
        }
    }
    value(val) {
        var _a;
        if (val === undefined) {
            return _a = this._htmlElement.checked, (_a !== null && _a !== void 0 ? _a : undefined);
        }
        else {
            if (util_1.isObject(val)) {
                this._softErr(new exceptions_1.BHETypeError({ faultyValue: { val }, expected: "primitive", where: "value()" }));
            }
            this._htmlElement.checked = val;
            return this;
        }
    }
    clear() {
        return this.uncheck();
    }
    async _softErr(e, thisArg) {
        this.toggleChecked(!this.checked);
        return super._softErr(e);
    }
}
exports.CheckboxInput = CheckboxInput;
class Select extends Changable {
    constructor(selectOpts) {
        super(selectOpts);
    }
    get selectedIndex() {
        return this._htmlElement.selectedIndex;
    }
    set selectedIndex(val) {
        this._htmlElement.selectedIndex = val;
    }
    get selected() {
        return this.item(this.selectedIndex);
    }
    set selected(val) {
        if (val instanceof HTMLOptionElement) {
            let index = this.options.findIndex(o => o === val);
            if (index === -1) {
                this._softWarn(new exceptions_1.ValueError({ faultyValue: { val }, where: "set selected(val)", message: `no option equals passed val` }));
            }
            this.selectedIndex = index;
        }
        else if (typeof val === 'number') {
            this.selectedIndex = val;
        }
        else {
            this.selectedIndex = this.options.findIndex(o => o.value === val);
        }
    }
    get options() {
        return [...this._htmlElement.options];
    }
    item(index) {
        return this._htmlElement.item(index);
    }
    value(val) {
        var _a;
        if (val === undefined) {
            return _a = this.selected.value, (_a !== null && _a !== void 0 ? _a : undefined);
        }
        else {
            this.selected = val;
            return this;
        }
    }
    clear() {
        this.selectedIndex = 0;
        return this;
    }
}
exports.Select = Select;
function elem(elemOptions) {
    return new BetterHTMLElement(elemOptions);
}
exports.elem = elem;
function span(spanOpts) {
    if (!util_1.bool(spanOpts)) {
        spanOpts = {};
    }
    return new Span(spanOpts);
}
exports.span = span;
function div(divOpts) {
    if (!util_1.bool(divOpts)) {
        divOpts = {};
    }
    return new Div(divOpts);
}
exports.div = div;
function button(buttonOpts) {
    if (!util_1.bool(buttonOpts)) {
        buttonOpts = {};
    }
    return new Button(buttonOpts);
}
exports.button = button;
function input(inputOpts) {
    if (!util_1.bool(inputOpts)) {
        inputOpts = {};
    }
    return new Input(inputOpts);
}
exports.input = input;
function select(selectOpts) {
    if (!util_1.bool(selectOpts)) {
        selectOpts = {};
    }
    return new Select(selectOpts);
}
exports.select = select;
function img(imgOpts) {
    if (!util_1.bool(imgOpts)) {
        imgOpts = {};
    }
    return new Img(imgOpts);
}
exports.img = img;
function paragraph(pOpts) {
    if (!util_1.bool(pOpts)) {
        pOpts = {};
    }
    return new Paragraph(pOpts);
}
exports.paragraph = paragraph;
function anchor(anchorOpts) {
    if (!util_1.bool(anchorOpts)) {
        anchorOpts = {};
    }
    return new Anchor(anchorOpts);
}
exports.anchor = anchor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGlDQUEwRztBQUUxRyw2Q0FBdUc7QUFFdkcsTUFBTSxVQUFVLEdBQUcsNEJBQTRCLENBQUM7QUFFaEQsTUFBYSxpQkFBaUI7SUFjMUIsWUFBWSxXQUFXO1FBWk4sV0FBTSxHQUFZLEtBQUssQ0FBQztRQUN4QixlQUFVLEdBQTRCLEVBQUUsQ0FBQztRQUNsRCxvQkFBZSxHQUFrRCxFQUFFLENBQUM7UUFXeEUsSUFBSSxFQUNBLEdBQUcsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLElBQUksRUFDckIsV0FBVyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUNyQyxHQUFHLFdBQVcsQ0FBQztRQUloQixJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDekUsTUFBTSxJQUFJLGtDQUFxQixDQUFDO2dCQUM1QixJQUFJLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxHQUFHO2FBQ2hDLEVBQUUsMkhBQTJILENBQUMsQ0FBQTtTQUNsSTtRQUdELElBQUksaUJBQVUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsSUFBSSxpQkFBVSxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRTtZQUNuRixNQUFNLElBQUksa0NBQXFCLENBQUM7Z0JBQzVCLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUU7Z0JBQ25CLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFO2FBQ3pDLEVBQUUsZ0NBQWdDLENBQUMsQ0FBQTtTQUN2QztRQUNELElBQUksbUJBQVksQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDL0MsTUFBTSxJQUFJLDBCQUFhLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLEVBQUUsUUFBUSxDQUFDLENBQUM7U0FDM0U7UUFJRCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUU7WUFDbkIsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUU7Z0JBQzdDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO2dCQUNuQixJQUFJLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2FBQ2pFO2lCQUFNO2dCQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQVksQ0FBQzthQUM5RDtTQUVKO2FBQU07WUFFSCxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7Z0JBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDdEIsT0FBTyxDQUFDLElBQUksQ0FBQywrQ0FBK0MsSUFBSSxFQUFFLENBQUMsQ0FBQztvQkFDcEUsSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3pCO2dCQUNELElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQVksQ0FBQzthQUNoRTtpQkFBTTtnQkFFSCxJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQVksQ0FBQztpQkFDaEU7cUJBQU07b0JBRUgsSUFBSSxXQUFXLEtBQUssU0FBUyxFQUFFO3dCQUMzQixJQUFJLENBQUMsWUFBWSxHQUFHLFdBQVcsQ0FBQztxQkFDbkM7aUJBQ0o7YUFDSjtTQUNKO1FBQ0QsSUFBSSxDQUFDLFdBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDMUIsTUFBTSxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksc0VBQXNFLG9CQUFPLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1NBQ3ZIO1FBQ0QsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQ25CLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbkI7UUFDRCxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNuQjtRQUNELElBQUksUUFBUSxLQUFLLFNBQVMsRUFBRTtZQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ2hDO1FBQ0QsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQ3JCLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDbEI7SUFHTCxDQUFDO0lBR0QsSUFBSSxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzdCLENBQUM7SUFvQkQsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPO1FBQ3RCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFpQyxDQUFDO1FBRXpFLElBQUksR0FBRyxLQUFLLEtBQUssRUFBRTtZQUNmLE9BQU8sR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7U0FDeEM7YUFBTSxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUU7WUFDcEIsT0FBTyxNQUFNLENBQUMsRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQztTQUMzQzthQUFNLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRTtZQUNwQixPQUFPLFNBQVMsQ0FBQyxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1NBQzlDO2FBQU0sSUFBSSxHQUFHLEtBQUssS0FBSyxFQUFFO1lBQ3RCLE9BQU8sR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7U0FDeEM7YUFBTSxJQUFJLEdBQUcsS0FBSyxPQUFPLEVBQUU7WUFDeEIsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtnQkFDekIsT0FBTyxJQUFJLFNBQVMsQ0FBQyxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO2FBQ2xEO2lCQUFNLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxVQUFVLEVBQUU7Z0JBQ3BDLE9BQU8sSUFBSSxhQUFhLENBQUMsRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQzthQUN0RDtpQkFBTTtnQkFDSCxPQUFPLEtBQUssQ0FBQyxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO2FBQzFDO1NBQ0o7YUFBTSxJQUFJLEdBQUcsS0FBSyxRQUFRLEVBQUU7WUFDekIsT0FBTyxNQUFNLENBQUMsRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQztTQUMzQzthQUFNLElBQUksR0FBRyxLQUFLLE1BQU0sRUFBRTtZQUN2QixPQUFPLElBQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1NBQ3pDO2FBQU0sSUFBSSxHQUFHLEtBQUssUUFBUSxFQUFFO1lBQ3pCLE9BQU8sTUFBTSxDQUFDLEVBQUUsV0FBVyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7U0FDM0M7YUFBTTtZQUNILE9BQU8sSUFBSSxDQUFDLEVBQUUsV0FBVyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7U0FDekM7SUFDTCxDQUFDO0lBRUQsUUFBUTs7UUFDSixNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzFDLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDOUMsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUUzRCxJQUFJLEdBQUcsU0FBRyxJQUFJLENBQUMsWUFBWSwwQ0FBRSxPQUFPLENBQUM7UUFDckMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQ25CLElBQUksU0FBUyxTQUFHLElBQUksQ0FBQyxZQUFZLDBDQUFFLFNBQVMsQ0FBQztRQUM3QyxJQUFJLGdCQUFTLENBQUMsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDakMsR0FBRyxJQUFJLElBQUksQ0FBQztZQUNaLElBQUksR0FBRyxFQUFFO2dCQUNMLEdBQUcsSUFBSSxJQUFJLEdBQUcsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFBO2FBQ2xDO1lBQ0QsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osR0FBRyxJQUFJLElBQUksRUFBRSxFQUFFLENBQUE7YUFDbEI7WUFDRCxJQUFJLFNBQVMsRUFBRTtnQkFDWCxHQUFHLElBQUksSUFBSSxTQUFTLEVBQUUsQ0FBQTthQUN6QjtZQUNELEdBQUcsSUFBSSxHQUFHLENBQUM7U0FDZDtRQUNELE9BQU8sR0FBRyxDQUFBO0lBQ2QsQ0FBQztJQVVELGlCQUFpQixDQUFDLGNBQWM7UUFDNUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDMUIsSUFBSSxjQUFjLFlBQVksaUJBQWlCLEVBQUU7WUFDN0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxZQUFZLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQztZQUNyQyxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUUsWUFBWSxDQUFDLElBQUksZ0JBQVMsQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLEVBQUU7Z0JBQ3hFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFBO2FBQ2xDO1lBQ0QsSUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxNQUFNO29CQUNwQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxNQUFNOztvQkFFdEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLE1BQU07NEJBQ25FLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQ3ZGO2dCQUNFLE9BQU8sQ0FBQyxJQUFJLENBQUMseUZBQXlGLEVBQUU7b0JBQ2hHLElBQUksRUFBRSxJQUFJO29CQUNWLGNBQWM7aUJBQ2pCLENBQ0osQ0FBQTthQUNKO1lBQ0QsSUFBSSxDQUFDLEVBQUUsaUNBQU0sSUFBSSxDQUFDLFVBQVUsR0FBSyxjQUFjLENBQUMsVUFBVSxFQUFJLENBQUM7U0FDbEU7YUFBTTtZQUVILElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3pCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQzlDLElBQUksQ0FBQyxZQUFZLEdBQUcsY0FBYyxDQUFDO1NBQ3RDO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQU9ELElBQUksQ0FBQyxJQUFLO1FBQ04sSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQ3BCLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUM7U0FDdEM7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUNuQyxPQUFPLElBQUksQ0FBQztTQUNmO0lBQ0wsQ0FBQztJQU1ELElBQUksQ0FBQyxHQUFJO1FBQ0wsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQ25CLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUM7U0FDdEM7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztZQUNsQyxPQUFPLElBQUksQ0FBQztTQUNmO0lBRUwsQ0FBQztJQU1ELEVBQUUsQ0FBQyxFQUFHOztRQUNGLElBQUksRUFBRSxLQUFLLFNBQVMsRUFBRTtZQUNsQixhQUFPLElBQUksQ0FBQyxZQUFZLDBDQUFFLEVBQUUsQ0FBQztTQUNoQzthQUFNO1lBQ0gsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQzFCLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7SUFDTCxDQUFDO0lBTUQsR0FBRyxDQUFDLEdBQUc7UUFDSCxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsRUFBRTtZQUN6QixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZDO2FBQU07WUFDSCxLQUFLLElBQUksQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLElBQUksZ0JBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDOUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQVMsU0FBUyxDQUFDLEdBQUcsUUFBUSxDQUFDO2FBQ3pEO1lBQ0QsT0FBTyxJQUFJLENBQUM7U0FDZjtJQUNMLENBQUM7SUFHRCxLQUFLLENBQUMsR0FBRyxXQUFpQztRQUN0QyxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDYixLQUFLLElBQUksSUFBSSxJQUFJLFdBQVcsRUFBRTtZQUMxQixHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQ2xCO1FBQ0QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3pCLENBQUM7SUFVRCxLQUFLLENBQUMsR0FBSTtRQUNOLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRTtZQUNuQixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNsRDthQUFNLElBQUksaUJBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN4QixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDNUQ7YUFBTTtZQUNILElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFHYixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ3ZDO2lCQUFNO2dCQUNILElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQzthQUNyQztZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2Y7SUFDTCxDQUFDO0lBRUQsUUFBUSxDQUFDLEdBQVcsRUFBRSxHQUFHLEtBQWU7UUFDcEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3JDLEtBQUssSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFO1lBQ2pCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QztRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFJRCxXQUFXLENBQUMsR0FBRyxFQUFFLEdBQUcsS0FBSztRQUNyQixJQUFJLGlCQUFVLENBQW1CLEdBQUcsQ0FBQyxFQUFFO1lBQ25DLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDcEQsS0FBSyxJQUFJLENBQUMsSUFBd0IsS0FBSyxFQUFFO2dCQUNyQyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3JEO1NBQ0o7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN4QyxLQUFLLElBQUksQ0FBQyxJQUFJLEtBQUssRUFBRTtnQkFDakIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3pDO1NBQ0o7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBSUQsWUFBWSxDQUFDLFFBQVEsRUFBRSxRQUFRO1FBQzNCLElBQUksaUJBQVUsQ0FBbUIsUUFBUSxDQUFDLEVBQUU7WUFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7U0FDdkU7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7U0FDM0Q7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBSUQsV0FBVyxDQUFDLEdBQUcsRUFBRSxLQUFLO1FBQ2xCLElBQUksaUJBQVUsQ0FBbUIsR0FBRyxDQUFDLEVBQUU7WUFDbkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDOUQ7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDbEQ7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBTUQsUUFBUSxDQUFDLEdBQUc7UUFDUixJQUFJLGlCQUFVLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDakIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFNBQVMsQ0FBQztTQUN4QzthQUFNO1lBQ0gsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDcEQ7SUFDTCxDQUFDO0lBSUQsS0FBSyxDQUFDLEdBQUcsS0FBc0M7UUFDM0MsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEVBQUU7WUFDcEIsSUFBSSxJQUFJLFlBQVksaUJBQWlCLEVBQUU7Z0JBQ25DLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNuQztpQkFBTTtnQkFDSCxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNqQztTQUNKO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUdELFdBQVcsQ0FBQyxJQUFxQztRQUM3QyxJQUFJLElBQUksWUFBWSxpQkFBaUIsRUFBRTtZQUNuQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDOUM7YUFBTTtZQUNILElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2pDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUtELE1BQU0sQ0FBQyxHQUFHLEtBQThGO1FBQ3BHLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxFQUFFO1lBQ3BCLElBQUksSUFBSSxZQUFZLGlCQUFpQixFQUFFO2dCQUNuQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDcEM7aUJBQU07Z0JBQ0gsSUFBSSxJQUFJLFlBQVksSUFBSSxFQUFFO29CQUN0QixJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDbEM7cUJBQU07b0JBQ0gsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztxQkFDNUI7eUJBQU07d0JBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtxQkFDekI7aUJBQ0o7YUFDSjtTQUNKO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFFaEIsQ0FBQztJQUdELFFBQVEsQ0FBQyxJQUFxQztRQUMxQyxJQUFJLElBQUksWUFBWSxpQkFBaUIsRUFBRTtZQUNuQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDL0M7YUFBTTtZQUNILElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2xDO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUdELE1BQU0sQ0FBQyxHQUFHLEtBQXNDO1FBQzVDLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxFQUFFO1lBQ3BCLElBQUksSUFBSSxZQUFZLGlCQUFpQixFQUFFO2dCQUNuQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDcEM7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDbEM7U0FDSjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFHRCxZQUFZLENBQUMsSUFBcUM7UUFDOUMsSUFBSSxJQUFJLFlBQVksaUJBQWlCLEVBQUU7WUFDbkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQy9DO2FBQU07WUFDSCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUNsQztRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFJRCxZQUFZLENBQUMsUUFBUSxFQUFFLFFBQVE7UUFDM0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQ25ELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFTRCxXQUFXLENBQUMsYUFBYTtRQUNyQixNQUFNLFlBQVksR0FBRyxDQUFDLElBQVksRUFBRSxNQUF5QixFQUFFLEVBQUU7WUFDN0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUM7UUFDRixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDOUIsS0FBSyxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLGFBQWEsRUFBRTtnQkFDcEMsWUFBWSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUM1QjtTQUNKO2FBQU07WUFDSCxLQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksZ0JBQVMsQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDL0MsWUFBWSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUM1QjtTQUNKO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELElBQUk7UUFDQSxPQUFPLGlCQUFpQixDQUFBO0lBQzVCLENBQUM7SUF1QkQsS0FBSyxDQUFDLFFBQVEsRUFBRSxNQUFPO1FBQ25CLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBZ0IsQ0FBQztRQUM3RSxJQUFJLFdBQVcsS0FBSyxJQUFJLEVBQUU7WUFDdEIsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksVUFBVSxRQUFRLGtDQUFrQyxDQUFDLENBQUM7WUFDMUUsT0FBTyxTQUFTLENBQUM7U0FDcEI7UUFDRCxJQUFJLEdBQUcsQ0FBQztRQUNSLElBQUksTUFBTSxLQUFLLFNBQVMsRUFBRTtZQUN0QixHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUM5QzthQUFNO1lBQ0gsR0FBRyxHQUFHLElBQUksTUFBTSxDQUFDLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztTQUNyQztRQUNELE9BQU8sR0FBRyxDQUFDO0lBQ2YsQ0FBQztJQVdELFFBQVEsQ0FBQyxRQUFTO1FBQ2QsSUFBSSxlQUFlLENBQUM7UUFDcEIsSUFBSSxrQkFBa0IsQ0FBQztRQUN2QixJQUFJLFFBQVEsS0FBSyxTQUFTLEVBQUU7WUFDeEIsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUM7U0FDbkQ7YUFBTTtZQUNILGtCQUFrQixHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDckU7UUFFRCxlQUFlLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBRWpELE9BQU8sZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVELEtBQUssQ0FBQyxJQUFjO1FBQ2hCLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLGtFQUFrRSxDQUFDLENBQUM7UUFFeEYsT0FBTyxJQUFJLGlCQUFpQixDQUFDLEVBQUUsV0FBVyxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBZ0IsRUFBRSxDQUFDLENBQUM7SUFDcEcsQ0FBQztJQXFCRCxhQUFhLENBQUMsV0FBd0I7UUFDbEMsS0FBSyxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLGdCQUFTLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDN0MsSUFBSSxJQUFJLEdBQUcsT0FBTyxLQUFLLENBQUM7WUFDeEIsSUFBSSxlQUFRLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2pCLElBQUksS0FBSyxZQUFZLGlCQUFpQixFQUFFO29CQUVwQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQTtpQkFDMUI7cUJBQU07b0JBRUgsSUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDcEMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxFQUFFO3dCQUMxQixPQUFPLENBQUMsSUFBSSxDQUNSLHFHQUFxRyxFQUFFOzRCQUNuRyxHQUFHOzRCQUNILG9CQUFvQixFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzVDLEtBQUs7NEJBQ0wsSUFBSSxFQUFFLElBQUk7eUJBQ2IsQ0FDSixDQUFDO3FCQUNMO29CQUNELElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNqQyxJQUFJLGlCQUFVLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBRWpCLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDO3dCQUNwQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztxQkFDekI7eUJBQU07d0JBQ0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3dCQUN2QyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNoQztpQkFDSjthQUNKO2lCQUFNLElBQUksSUFBSSxLQUFLLFFBQVEsRUFBRTtnQkFDMUIsSUFBSSxLQUFLLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFlLENBQUMsQ0FBQztnQkFFN0MsSUFBSSxLQUFLLEVBQUU7b0JBRVAsSUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBUSxDQUFDO29CQUU5QixNQUFNLFlBQVksR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBNEMsQ0FBQztvQkFDckgsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO29CQUNkLEtBQUssSUFBSSxXQUFXLElBQUksWUFBWSxFQUFFO3dCQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztxQkFDbkQ7b0JBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQzFCO3FCQUFNO29CQUVILElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBb0IsQ0FBQyxDQUFDLENBQUM7aUJBQ3REO2FBQ0o7aUJBQU07Z0JBQ0gsT0FBTyxDQUFDLElBQUksQ0FBQyxtQ0FBbUMsSUFBSSxZQUFZLEdBQUcsY0FBYyxLQUFLLGlCQUFpQixFQUFFLFdBQVcsQ0FBRSxDQUFDO2FBQzFIO1NBQ0o7UUFDRCxPQUFPLElBQUksQ0FBQztJQUVoQixDQUFDO0lBR0QsS0FBSztRQUNELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUU7WUFDakMsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUMvRDtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFHRCxNQUFNO1FBQ0YsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMzQixPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBSUQsRUFBRSxDQUFDLGFBQXVDLEVBQUUsT0FBaUM7UUFFekUsS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxJQUFJLGdCQUFTLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDakQsTUFBTSxFQUFFLEdBQUcsU0FBUyxFQUFFLENBQUMsR0FBRztnQkFDdEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2QsQ0FBQyxDQUFDO1lBQ0YsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ3hELElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQ2hDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQWFELFVBQVUsQ0FBQyxFQUEyQixFQUFFLE9BQWlDO1FBQ3JFLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQWM7WUFDdkUsRUFBRSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3BCLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNQLElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQzNCO2dCQUNJLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7YUFDOUM7UUFDTCxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFWixPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBR0QsV0FBVyxDQUFDLEVBQTZDLEVBQUUsT0FBaUM7UUFFeEYsSUFBSSxNQUFNLENBQUM7UUFDWCxJQUFJO1lBR0EsTUFBTSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO1NBQzlEO1FBQUMsT0FBTyxDQUFDLEVBQUU7WUFDUixNQUFNLEdBQUcsV0FBVyxDQUFBO1NBQ3ZCO1FBQ0QsTUFBTSxFQUFFLEdBQUcsU0FBUyxFQUFFLENBQUMsRUFBNkI7WUFDaEQsRUFBRSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3BCLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNQLElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQzNCO2dCQUNJLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUM7YUFDeEM7UUFDTCxDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDeEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ2pDLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFRRCxLQUFLLENBQUMsRUFBRyxFQUFFLE9BQVE7UUFDZixJQUFJLEVBQUUsS0FBSyxTQUFTLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUMxQixPQUFPLElBQUksQ0FBQztTQUNmO2FBQU07WUFDSCxPQUFPLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDMUM7SUFDTCxDQUFDO0lBUUQsSUFBSSxDQUFDLEVBQUcsRUFBRSxPQUFRO1FBQ2QsSUFBSSxFQUFFLEtBQUssU0FBUyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDekIsT0FBTyxJQUFJLENBQUM7U0FDZjthQUFNO1lBQ0gsT0FBTyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFBO1NBQ3hDO0lBQ0wsQ0FBQztJQVFELEtBQUssQ0FBQyxFQUFHLEVBQUUsT0FBUTtRQUNmLElBQUksRUFBRSxLQUFLLFNBQVMsRUFBRTtZQUNsQixJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQzFCLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7YUFBTTtZQUNILE9BQU8sSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQTtTQUN6QztJQUNMLENBQUM7SUFHRCxNQUFNLENBQUMsRUFBeUIsRUFBRSxPQUFpQztRQUMvRCxPQUFPLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUdELFdBQVcsQ0FBQyxFQUE4QixFQUFFLE9BQWlDO1FBQ3pFLE9BQU8sSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLFdBQVcsRUFBRSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBUUQsUUFBUSxDQUFDLEVBQUcsRUFBRSxPQUFRO1FBQ2xCLElBQUksRUFBRSxLQUFLLFNBQVMsRUFBRTtZQUNsQixNQUFNLFFBQVEsR0FBRyxJQUFJLFVBQVUsQ0FBQyxVQUFVLEVBQUU7Z0JBQ3hDLE1BQU0sRUFBRSxNQUFNO2dCQUNkLFNBQVMsRUFBRSxJQUFJO2dCQUNmLFlBQVksRUFBRSxJQUFJO2FBQ3JCLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzFDLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7YUFBTTtZQUNILE9BQU8sSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQTtTQUM1QztJQUNMLENBQUM7SUFRRCxVQUFVLENBQUMsRUFBRyxFQUFFLE9BQVE7UUFJcEIsSUFBSSxFQUFFLEtBQUssU0FBUyxFQUFFO1lBQ2xCLE1BQU0sVUFBVSxHQUFHLElBQUksVUFBVSxDQUFDLFlBQVksRUFBRTtnQkFDNUMsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsWUFBWSxFQUFFLElBQUk7YUFDckIsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDNUMsT0FBTyxJQUFJLENBQUM7U0FDZjthQUFNO1lBQ0gsT0FBTyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFBO1NBQzlDO0lBQ0wsQ0FBQztJQUdELE9BQU8sQ0FBQyxFQUFpQyxFQUFFLE9BQWlDO1FBQ3hFLE9BQU8sSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQTtJQUM1QyxDQUFDO0lBR0QsUUFBUSxDQUFDLEVBQThCLEVBQUUsT0FBaUM7UUFLdEUsT0FBTyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFBO0lBQzdDLENBQUM7SUFHRCxTQUFTLENBQUMsRUFBK0IsRUFBRSxPQUFpQztRQUl4RSxPQUFPLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUNyQyxDQUFDO0lBR0QsR0FBRyxDQUFDLEtBQWdCO1FBRWhCLElBQUksQ0FBQyxZQUFZLENBQUMsbUJBQW1CLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUNyRSxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBR0QsTUFBTTtRQUVGLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDMUQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMvQixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ25CO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQVVELElBQUksQ0FBQyxZQUFZO1FBQ2IsSUFBSSxPQUFPLFlBQVksS0FBSyxRQUFRLEVBQUU7WUFDbEMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUN2RDthQUFNO1lBQ0gsS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLGdCQUFTLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQzdDLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQzthQUM3QztZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2Y7SUFDTCxDQUFDO0lBR0QsVUFBVSxDQUFDLGFBQXFCLEVBQUUsR0FBRyxjQUF3QjtRQUN6RCxJQUFJLGdCQUFnQixDQUFDO1FBQ3JCLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNiLGdCQUFnQixHQUFHLENBQUMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQztTQUN4RzthQUFNO1lBQ0gsZ0JBQWdCLEdBQUcsQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQzFGO1FBRUQsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDaEMsS0FBSyxJQUFJLEVBQUUsSUFBSSxjQUFjLEVBQUU7WUFDM0IsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDeEI7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBR0QsT0FBTyxDQUFDLEdBQVcsRUFBRSxRQUFpQixJQUFJO1FBRXRDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUMzRCxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7WUFDaEIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzNCO2FBQU07WUFDSCxPQUFPLElBQUksQ0FBQTtTQUNkO0lBQ0wsQ0FBQztJQUVPLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBOEM7UUFDOUQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzQyxJQUFJLFFBQVEsS0FBSyxTQUFTLEVBQUU7WUFDeEIsT0FBTyxDQUFDLElBQUksQ0FBQyxvQ0FBb0MsR0FBRyxJQUFJLEVBQUUsY0FBYyxRQUFRLEVBQUUsRUFDOUUsY0FBYyxLQUFLLEVBQUUsRUFBRSx3QkFBd0IsUUFBUSxJQUFJLEtBQUssRUFBRSxDQUNyRSxDQUFDO1NBQ0w7UUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQ2xCLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO0lBQ3RDLENBQUM7Q0FHSjtBQS8yQkQsOENBKzJCQztBQUVELE1BQWEsR0FBNkMsU0FBUSxpQkFBaUM7SUFXL0YsWUFBWSxPQUFPO1FBQ2YsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsR0FBRyxPQUFPLENBQUM7UUFDL0UsSUFBSSxJQUFJLEtBQUssU0FBUyxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDMUMsTUFBTSxJQUFJLGtDQUFxQixDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7U0FDbEQ7UUFDRCxJQUFJLFdBQVcsS0FBSyxTQUFTLEVBQUU7WUFDM0IsS0FBSyxDQUFDLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7U0FDcEM7YUFBTSxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDM0IsS0FBSyxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7U0FDN0I7YUFBTSxJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUU7WUFDNUIsS0FBSyxDQUFDLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7U0FDOUI7YUFBTTtZQUNILEtBQUssQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1lBQ3hDLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtnQkFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNuQjtTQUVKO0lBQ0wsQ0FBQztDQUVKO0FBL0JELGtCQStCQztBQUVELE1BQWEsU0FBVSxTQUFRLGlCQUF1QztJQUVsRSxZQUFZLEtBQUs7UUFJYixNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxHQUFHLEtBQUssQ0FBQztRQUM3RSxJQUFJLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUMxQyxNQUFNLElBQUksa0NBQXFCLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtTQUNsRDtRQUNELElBQUksV0FBVyxLQUFLLFNBQVMsRUFBRTtZQUMzQixLQUFLLENBQUMsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUNwQzthQUFNLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUMzQixLQUFLLENBQUMsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUM3QjthQUFNLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRTtZQUM1QixLQUFLLENBQUMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUM5QjthQUFNO1lBQ0gsS0FBSyxDQUFDLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7WUFDdEMsSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO2dCQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ25CO1NBQ0o7SUFDTCxDQUFDO0NBQ0o7QUF2QkQsOEJBdUJDO0FBRUQsTUFBYSxJQUFLLFNBQVEsaUJBQWtDO0lBY3hELFlBQVksUUFBUTtRQUNoQixNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxHQUFHLFFBQVEsQ0FBQztRQUNoRixJQUFJLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUMxQyxNQUFNLElBQUksa0NBQXFCLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtTQUNsRDtRQUNELElBQUksV0FBVyxLQUFLLFNBQVMsRUFBRTtZQUMzQixLQUFLLENBQUMsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUNwQzthQUFNLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUMzQixLQUFLLENBQUMsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUM3QjthQUFNLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRTtZQUM1QixLQUFLLENBQUMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUM5QjthQUFNO1lBQ0gsS0FBSyxDQUFDLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7WUFDekMsSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO2dCQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ25CO1NBQ0o7SUFFTCxDQUFDO0NBQ0o7QUFqQ0Qsb0JBaUNDO0FBRUQsTUFBYSxHQUE2QyxTQUFRLGlCQUFtQztJQW1CakcsWUFBWSxPQUFRO1FBQ2hCLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsR0FBRyxPQUFPLENBQUM7UUFDeEUsSUFBSSxXQUFXLEtBQUssU0FBUyxFQUFFO1lBQzNCLEtBQUssQ0FBQyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQ3BDO2FBQU0sSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQzNCLEtBQUssQ0FBQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO2FBQU0sSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQzVCLEtBQUssQ0FBQyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQzlCO2FBQU07WUFDSCxLQUFLLENBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO1lBQ2xDLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNqQjtTQUNKO0lBRUwsQ0FBQztJQUlELEdBQUcsQ0FBQyxHQUFJO1FBQ0osSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQ25CLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUE7U0FDL0I7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztZQUM1QixPQUFPLElBQUksQ0FBQztTQUNmO0lBQ0wsQ0FBQztDQUdKO0FBaERELGtCQWdEQztBQUVELE1BQWEsTUFBTyxTQUFRLGlCQUFvQztJQUc1RCxZQUFZLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFO1FBQ3BGLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQzFDLE1BQU0sSUFBSSxrQ0FBcUIsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1NBQ2xEO1FBQ0QsSUFBSSxXQUFXLEtBQUssU0FBUyxFQUFFO1lBQzNCLEtBQUssQ0FBQyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQ3BDO2FBQU0sSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQzNCLEtBQUssQ0FBQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO2FBQU0sSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQzVCLEtBQUssQ0FBQyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQzlCO2FBQU07WUFDSCxLQUFLLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUN0QyxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7Z0JBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDbkI7WUFDRCxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7Z0JBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDbkI7WUFDRCxJQUFJLE1BQU0sS0FBSyxTQUFTLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDdkI7U0FDSjtJQUVMLENBQUM7SUFJRCxJQUFJLENBQUMsR0FBSTtRQUNMLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRTtZQUNuQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDNUI7YUFBTTtZQUNILE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFBO1NBQ2xDO0lBQ0wsQ0FBQztJQUlELE1BQU0sQ0FBQyxHQUFJO1FBQ1AsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQ25CLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUM5QjthQUFNO1lBQ0gsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUE7U0FDcEM7SUFDTCxDQUFDO0NBQ0o7QUEvQ0Qsd0JBK0NDO0FBV0QsTUFBc0IsSUFDbEIsU0FBUSxpQkFBMEI7SUFHbEMsSUFBSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQztJQUN0QyxDQUFDO0lBcUJELE9BQU87UUFDSCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDbEMsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELE1BQU07UUFDRixJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDbkMsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQVFELGFBQWEsQ0FBQyxFQUFFO1FBQ1osSUFBSSxlQUFRLENBQUMsRUFBRSxDQUFDLEVBQUU7WUFDZCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUkseUJBQVksQ0FBQyxFQUFFLFdBQVcsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzFHLE9BQU8sSUFBSSxDQUFBO1NBQ2Q7UUFDRCxJQUFJLFdBQUksQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUNWLE9BQU8sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFBO1NBQ3ZCO2FBQU07WUFDSCxPQUFPLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtTQUN4QjtJQUNMLENBQUM7SUFVRCxLQUFLLENBQUMsR0FBSTs7UUFDTixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUU7WUFDbkIsWUFBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssdUNBQUksU0FBUyxFQUFDO1NBQy9DO2FBQU07WUFDSCxJQUFJLGVBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDZixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUkseUJBQVksQ0FBQyxFQUFFLFdBQVcsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbkcsT0FBTyxJQUFJLENBQUM7YUFDZjtZQUNELElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztZQUM5QixPQUFPLElBQUksQ0FBQztTQUNmO0lBQ0wsQ0FBQztJQUVELEtBQUssQ0FBQyxRQUFRO1FBQ1YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixNQUFNLFdBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqQixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBRTVCLENBQUM7SUFFRCxLQUFLLENBQUMsU0FBUztRQUNYLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDdEIsTUFBTSxXQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDakIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBRUQsS0FBSztRQUNELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUMzQixDQUFDO0lBTUQsWUFBWSxDQUFDLE9BQWM7UUFDdkIsSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDL0MsT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUE7SUFDekIsQ0FBQztJQUtELGVBQWUsQ0FBQyxHQUFRLEVBQUUsT0FBYztRQUNwQyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUMvQyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFBO1NBQ25CO1FBQ0QsT0FBTyxJQUFJLENBQUE7SUFDZixDQUFDO0lBS0QsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFRLEVBQUUsT0FBYztRQUNuQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUMxQyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUMvQyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDZixNQUFNLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUN6QjtRQUNELE9BQU8sSUFBSSxDQUFBO0lBQ2YsQ0FBQztJQUtELEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBUSxFQUFFLE9BQWM7UUFDcEMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDekMsSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDL0MsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2YsTUFBTSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDekI7UUFDRCxPQUFPLElBQUksQ0FBQTtJQUNmLENBQUM7SUFLRCxXQUFXLENBQUMsT0FBYztRQUN0QixJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUMvQyxPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBR1MsS0FBSyxDQUFDLG1CQUFtQixDQUEyQyxPQUFVLEVBQUUsS0FBWTtRQUNsRyxJQUFJO1lBQ0EsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3BCLE1BQU0sR0FBRyxHQUFHLE1BQU0sT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2pDLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUVuQztRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1IsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBRTFCO2dCQUFTO1lBQ04sSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO0lBQ0wsQ0FBQztDQUNKO0FBL0pELG9CQStKQztBQUdELE1BQWEsTUFBZ0QsU0FBUSxJQUF1QjtJQW1CeEYsWUFBWSxVQUFXO1FBQ25CLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxHQUFHLFVBQVUsQ0FBQztRQUN6RixJQUFJLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUMxQyxNQUFNLElBQUksa0NBQXFCLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtTQUNsRDtRQUNELElBQUksV0FBVyxLQUFLLFNBQVMsRUFBRTtZQUMzQixLQUFLLENBQUMsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUNwQzthQUFNLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUMzQixLQUFLLENBQUMsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUM3QjthQUFNLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRTtZQUM1QixLQUFLLENBQUMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUM5QjthQUFNO1lBQ0gsS0FBSyxDQUFDLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7WUFDM0MsSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO2dCQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ25CO1lBQ0QsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO2dCQUNyQixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3JCO1NBRUo7SUFFTCxDQUFDO0lBRUQsS0FBSyxDQUFDLEdBQTBDO1FBQzVDLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRTtZQUNuQixNQUFNLEVBQUUsR0FBRyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQ3ZCLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMvQyxDQUFDLENBQUM7WUFFRixPQUFPLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDMUI7UUFDRCxPQUFPLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQTtJQUN4QixDQUFDO0NBR0o7QUF2REQsd0JBdURDO0FBRUQsTUFBYSxLQUdULFNBQVEsSUFBYTtJQW9CckIsWUFBWSxTQUFVO1FBQ2xCLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsR0FBRyxTQUFTLENBQUM7UUFHM0UsSUFBSSxXQUFXLEtBQUssU0FBUyxFQUFFO1lBQzNCLEtBQUssQ0FBQyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQ3BDO2FBQU0sSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQzNCLEtBQUssQ0FBQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO2FBQU0sSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQzVCLEtBQUssQ0FBQyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQzlCO2FBQU07WUFDSCxLQUFLLENBQUMsRUFBRSxHQUFHLEVBQUUsT0FBK0IsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUM1RCxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7Z0JBRXBCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQzthQUNqQztTQUNKO0lBR0wsQ0FBQztDQUdKO0FBN0NELHNCQTZDQztBQUVELE1BQWEsU0FBbUQsU0FBUSxLQUFhO0lBa0JqRixZQUFZLElBQUs7UUFDYixJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztRQUNuQixLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDWixNQUFNLEVBQUUsV0FBVyxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBQzdCLElBQUksV0FBVyxLQUFLLFNBQVMsRUFBRTtZQUMzQixJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQztJQUlELFdBQVcsQ0FBQyxHQUFJO1FBQ1osSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQ25CLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUM7U0FDeEM7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztZQUNwQyxPQUFPLElBQUksQ0FBQztTQUNmO0lBRUwsQ0FBQztJQUVELE9BQU8sQ0FBQyxHQUE0QztRQUNoRCxNQUFNLEVBQUUsR0FBRyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUU7WUFDdkIsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLE9BQU8sRUFBRTtnQkFDdkIsT0FBTzthQUNWO1lBQ0QsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxXQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLHVCQUFVLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pHLE9BQU87YUFDVjtZQUNELE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMvQyxDQUFDLENBQUM7UUFDRixPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDN0IsQ0FBQztDQUNKO0FBckRELDhCQXFEQztBQUVELE1BQWEsU0FBNEUsU0FBUSxLQUEwQjtJQUN2SCxNQUFNLENBQUMsR0FBb0M7UUFFdkMsTUFBTSxFQUFFLEdBQUcsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQ3ZCLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMvQyxDQUFDLENBQUM7UUFDRixPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDNUIsQ0FBQztDQUNKO0FBUkQsOEJBUUM7QUFHRCxNQUFhLGFBQWMsU0FBUSxTQUF1QztJQUN0RSxZQUFZLElBQUk7UUFDWixJQUFJLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQztRQUN2QixLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDaEIsQ0FBQztJQUVELElBQUksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUM7SUFDckMsQ0FBQztJQUVELEtBQUs7UUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDakMsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELE9BQU87UUFDSCxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7UUFDbEMsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQVVELGFBQWEsQ0FBQyxFQUFFO1FBQ1osSUFBSSxlQUFRLENBQUMsRUFBRSxDQUFDLEVBQUU7WUFDZCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUkseUJBQVksQ0FBQyxFQUFFLFdBQVcsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzFHLE9BQU8sSUFBSSxDQUFBO1NBQ2Q7UUFDRCxJQUFJLFdBQUksQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUNWLE9BQU8sSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFBO1NBQ3RCO2FBQU07WUFDSCxPQUFPLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtTQUN4QjtJQUNMLENBQUM7SUFVRCxLQUFLLENBQUMsR0FBSTs7UUFDTixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUU7WUFDbkIsWUFBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sdUNBQUksU0FBUyxFQUFDO1NBQ2pEO2FBQU07WUFDSCxJQUFJLGVBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDZixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUkseUJBQVksQ0FBQyxFQUFFLFdBQVcsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUN0RztZQUNELElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztZQUNoQyxPQUFPLElBQUksQ0FBQztTQUNmO0lBQ0wsQ0FBQztJQUVELEtBQUs7UUFDRCxPQUFPLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFRLEVBQUUsT0FBYztRQUNuQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2xDLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM3QixDQUFDO0NBQ0o7QUFwRUQsc0NBb0VDO0FBR0QsTUFBYSxNQUFPLFNBQVEsU0FBdUM7SUFJL0QsWUFBWSxVQUFVO1FBQ2xCLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN0QixDQUFDO0lBRUQsSUFBSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQTtJQUMxQyxDQUFDO0lBRUQsSUFBSSxhQUFhLENBQUMsR0FBVztRQUN6QixJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsR0FBRyxHQUFHLENBQUE7SUFDekMsQ0FBQztJQUVELElBQUksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUE7SUFDeEMsQ0FBQztJQUdELElBQUksUUFBUSxDQUFDLEdBQUc7UUFDWixJQUFJLEdBQUcsWUFBWSxpQkFBaUIsRUFBRTtZQUNsQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztZQUNuRCxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDZCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksdUJBQVUsQ0FBQyxFQUFFLFdBQVcsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEtBQUssRUFBRSxtQkFBbUIsRUFBRSxPQUFPLEVBQUUsNkJBQTZCLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDaEk7WUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztTQUM5QjthQUFNLElBQUksT0FBTyxHQUFHLEtBQUssUUFBUSxFQUFFO1lBQ2hDLElBQUksQ0FBQyxhQUFhLEdBQUcsR0FBRyxDQUFBO1NBQzNCO2FBQU07WUFDSCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQztTQUNyRTtJQUVMLENBQUM7SUFFRCxJQUFJLE9BQU87UUFDUCxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQWlELENBQUMsQ0FBQTtJQUNuRixDQUFDO0lBRUQsSUFBSSxDQUFDLEtBQWE7UUFDZCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBc0IsQ0FBQTtJQUM3RCxDQUFDO0lBVUQsS0FBSyxDQUFDLEdBQUk7O1FBQ04sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQ25CLFlBQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLHVDQUFJLFNBQVMsRUFBQztTQUMzQzthQUFNO1lBQ0gsSUFBSSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUM7WUFDcEIsT0FBTyxJQUFJLENBQUM7U0FDZjtJQUNMLENBQUM7SUFHRCxLQUFLO1FBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7UUFDdkIsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztDQWdCSjtBQWpGRCx3QkFpRkM7QUEwQkQsU0FBZ0IsSUFBSSxDQUFDLFdBQVc7SUFDNUIsT0FBTyxJQUFJLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQzlDLENBQUM7QUFGRCxvQkFFQztBQWVELFNBQWdCLElBQUksQ0FBQyxRQUFTO0lBQzFCLElBQUksQ0FBQyxXQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7UUFDakIsUUFBUSxHQUFHLEVBQUUsQ0FBQTtLQUNoQjtJQUNELE9BQU8sSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDN0IsQ0FBQztBQUxELG9CQUtDO0FBcUJELFNBQWdCLEdBQUcsQ0FBQyxPQUFRO0lBQ3hCLElBQUksQ0FBQyxXQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDaEIsT0FBTyxHQUFHLEVBQUUsQ0FBQTtLQUNmO0lBQ0QsT0FBTyxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUMzQixDQUFDO0FBTEQsa0JBS0M7QUFxQkQsU0FBZ0IsTUFBTSxDQUFDLFVBQVc7SUFDOUIsSUFBSSxDQUFDLFdBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtRQUNuQixVQUFVLEdBQUcsRUFBRSxDQUFBO0tBQ2xCO0lBQ0QsT0FBTyxJQUFJLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUNqQyxDQUFDO0FBTEQsd0JBS0M7QUFrQkQsU0FBZ0IsS0FBSyxDQUFDLFNBQVU7SUFDNUIsSUFBSSxDQUFDLFdBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtRQUNsQixTQUFTLEdBQUcsRUFBRSxDQUFBO0tBQ2pCO0lBQ0QsT0FBTyxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQTtBQUMvQixDQUFDO0FBTEQsc0JBS0M7QUFFRCxTQUFnQixNQUFNLENBQUMsVUFBVTtJQUM3QixJQUFJLENBQUMsV0FBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQ25CLFVBQVUsR0FBRyxFQUFFLENBQUE7S0FDbEI7SUFDRCxPQUFPLElBQUksTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFBO0FBQ2pDLENBQUM7QUFMRCx3QkFLQztBQW1CRCxTQUFnQixHQUFHLENBQUMsT0FBUTtJQUN4QixJQUFJLENBQUMsV0FBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ2hCLE9BQU8sR0FBRyxFQUFFLENBQUE7S0FDZjtJQUNELE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUE7QUFDM0IsQ0FBQztBQUxELGtCQUtDO0FBZUQsU0FBZ0IsU0FBUyxDQUFDLEtBQU07SUFDNUIsSUFBSSxDQUFDLFdBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNkLEtBQUssR0FBRyxFQUFFLENBQUE7S0FDYjtJQUNELE9BQU8sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDL0IsQ0FBQztBQUxELDhCQUtDO0FBNEJELFNBQWdCLE1BQU0sQ0FBQyxVQUFXO0lBQzlCLElBQUksQ0FBQyxXQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7UUFDbkIsVUFBVSxHQUFHLEVBQUUsQ0FBQTtLQUNsQjtJQUNELE9BQU8sSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUE7QUFDakMsQ0FBQztBQUxELHdCQUtDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYWxsVW5kZWZpbmVkLCBhbnlEZWZpbmVkLCBhbnlUcnV0aHksIGJvb2wsIGVudW1lcmF0ZSwgaXNGdW5jdGlvbiwgaXNPYmplY3QsIHdhaXQgfSBmcm9tIFwiLi91dGlsXCI7XG5pbXBvcnQgeyBDaGlsZHJlbk9iaiwgQ3NzT3B0aW9ucywgRWxlbWVudDJUYWcsIEV2ZW50TmFtZSwgRXZlbnROYW1lMkZ1bmN0aW9uLCBNYXBPZkV2ZW50TmFtZTJGdW5jdGlvbiwgUXVlcnlPclByZWNpc2VUYWcsIFF1ZXJ5U2VsZWN0b3IsIFJldHVybnMsIFRhZywgVGFnT3JTdHJpbmcsIFRNYXAgfSBmcm9tIFwiLi90eXBpbmdzXCI7XG5pbXBvcnQgeyBCSEVUeXBlRXJyb3IsIE11dHVhbGx5RXhjbHVzaXZlQXJncywgTm90RW5vdWdoQXJncywgc3VtbWFyeSwgVmFsdWVFcnJvciB9IGZyb20gXCIuL2V4Y2VwdGlvbnNcIjtcblxuY29uc3QgU1ZHX05TX1VSSSA9ICdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Zyc7XG5cbmV4cG9ydCBjbGFzcyBCZXR0ZXJIVE1MRWxlbWVudDxHZW5lcmljIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4ge1xuICAgIHByb3RlY3RlZCBfaHRtbEVsZW1lbnQ6IEdlbmVyaWM7XG4gICAgcHJpdmF0ZSByZWFkb25seSBfaXNTdmc6IGJvb2xlYW4gPSBmYWxzZTtcbiAgICBwcml2YXRlIHJlYWRvbmx5IF9saXN0ZW5lcnM6IE1hcE9mRXZlbnROYW1lMkZ1bmN0aW9uID0ge307XG4gICAgcHJpdmF0ZSBfY2FjaGVkQ2hpbGRyZW46IFRNYXA8QmV0dGVySFRNTEVsZW1lbnQgfCBCZXR0ZXJIVE1MRWxlbWVudFtdPiA9IHt9O1xuXG4gICAgLyoqQ3JlYXRlIGFuIGVsZW1lbnQgb2YgYHRhZ2AuIE9wdGlvbmFsbHksIHNldCBpdHMgYGNsc2Agb3IgYGlkYC4gKi9cbiAgICBjb25zdHJ1Y3Rvcih7IHRhZywgY2xzLCBzZXRpZCwgaHRtbCB9OiB7IHRhZzogRWxlbWVudDJUYWc8R2VuZXJpYz4sIGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsIGh0bWw/OiBzdHJpbmcgfSk7XG4gICAgLyoqV3JhcCBhbiBleGlzdGluZyBlbGVtZW50IGJ5IGBieWlkYC4gT3B0aW9uYWxseSBjYWNoZSBleGlzdGluZyBgY2hpbGRyZW5gKi9cbiAgICBjb25zdHJ1Y3Rvcih7IGJ5aWQsIGNoaWxkcmVuIH06IHsgYnlpZDogc3RyaW5nLCBjaGlsZHJlbj86IENoaWxkcmVuT2JqIH0pO1xuICAgIC8qKldyYXAgYW4gZXhpc3RpbmcgZWxlbWVudCBieSBgcXVlcnlgLiBPcHRpb25hbGx5IGNhY2hlIGV4aXN0aW5nIGBjaGlsZHJlbmAqL1xuICAgIGNvbnN0cnVjdG9yKHsgcXVlcnksIGNoaWxkcmVuIH06IHsgcXVlcnk6IFF1ZXJ5U2VsZWN0b3IsIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmogfSk7XG4gICAgLyoqV3JhcCBhbiBleGlzdGluZyBIVE1MRWxlbWVudC4gT3B0aW9uYWxseSBjYWNoZSBleGlzdGluZyBgY2hpbGRyZW5gKi9cbiAgICBjb25zdHJ1Y3Rvcih7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9OiB7IGh0bWxFbGVtZW50OiBHZW5lcmljOyBjaGlsZHJlbj86IENoaWxkcmVuT2JqIH0pO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1PcHRpb25zKSB7XG4gICAgICAgIGxldCB7XG4gICAgICAgICAgICB0YWcsIGNscywgc2V0aWQsIGh0bWwsIC8vIGNyZWF0ZVxuICAgICAgICAgICAgaHRtbEVsZW1lbnQsIGJ5aWQsIHF1ZXJ5LCBjaGlsZHJlbiAvLyB3cmFwIGV4aXN0aW5nXG4gICAgICAgIH0gPSBlbGVtT3B0aW9ucztcblxuICAgICAgICAvLyAqKiogQXJndW1lbnQgRXJyb3JzXG4gICAgICAgIC8vICoqIHdyYXBwaW5nIGFyZ3M6IGFzc2VydCBtYXggb25lIChvciBub25lIGlmIGNyZWF0aW5nIG5ldylcbiAgICAgICAgaWYgKFt0YWcsIGJ5aWQsIHF1ZXJ5LCBodG1sRWxlbWVudF0uZmlsdGVyKHggPT4geCAhPT0gdW5kZWZpbmVkKS5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTXV0dWFsbHlFeGNsdXNpdmVBcmdzKHtcbiAgICAgICAgICAgICAgICBieWlkLCBxdWVyeSwgaHRtbEVsZW1lbnQsIHRhZ1xuICAgICAgICAgICAgfSwgJ0VpdGhlciB3cmFwIGFuIGV4aXN0aW5nIGVsZW1lbnQgYnkgcGFzc2luZyBvbmUgb2YgYGJ5aWRgIC8gYHF1ZXJ5YCAvIGBodG1sRWxlbWVudGAsIG9yIGNyZWF0ZSBhIG5ldyBvbmUgYnkgcGFzc2luZyBgdGFnYC4nKVxuICAgICAgICB9XG4gICAgICAgIC8vICoqIGNyZWF0aW5nIG5ldyBlbGVtIGFyZ3M6IGFzc2VydCBjcmVhdG9ycyBhbmQgd3JhcHBlcnMgbm90IG1peGVkXG4gICAgICAgIC8vICogaWYgY3JlYXRpbmcgbmV3IHdpdGggZWl0aGVyIGB0YWdgIC8gYHNldGlkYCAsIG5vIG1lYW5pbmcgdG8gZWl0aGVyIGNoaWxkcmVuLCBieWlkLCBodG1sRWxlbWVudCwgb3IgcXVlcnlcbiAgICAgICAgaWYgKGFueURlZmluZWQoW3RhZywgY2xzLCBzZXRpZF0pICYmIGFueURlZmluZWQoW2NoaWxkcmVuLCBieWlkLCBodG1sRWxlbWVudCwgcXVlcnldKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE11dHVhbGx5RXhjbHVzaXZlQXJncyhbXG4gICAgICAgICAgICAgICAgeyB0YWcsIGNscywgc2V0aWQgfSxcbiAgICAgICAgICAgICAgICB7IGNoaWxkcmVuLCBieWlkLCBodG1sRWxlbWVudCwgcXVlcnkgfVxuICAgICAgICAgICAgXSwgYENhbid0IGhhdmUgYXJncyBmcm9tIGJvdGggc2V0c2ApXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFsbFVuZGVmaW5lZChbdGFnLCBieWlkLCBodG1sRWxlbWVudCwgcXVlcnldKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE5vdEVub3VnaEFyZ3MoMSwgeyB0YWcsIGJ5aWQsIGh0bWxFbGVtZW50LCBxdWVyeSB9LCAnZWl0aGVyJyk7XG4gICAgICAgIH1cblxuXG4gICAgICAgIC8vICoqIHRhZyAoQ1JFQVRFIGVsZW1lbnQpXG4gICAgICAgIGlmICh0YWcgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgaWYgKFsnc3ZnJywgJ3BhdGgnXS5pbmNsdWRlcyh0YWcudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1N2ZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoU1ZHX05TX1VSSSwgdGFnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZykgYXMgR2VuZXJpYztcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9IGVsc2UgeyAvLyAqKiB3cmFwIEVYSVNUSU5HIGVsZW1lbnRcbiAgICAgICAgICAgIC8vICogYnlpZFxuICAgICAgICAgICAgaWYgKGJ5aWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGlmIChieWlkLnN0YXJ0c1dpdGgoJyMnKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYHBhcmFtICdieWlkJyBzdGFydHMgd2l0aCAnIycsIHN0cmlwcGluZyBpdDogJHtieWlkfWApO1xuICAgICAgICAgICAgICAgICAgICBieWlkID0gYnlpZC5zdWJzdHIoMSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoYnlpZCkgYXMgR2VuZXJpYztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gKiBxdWVyeVxuICAgICAgICAgICAgICAgIGlmIChxdWVyeSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeSkgYXMgR2VuZXJpYztcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAvLyAqIGh0bWxFbGVtZW50XG4gICAgICAgICAgICAgICAgICAgIGlmIChodG1sRWxlbWVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9odG1sRWxlbWVudCA9IGh0bWxFbGVtZW50O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICghYm9vbCh0aGlzLl9odG1sRWxlbWVudCkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzfSBjb25zdHJ1Y3RvciBlbmRlZCB1cCB3aXRoIG5vICd0aGlzLl9odG1sRWxlbWVudCcuIFBhc3NlZCBvcHRpb25zOiAke3N1bW1hcnkoZWxlbU9wdGlvbnMpfWApXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNscyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLmNsYXNzKGNscyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGh0bWwgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5odG1sKGh0bWwpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjaGlsZHJlbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLmNhY2hlQ2hpbGRyZW4oY2hpbGRyZW4pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzZXRpZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLmlkKHNldGlkKTtcbiAgICAgICAgfVxuXG5cbiAgICB9XG5cbiAgICAvKipSZXR1cm4gdGhlIHdyYXBwZWQgSFRNTEVsZW1lbnQqL1xuICAgIGdldCBlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5faHRtbEVsZW1lbnQ7XG4gICAgfVxuXG4gICAgc3RhdGljIHdyYXBXaXRoQkhFKGh0bWxFbGVtZW50OiBIVE1MQW5jaG9yRWxlbWVudCk6IEFuY2hvcjtcblxuICAgIHN0YXRpYyB3cmFwV2l0aEJIRTxUSW5wdXRUeXBlIGV4dGVuZHMgSW5wdXRUeXBlID0gSW5wdXRUeXBlLCBHZW5lcmljIGV4dGVuZHMgRm9ybWlzaEhUTUxFbGVtZW50ID0gRm9ybWlzaEhUTUxFbGVtZW50PihodG1sRWxlbWVudDogR2VuZXJpYyk6IElucHV0PFRJbnB1dFR5cGUsIEdlbmVyaWM+O1xuXG4gICAgc3RhdGljIHdyYXBXaXRoQkhFKGh0bWxFbGVtZW50OiBIVE1MSW1hZ2VFbGVtZW50KTogSW1nO1xuXG4gICAgc3RhdGljIHdyYXBXaXRoQkhFKGh0bWxFbGVtZW50OiBIVE1MUGFyYWdyYXBoRWxlbWVudCk6IFBhcmFncmFwaDtcblxuICAgIHN0YXRpYyB3cmFwV2l0aEJIRShodG1sRWxlbWVudDogSFRNTFNwYW5FbGVtZW50KTogU3BhbjtcblxuICAgIHN0YXRpYyB3cmFwV2l0aEJIRShodG1sRWxlbWVudDogSFRNTEJ1dHRvbkVsZW1lbnQpOiBCdXR0b247XG5cbiAgICBzdGF0aWMgd3JhcFdpdGhCSEUoaHRtbEVsZW1lbnQ6IEhUTUxEaXZFbGVtZW50KTogRGl2O1xuXG4gICAgc3RhdGljIHdyYXBXaXRoQkhFKGh0bWxFbGVtZW50OiBIVE1MU2VsZWN0RWxlbWVudCk6IERpdjtcblxuICAgIHN0YXRpYyB3cmFwV2l0aEJIRShodG1sRWxlbWVudDogSFRNTEVsZW1lbnQpOiBCZXR0ZXJIVE1MRWxlbWVudDtcblxuICAgIHN0YXRpYyB3cmFwV2l0aEJIRShlbGVtZW50KSB7XG4gICAgICAgIGNvbnN0IHRhZyA9IGVsZW1lbnQudGFnTmFtZS50b0xvd2VyQ2FzZSgpIGFzIEVsZW1lbnQyVGFnPHR5cGVvZiBlbGVtZW50PjtcbiAgICAgICAgLy8gY29uc3QgdGFnID0gZWxlbWVudC50YWdOYW1lLnRvTG93ZXJDYXNlKCkgYXMgVGFnO1xuICAgICAgICBpZiAodGFnID09PSAnZGl2Jykge1xuICAgICAgICAgICAgcmV0dXJuIGRpdih7IGh0bWxFbGVtZW50OiBlbGVtZW50IH0pO1xuICAgICAgICB9IGVsc2UgaWYgKHRhZyA9PT0gJ2EnKSB7XG4gICAgICAgICAgICByZXR1cm4gYW5jaG9yKHsgaHRtbEVsZW1lbnQ6IGVsZW1lbnQgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAodGFnID09PSAncCcpIHtcbiAgICAgICAgICAgIHJldHVybiBwYXJhZ3JhcGgoeyBodG1sRWxlbWVudDogZWxlbWVudCB9KTtcbiAgICAgICAgfSBlbHNlIGlmICh0YWcgPT09ICdpbWcnKSB7XG4gICAgICAgICAgICByZXR1cm4gaW1nKHsgaHRtbEVsZW1lbnQ6IGVsZW1lbnQgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAodGFnID09PSAnaW5wdXQnKSB7XG4gICAgICAgICAgICBpZiAoZWxlbWVudC50eXBlID09PSBcInRleHRcIikge1xuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgVGV4dElucHV0KHsgaHRtbEVsZW1lbnQ6IGVsZW1lbnQgfSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGVsZW1lbnQudHlwZSA9PT0gXCJjaGVja2JveFwiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBDaGVja2JveElucHV0KHsgaHRtbEVsZW1lbnQ6IGVsZW1lbnQgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiBpbnB1dCh7IGh0bWxFbGVtZW50OiBlbGVtZW50IH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHRhZyA9PT0gJ2J1dHRvbicpIHtcbiAgICAgICAgICAgIHJldHVybiBidXR0b24oeyBodG1sRWxlbWVudDogZWxlbWVudCB9KTtcbiAgICAgICAgfSBlbHNlIGlmICh0YWcgPT09ICdzcGFuJykge1xuICAgICAgICAgICAgcmV0dXJuIHNwYW4oeyBodG1sRWxlbWVudDogZWxlbWVudCB9KTtcbiAgICAgICAgfSBlbHNlIGlmICh0YWcgPT09ICdzZWxlY3QnKSB7XG4gICAgICAgICAgICByZXR1cm4gc2VsZWN0KHsgaHRtbEVsZW1lbnQ6IGVsZW1lbnQgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gZWxlbSh7IGh0bWxFbGVtZW50OiBlbGVtZW50IH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgdG9TdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IHByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKHRoaXMpO1xuICAgICAgICBjb25zdCBwcm90b1N0ciA9IHByb3RvLmNvbnN0cnVjdG9yLnRvU3RyaW5nKCk7XG4gICAgICAgIGxldCBzdHIgPSBwcm90b1N0ci5zdWJzdHJpbmcoNiwgcHJvdG9TdHIuaW5kZXhPZigneycpIC0gMSk7XG5cbiAgICAgICAgbGV0IHRhZyA9IHRoaXMuX2h0bWxFbGVtZW50Py50YWdOYW1lO1xuICAgICAgICBsZXQgaWQgPSB0aGlzLmlkKCk7XG4gICAgICAgIGxldCBjbGFzc0xpc3QgPSB0aGlzLl9odG1sRWxlbWVudD8uY2xhc3NMaXN0O1xuICAgICAgICBpZiAoYW55VHJ1dGh5KFtpZCwgY2xhc3NMaXN0LCB0YWddKSkge1xuICAgICAgICAgICAgc3RyICs9IGAgKGA7XG4gICAgICAgICAgICBpZiAodGFnKSB7XG4gICAgICAgICAgICAgICAgc3RyICs9IGA8JHt0YWcudG9Mb3dlckNhc2UoKX0+YFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgc3RyICs9IGAjJHtpZH1gXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY2xhc3NMaXN0KSB7XG4gICAgICAgICAgICAgICAgc3RyICs9IGAuJHtjbGFzc0xpc3R9YFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc3RyICs9IGApYDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RyXG4gICAgfVxuXG4gICAgLyoqU2V0cyBgdGhpcy5faHRtbEVsZW1lbnRgIHRvIGBuZXdIdG1sRWxlbWVudC5faHRtbEVsZW1lbnRgLlxuICAgICAqIFJlc2V0cyBgdGhpcy5fY2FjaGVkQ2hpbGRyZW5gIGFuZCBjYWNoZXMgYG5ld0h0bWxFbGVtZW50Ll9jYWNoZWRDaGlsZHJlbmAuXG4gICAgICogQWRkcyBldmVudCBsaXN0ZW5lcnMgZnJvbSBgbmV3SHRtbEVsZW1lbnQuX2xpc3RlbmVyc2AsIHdoaWxlIGtlZXBpbmcgYHRoaXMuX2xpc3RlbmVyc2AuKi9cbiAgICB3cmFwU29tZXRoaW5nRWxzZTxUIGV4dGVuZHMgSFRNTEVsZW1lbnQ+KG5ld0h0bWxFbGVtZW50OiBCZXR0ZXJIVE1MRWxlbWVudDxUPik6IHRoaXNcbiAgICAvKipTZXRzIGB0aGlzLl9odG1sRWxlbWVudGAgdG8gYG5ld0h0bWxFbGVtZW50YC5cbiAgICAgKiBLZWVwcyBgdGhpcy5fbGlzdGVuZXJzYC5cbiAgICAgKiBOT1RFOiB0aGlzIHJlaW5pdGlhbGl6ZXMgYHRoaXMuX2NhY2hlZENoaWxkcmVuYCBhbmQgYWxsIGV2ZW50IGxpc3RlbmVycyBiZWxvbmdpbmcgdG8gYG5ld0h0bWxFbGVtZW50YCBhcmUgbG9zdC4gUGFzcyBhIGBCZXR0ZXJIVE1MRWxlbWVudGAgdG8ga2VlcCB0aGVtLiovXG4gICAgd3JhcFNvbWV0aGluZ0Vsc2UobmV3SHRtbEVsZW1lbnQ6IE5vZGUpOiB0aGlzXG4gICAgd3JhcFNvbWV0aGluZ0Vsc2UobmV3SHRtbEVsZW1lbnQpIHtcbiAgICAgICAgdGhpcy5fY2FjaGVkQ2hpbGRyZW4gPSB7fTtcbiAgICAgICAgaWYgKG5ld0h0bWxFbGVtZW50IGluc3RhbmNlb2YgQmV0dGVySFRNTEVsZW1lbnQpIHtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LnJlcGxhY2VXaXRoKG5ld0h0bWxFbGVtZW50LmUpO1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQgPSBuZXdIdG1sRWxlbWVudC5lO1xuICAgICAgICAgICAgZm9yIChsZXQgW19rZXksIF9jYWNoZWRDaGlsZF0gb2YgZW51bWVyYXRlKG5ld0h0bWxFbGVtZW50Ll9jYWNoZWRDaGlsZHJlbikpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZShfa2V5LCBfY2FjaGVkQ2hpbGQpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgT2JqZWN0LmtleXModGhpcy5fY2FjaGVkQ2hpbGRyZW4pLmxlbmd0aFxuICAgICAgICAgICAgICAgICE9PSBPYmplY3Qua2V5cyhuZXdIdG1sRWxlbWVudC5fY2FjaGVkQ2hpbGRyZW4pLmxlbmd0aFxuICAgICAgICAgICAgICAgIHx8XG4gICAgICAgICAgICAgICAgT2JqZWN0LnZhbHVlcyh0aGlzLl9jYWNoZWRDaGlsZHJlbikuZmlsdGVyKHYgPT4gdiAhPT0gdW5kZWZpbmVkKS5sZW5ndGhcbiAgICAgICAgICAgICAgICAhPT0gT2JqZWN0LnZhbHVlcyhuZXdIdG1sRWxlbWVudC5fY2FjaGVkQ2hpbGRyZW4pLmZpbHRlcih2ID0+IHYgIT09IHVuZGVmaW5lZCkubGVuZ3RoXG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYHdyYXBTb21ldGhpbmdFbHNlIHRoaXMuX2NhY2hlZENoaWxkcmVuIGxlbmd0aCAhPT0gbmV3SHRtbEVsZW1lbnQuX2NhY2hlZENoaWxkcmVuLmxlbmd0aGAsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXM6IHRoaXMsXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdIdG1sRWxlbWVudFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5vbih7IC4uLnRoaXMuX2xpc3RlbmVycywgLi4ubmV3SHRtbEVsZW1lbnQuX2xpc3RlbmVycywgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBObyB3YXkgdG8gZ2V0IG5ld0h0bWxFbGVtZW50IGV2ZW50IGxpc3RlbmVycyBiZXNpZGVzIGhhY2tpbmcgRWxlbWVudC5wcm90b3R5cGVcbiAgICAgICAgICAgIHRoaXMub24odGhpcy5fbGlzdGVuZXJzKTtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LnJlcGxhY2VXaXRoKG5ld0h0bWxFbGVtZW50KTtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50ID0gbmV3SHRtbEVsZW1lbnQ7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICAvLyAqKiogQmFzaWNcbiAgICAvKipTZXQgdGhlIGVsZW1lbnQncyBpbm5lckhUTUwqL1xuICAgIGh0bWwoaHRtbDogc3RyaW5nKTogdGhpcztcbiAgICAvKipHZXQgdGhlIGVsZW1lbnQncyBpbm5lckhUTUwqL1xuICAgIGh0bWwoKTogc3RyaW5nO1xuICAgIGh0bWwoaHRtbD8pIHtcbiAgICAgICAgaWYgKGh0bWwgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2h0bWxFbGVtZW50LmlubmVySFRNTDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlNldCB0aGUgZWxlbWVudCdzIGlubmVyVGV4dCovXG4gICAgdGV4dCh0eHQ6IHN0cmluZyB8IG51bWJlcik6IHRoaXM7XG4gICAgLyoqR2V0IHRoZSBlbGVtZW50J3MgaW5uZXJUZXh0Ki9cbiAgICB0ZXh0KCk6IHN0cmluZztcbiAgICB0ZXh0KHR4dD8pIHtcbiAgICAgICAgaWYgKHR4dCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faHRtbEVsZW1lbnQuaW5uZXJUZXh0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuaW5uZXJUZXh0ID0gdHh0O1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cblxuICAgIH1cblxuICAgIC8qKlNldCB0aGUgaWQgb2YgdGhlIGVsZW1lbnQqL1xuICAgIGlkKGlkOiBzdHJpbmcpOiB0aGlzO1xuICAgIC8qKkdldCB0aGUgaWQgb2YgdGhlIGVsZW1lbnQqL1xuICAgIGlkKCk6IHN0cmluZztcbiAgICBpZChpZD8pIHtcbiAgICAgICAgaWYgKGlkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9odG1sRWxlbWVudD8uaWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5pZCA9IGlkO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipGb3IgZWFjaCBgezxzdHlsZUF0dHI+OiA8c3R5bGVWYWw+fWAgcGFpciwgc2V0IHRoZSBgc3R5bGVbc3R5bGVBdHRyXWAgdG8gYHN0eWxlVmFsYC4qL1xuICAgIGNzcyhjc3M6IFBhcnRpYWw8Q3NzT3B0aW9ucz4pOiB0aGlzXG4gICAgLyoqR2V0IGBzdHlsZVtjc3NdYCovXG4gICAgY3NzKGNzczogc3RyaW5nKTogc3RyaW5nXG4gICAgY3NzKGNzcykge1xuICAgICAgICBpZiAodHlwZW9mIGNzcyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9odG1sRWxlbWVudC5zdHlsZVtjc3NdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZm9yIChsZXQgW3N0eWxlQXR0ciwgc3R5bGVWYWxdIG9mIGVudW1lcmF0ZShjc3MpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuc3R5bGVbPHN0cmluZz5zdHlsZUF0dHJdID0gc3R5bGVWYWw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlJlbW92ZSB0aGUgdmFsdWUgb2YgdGhlIHBhc3NlZCBzdHlsZSBwcm9wZXJ0aWVzKi9cbiAgICB1bmNzcyguLi5yZW1vdmVQcm9wczogKGtleW9mIENzc09wdGlvbnMpW10pOiB0aGlzIHtcbiAgICAgICAgbGV0IGNzcyA9IHt9O1xuICAgICAgICBmb3IgKGxldCBwcm9wIG9mIHJlbW92ZVByb3BzKSB7XG4gICAgICAgICAgICBjc3NbcHJvcF0gPSAnJztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5jc3MoY3NzKTtcbiAgICB9XG5cblxuICAgIC8vICoqKiBDbGFzc2VzXG4gICAgLyoqYC5jbGFzc05hbWUgPSBjbHNgKi9cbiAgICBjbGFzcyhjbHM6IHN0cmluZyk6IHRoaXM7XG4gICAgLyoqUmV0dXJuIHRoZSBmaXJzdCBjbGFzcyB0aGF0IG1hdGNoZXMgYGNsc2AgcHJlZGljYXRlLiovXG4gICAgY2xhc3MoY2xzOiBSZXR1cm5zPGJvb2xlYW4+KTogc3RyaW5nO1xuICAgIC8qKlJldHVybiBhIHN0cmluZyBhcnJheSBvZiB0aGUgZWxlbWVudCdzIGNsYXNzZXMgKG5vdCBhIGNsYXNzTGlzdCkqL1xuICAgIGNsYXNzKCk6IHN0cmluZ1tdO1xuICAgIGNsYXNzKGNscz8pIHtcbiAgICAgICAgaWYgKGNscyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gQXJyYXkuZnJvbSh0aGlzLl9odG1sRWxlbWVudC5jbGFzc0xpc3QpO1xuICAgICAgICB9IGVsc2UgaWYgKGlzRnVuY3Rpb24oY2xzKSkge1xuICAgICAgICAgICAgcmV0dXJuIEFycmF5LmZyb20odGhpcy5faHRtbEVsZW1lbnQuY2xhc3NMaXN0KS5maW5kKGNscyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAodGhpcy5faXNTdmcpIHtcbiAgICAgICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICAgICAgLy8gbm9pbnNwZWN0aW9uIEpTQ29uc3RhbnRSZWFzc2lnbm1lbnRcbiAgICAgICAgICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5jbGFzc0xpc3QgPSBbY2xzXTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuY2xhc3NOYW1lID0gY2xzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBhZGRDbGFzcyhjbHM6IHN0cmluZywgLi4uY2xzZXM6IHN0cmluZ1tdKTogdGhpcyB7XG4gICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmNsYXNzTGlzdC5hZGQoY2xzKTtcbiAgICAgICAgZm9yIChsZXQgYyBvZiBjbHNlcykge1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuY2xhc3NMaXN0LmFkZChjKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICByZW1vdmVDbGFzcyhjbHM6IFJldHVybnM8Ym9vbGVhbj4sIC4uLmNsc2VzOiBSZXR1cm5zPGJvb2xlYW4+W10pOiB0aGlzO1xuICAgIHJlbW92ZUNsYXNzKGNsczogc3RyaW5nLCBjbHNlcz86IHN0cmluZ1tdKTogdGhpcztcbiAgICByZW1vdmVDbGFzcyhjbHMsIC4uLmNsc2VzKSB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uPFJldHVybnM8Ym9vbGVhbj4+KGNscykpIHtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUodGhpcy5jbGFzcyhjbHMpKTtcbiAgICAgICAgICAgIGZvciAobGV0IGMgb2YgPFJldHVybnM8Ym9vbGVhbj5bXT5jbHNlcykge1xuICAgICAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUodGhpcy5jbGFzcyhjKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKGNscyk7XG4gICAgICAgICAgICBmb3IgKGxldCBjIG9mIGNsc2VzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShjKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICByZXBsYWNlQ2xhc3Mob2xkVG9rZW46IFJldHVybnM8Ym9vbGVhbj4sIG5ld1Rva2VuOiBzdHJpbmcpOiB0aGlzO1xuICAgIHJlcGxhY2VDbGFzcyhvbGRUb2tlbjogc3RyaW5nLCBuZXdUb2tlbjogc3RyaW5nKTogdGhpc1xuICAgIHJlcGxhY2VDbGFzcyhvbGRUb2tlbiwgbmV3VG9rZW4pIHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb248UmV0dXJuczxib29sZWFuPj4ob2xkVG9rZW4pKSB7XG4gICAgICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5jbGFzc0xpc3QucmVwbGFjZSh0aGlzLmNsYXNzKG9sZFRva2VuKSwgbmV3VG9rZW4pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuY2xhc3NMaXN0LnJlcGxhY2Uob2xkVG9rZW4sIG5ld1Rva2VuKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICB0b2dnbGVDbGFzcyhjbHM6IFJldHVybnM8Ym9vbGVhbj4sIGZvcmNlPzogYm9vbGVhbik6IHRoaXNcbiAgICB0b2dnbGVDbGFzcyhjbHM6IHN0cmluZywgZm9yY2U/OiBib29sZWFuKTogdGhpc1xuICAgIHRvZ2dsZUNsYXNzKGNscywgZm9yY2UpIHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb248UmV0dXJuczxib29sZWFuPj4oY2xzKSkge1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuY2xhc3NMaXN0LnRvZ2dsZSh0aGlzLmNsYXNzKGNscyksIGZvcmNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmNsYXNzTGlzdC50b2dnbGUoY2xzLCBmb3JjZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgLyoqUmV0dXJucyBgdGhpcy5faHRtbEVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKGNscylgICovXG4gICAgaGFzQ2xhc3MoY2xzOiBzdHJpbmcpOiBib29sZWFuXG4gICAgLyoqUmV0dXJucyB3aGV0aGVyIGB0aGlzYCBoYXMgYSBjbGFzcyB0aGF0IG1hdGNoZXMgcGFzc2VkIGZ1bmN0aW9uICovXG4gICAgaGFzQ2xhc3MoY2xzOiBSZXR1cm5zPGJvb2xlYW4+KTogYm9vbGVhblxuICAgIGhhc0NsYXNzKGNscykge1xuICAgICAgICBpZiAoaXNGdW5jdGlvbihjbHMpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jbGFzcyhjbHMpICE9PSB1bmRlZmluZWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faHRtbEVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKGNscyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvLyAqKiogTm9kZXNcbiAgICAvKipJbnNlcnQgYXQgbGVhc3Qgb25lIGBub2RlYCBqdXN0IGFmdGVyIGB0aGlzYC4gQW55IGBub2RlYCBjYW4gYmUgZWl0aGVyIGBCZXR0ZXJIVE1MRWxlbWVudGBzIG9yIHZhbmlsbGEgYE5vZGVgLiovXG4gICAgYWZ0ZXIoLi4ubm9kZXM6IEFycmF5PEJldHRlckhUTUxFbGVtZW50IHwgTm9kZT4pOiB0aGlzIHtcbiAgICAgICAgZm9yIChsZXQgbm9kZSBvZiBub2Rlcykge1xuICAgICAgICAgICAgaWYgKG5vZGUgaW5zdGFuY2VvZiBCZXR0ZXJIVE1MRWxlbWVudCkge1xuICAgICAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmFmdGVyKG5vZGUuZSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmFmdGVyKG5vZGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8qKkluc2VydCBgdGhpc2AganVzdCBhZnRlciBhIGBCZXR0ZXJIVE1MRWxlbWVudGAgb3IgYSB2YW5pbGxhIGBOb2RlYC4qL1xuICAgIGluc2VydEFmdGVyKG5vZGU6IEJldHRlckhUTUxFbGVtZW50IHwgSFRNTEVsZW1lbnQpOiB0aGlzIHtcbiAgICAgICAgaWYgKG5vZGUgaW5zdGFuY2VvZiBCZXR0ZXJIVE1MRWxlbWVudCkge1xuICAgICAgICAgICAgbm9kZS5faHRtbEVsZW1lbnQuYWZ0ZXIodGhpcy5faHRtbEVsZW1lbnQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbm9kZS5hZnRlcih0aGlzLl9odG1sRWxlbWVudCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgLyoqSW5zZXJ0IGF0IGxlYXN0IG9uZSBgbm9kZWAgYWZ0ZXIgdGhlIGxhc3QgY2hpbGQgb2YgYHRoaXNgLlxuICAgICAqIEFueSBgbm9kZWAgY2FuIGJlIGVpdGhlciBhIGBCZXR0ZXJIVE1MRWxlbWVudGAsIGEgdmFuaWxsYSBgTm9kZWAsXG4gICAgICogYSBge3NvbWVLZXk6IEJldHRlckhUTUxFbGVtZW50fWAgcGFpcnMgb2JqZWN0LCBvciBhIGBbc29tZUtleSwgQmV0dGVySFRNTEVsZW1lbnRdYCB0dXBsZS4qL1xuICAgIGFwcGVuZCguLi5ub2RlczogQXJyYXk8QmV0dGVySFRNTEVsZW1lbnQgfCBOb2RlIHwgVE1hcDxCZXR0ZXJIVE1MRWxlbWVudD4gfCBbc3RyaW5nLCBCZXR0ZXJIVE1MRWxlbWVudF0+KTogdGhpcyB7XG4gICAgICAgIGZvciAobGV0IG5vZGUgb2Ygbm9kZXMpIHtcbiAgICAgICAgICAgIGlmIChub2RlIGluc3RhbmNlb2YgQmV0dGVySFRNTEVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5hcHBlbmQobm9kZS5lKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKG5vZGUgaW5zdGFuY2VvZiBOb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmFwcGVuZChub2RlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShub2RlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jYWNoZUFwcGVuZChbbm9kZV0pO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jYWNoZUFwcGVuZChub2RlKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuXG4gICAgfVxuXG4gICAgLyoqQXBwZW5kIGB0aGlzYCB0byBhIGBCZXR0ZXJIVE1MRWxlbWVudGAgb3IgYSB2YW5pbGxhIGBOb2RlYCovXG4gICAgYXBwZW5kVG8obm9kZTogQmV0dGVySFRNTEVsZW1lbnQgfCBIVE1MRWxlbWVudCk6IHRoaXMge1xuICAgICAgICBpZiAobm9kZSBpbnN0YW5jZW9mIEJldHRlckhUTUxFbGVtZW50KSB7XG4gICAgICAgICAgICBub2RlLl9odG1sRWxlbWVudC5hcHBlbmQodGhpcy5faHRtbEVsZW1lbnQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbm9kZS5hcHBlbmQodGhpcy5faHRtbEVsZW1lbnQpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgLyoqSW5zZXJ0IGF0IGxlYXN0IG9uZSBgbm9kZWAganVzdCBiZWZvcmUgYHRoaXNgLiBBbnkgYG5vZGVgIGNhbiBiZSBlaXRoZXIgYEJldHRlckhUTUxFbGVtZW50YHMgb3IgdmFuaWxsYSBgTm9kZWAuKi9cbiAgICBiZWZvcmUoLi4ubm9kZXM6IEFycmF5PEJldHRlckhUTUxFbGVtZW50IHwgTm9kZT4pOiB0aGlzIHtcbiAgICAgICAgZm9yIChsZXQgbm9kZSBvZiBub2Rlcykge1xuICAgICAgICAgICAgaWYgKG5vZGUgaW5zdGFuY2VvZiBCZXR0ZXJIVE1MRWxlbWVudCkge1xuICAgICAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmJlZm9yZShub2RlLmUpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5iZWZvcmUobm9kZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgLyoqSW5zZXJ0IGB0aGlzYCBqdXN0IGJlZm9yZSBhIGBCZXR0ZXJIVE1MRWxlbWVudGAgb3IgYSB2YW5pbGxhIGBOb2RlYHMuKi9cbiAgICBpbnNlcnRCZWZvcmUobm9kZTogQmV0dGVySFRNTEVsZW1lbnQgfCBIVE1MRWxlbWVudCk6IHRoaXMge1xuICAgICAgICBpZiAobm9kZSBpbnN0YW5jZW9mIEJldHRlckhUTUxFbGVtZW50KSB7XG4gICAgICAgICAgICBub2RlLl9odG1sRWxlbWVudC5iZWZvcmUodGhpcy5faHRtbEVsZW1lbnQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbm9kZS5iZWZvcmUodGhpcy5faHRtbEVsZW1lbnQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHJlcGxhY2VDaGlsZChuZXdDaGlsZDogTm9kZSwgb2xkQ2hpbGQ6IE5vZGUpOiB0aGlzO1xuICAgIHJlcGxhY2VDaGlsZChuZXdDaGlsZDogQmV0dGVySFRNTEVsZW1lbnQsIG9sZENoaWxkOiBCZXR0ZXJIVE1MRWxlbWVudCk6IHRoaXM7XG4gICAgcmVwbGFjZUNoaWxkKG5ld0NoaWxkLCBvbGRDaGlsZCkge1xuICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5yZXBsYWNlQ2hpbGQobmV3Q2hpbGQsIG9sZENoaWxkKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG5cbiAgICAvKipGb3IgZWFjaCBgW2tleSwgY2hpbGRdYCBwYWlyLCBgYXBwZW5kKGNoaWxkKWAgYW5kIHN0b3JlIGl0IGluIGB0aGlzW2tleV1gLiAqL1xuICAgIGNhY2hlQXBwZW5kKGtleUNoaWxkUGFpcnM6IFRNYXA8QmV0dGVySFRNTEVsZW1lbnQ+KTogdGhpc1xuXG4gICAgLyoqRm9yIGVhY2ggYFtrZXksIGNoaWxkXWAgdHVwbGUsIGBhcHBlbmQoY2hpbGQpYCBhbmQgc3RvcmUgaXQgaW4gYHRoaXNba2V5XWAuICovXG4gICAgY2FjaGVBcHBlbmQoa2V5Q2hpbGRQYWlyczogW3N0cmluZywgQmV0dGVySFRNTEVsZW1lbnRdW10pOiB0aGlzXG5cbiAgICBjYWNoZUFwcGVuZChrZXlDaGlsZFBhaXJzKSB7XG4gICAgICAgIGNvbnN0IF9jYWNoZUFwcGVuZCA9IChfa2V5OiBzdHJpbmcsIF9jaGlsZDogQmV0dGVySFRNTEVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXBwZW5kKF9jaGlsZCk7XG4gICAgICAgICAgICB0aGlzLl9jYWNoZShfa2V5LCBfY2hpbGQpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShrZXlDaGlsZFBhaXJzKSkge1xuICAgICAgICAgICAgZm9yIChsZXQgW2tleSwgY2hpbGRdIG9mIGtleUNoaWxkUGFpcnMpIHtcbiAgICAgICAgICAgICAgICBfY2FjaGVBcHBlbmQoa2V5LCBjaGlsZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBmb3IgKGxldCBba2V5LCBjaGlsZF0gb2YgZW51bWVyYXRlKGtleUNoaWxkUGFpcnMpKSB7XG4gICAgICAgICAgICAgICAgX2NhY2hlQXBwZW5kKGtleSwgY2hpbGQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIF9jbHMoKSB7XG4gICAgICAgIHJldHVybiBCZXR0ZXJIVE1MRWxlbWVudFxuICAgIH1cblxuICAgIGNoaWxkKHNlbGVjdG9yOiBcImltZ1wiKTogSW1nO1xuXG4gICAgY2hpbGQoc2VsZWN0b3I6IFwiYVwiKTogQW5jaG9yO1xuXG4gICAgY2hpbGQ8VElucHV0VHlwZSBleHRlbmRzIElucHV0VHlwZSA9IElucHV0VHlwZT4oc2VsZWN0b3I6IFwiaW5wdXRcIik6IElucHV0PFRJbnB1dFR5cGUsIEhUTUxJbnB1dEVsZW1lbnQ+O1xuICAgIGNoaWxkKHNlbGVjdG9yOiBcInNlbGVjdFwiKTogSW5wdXQ8dW5kZWZpbmVkLCBIVE1MU2VsZWN0RWxlbWVudD47XG5cbiAgICBjaGlsZChzZWxlY3RvcjogXCJwXCIpOiBQYXJhZ3JhcGg7XG5cbiAgICBjaGlsZChzZWxlY3RvcjogXCJzcGFuXCIpOiBTcGFuO1xuXG4gICAgY2hpbGQoc2VsZWN0b3I6IFwiYnV0dG9uXCIpOiBCdXR0b247XG5cbiAgICBjaGlsZChzZWxlY3RvcjogXCJkaXZcIik6IERpdjtcblxuICAgIGNoaWxkPFQgZXh0ZW5kcyBUYWc+KHNlbGVjdG9yOiBUKTogQmV0dGVySFRNTEVsZW1lbnQ8SFRNTEVsZW1lbnRUYWdOYW1lTWFwW1RdPjtcblxuICAgIGNoaWxkKHNlbGVjdG9yOiBzdHJpbmcpOiBCZXR0ZXJIVE1MRWxlbWVudDtcblxuICAgIGNoaWxkPFQgZXh0ZW5kcyB0eXBlb2YgQmV0dGVySFRNTEVsZW1lbnQ+KHNlbGVjdG9yOiBzdHJpbmcsIGJoZUNsczogVCk6IFQ7XG5cbiAgICBjaGlsZChzZWxlY3RvciwgYmhlQ2xzPykge1xuICAgICAgICBjb25zdCBodG1sRWxlbWVudCA9IHRoaXMuX2h0bWxFbGVtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpIGFzIEhUTUxFbGVtZW50O1xuICAgICAgICBpZiAoaHRtbEVsZW1lbnQgPT09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgJHt0aGlzfS5jaGlsZCgke3NlbGVjdG9yfSk6IG5vIGNoaWxkLiByZXR1cm5pbmcgdW5kZWZpbmVkYCk7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGxldCBiaGU7XG4gICAgICAgIGlmIChiaGVDbHMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgYmhlID0gdGhpcy5fY2xzKCkud3JhcFdpdGhCSEUoaHRtbEVsZW1lbnQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYmhlID0gbmV3IGJoZUNscyh7IGh0bWxFbGVtZW50IH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBiaGU7XG4gICAgfVxuXG4gICAgLyoqUmV0dXJuIGEgYEJldHRlckhUTUxFbGVtZW50YCBsaXN0IG9mIGFsbCBjaGlsZHJlbiAqL1xuICAgIGNoaWxkcmVuKCk6IEJldHRlckhUTUxFbGVtZW50W107XG5cbiAgICAvKipSZXR1cm4gYSBgQmV0dGVySFRNTEVsZW1lbnRgIGxpc3Qgb2YgYWxsIGNoaWxkcmVuIHNlbGVjdGVkIGJ5IGBzZWxlY3RvcmAgKi9cbiAgICBjaGlsZHJlbjxLIGV4dGVuZHMgVGFnPihzZWxlY3RvcjogSyk6IEJldHRlckhUTUxFbGVtZW50W107XG5cbiAgICAvKipSZXR1cm4gYSBgQmV0dGVySFRNTEVsZW1lbnRgIGxpc3Qgb2YgYWxsIGNoaWxkcmVuIHNlbGVjdGVkIGJ5IGBzZWxlY3RvcmAgKi9cbiAgICBjaGlsZHJlbihzZWxlY3RvcjogUXVlcnlTZWxlY3Rvcik6IEJldHRlckhUTUxFbGVtZW50W107XG5cbiAgICBjaGlsZHJlbihzZWxlY3Rvcj8pIHtcbiAgICAgICAgbGV0IGNoaWxkcmVuVmFuaWxsYTtcbiAgICAgICAgbGV0IGNoaWxkcmVuQ29sbGVjdGlvbjtcbiAgICAgICAgaWYgKHNlbGVjdG9yID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGNoaWxkcmVuQ29sbGVjdGlvbiA9IHRoaXMuX2h0bWxFbGVtZW50LmNoaWxkcmVuO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2hpbGRyZW5Db2xsZWN0aW9uID0gdGhpcy5faHRtbEVsZW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWxlY3Rvcik7XG4gICAgICAgIH1cblxuICAgICAgICBjaGlsZHJlblZhbmlsbGEgPSBBcnJheS5mcm9tKGNoaWxkcmVuQ29sbGVjdGlvbik7XG5cbiAgICAgICAgcmV0dXJuIGNoaWxkcmVuVmFuaWxsYS5tYXAodGhpcy5fY2xzKCkud3JhcFdpdGhCSEUpO1xuICAgIH1cblxuICAgIGNsb25lKGRlZXA/OiBib29sZWFuKTogQmV0dGVySFRNTEVsZW1lbnQge1xuICAgICAgICBjb25zb2xlLndhcm4oYCR7dGhpc30uY2xvbmUoKSBkb2VzbnQgcmV0dXJuIGEgbWF0Y2hpbmcgQkhFIHN1YnR5cGUsIGJ1dCBhIHJlZ3VsYXIgQkhFYCk7XG4gICAgICAgIC8vIFRPRE86IHJldHVybiBuZXcgdGhpcygpP1xuICAgICAgICByZXR1cm4gbmV3IEJldHRlckhUTUxFbGVtZW50KHsgaHRtbEVsZW1lbnQ6IHRoaXMuX2h0bWxFbGVtZW50LmNsb25lTm9kZShkZWVwKSBhcyBIVE1MRWxlbWVudCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdG9yZXMgY2hpbGQgQkhFJ3MgaW4gYHRoaXNgIHNvIHRoZXkgY2FuIGJlIGFjY2Vzc2VkIGUuZy4gYG5hdmJhci5ob21lLmNsYXNzKCdzZWxlY3RlZCcpYC5cbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIG5hdmJhci5jYWNoZUNoaWxkcmVuKHsgJ2hvbWUnOiAnYnV0dG9uLmhvbWUnIH0pXG4gICAgICogLy8gb3JcbiAgICAgKiBtYWluZGl2LmNhY2hlQ2hpbGRyZW4oeyAnd2VsY29tZSc6IHBhcmFncmFwaCh7ICdxdWVyeSc6ICdwLndlbGNvbWUnIH0pIH0pXG4gICAgICogLy8gYGNoaWxkcmVuT2JqYCBjYW4gYmUgcmVjdXJzaXZlIGFuZCBtaXhlZCwgZS5nLlxuICAgICAqIG5hdmJhci5jYWNoZUNoaWxkcmVuKHtcbiAgICAgKiAgICAgIGhvbWU6IHtcbiAgICAgKiAgICAgICAgICAnbGkubmF2YmFyLWl0ZW0taG9tZSc6IHtcbiAgICAgKiAgICAgICAgICAgICAgdGh1bWJuYWlsOiAnaW1nLmhvbWUtdGh1bWJuYWlsJyxcbiAgICAgKiAgICAgICAgICAgICAgZXhwYW5kOiBidXR0b24oeyBieWlkOiAnaG9tZV9leHBhbmQnIH0pXG4gICAgICogICAgICAgICAgfVxuICAgICAqICAgICAgfVxuICAgICAqICB9KTtcbiAgICAgKiBuYXZiYXIuaG9tZS5jbGFzcyhcInNlbGVjdGVkXCIpO1xuICAgICAqIG5hdmJhci5ob21lLnRodW1ibmFpbC5jc3MoLi4uKTtcbiAgICAgKiBuYXZiYXIuaG9tZS5leHBhbmQuY2xpY2soIGUgPT4gey4uLn0gKVxuICAgICAqIEBzZWUgdGhpcy5jaGlsZCovXG4gICAgY2FjaGVDaGlsZHJlbihjaGlsZHJlbk9iajogQ2hpbGRyZW5PYmopOiB0aGlzIHtcbiAgICAgICAgZm9yIChsZXQgW2tleSwgdmFsdWVdIG9mIGVudW1lcmF0ZShjaGlsZHJlbk9iaikpIHtcbiAgICAgICAgICAgIGxldCB0eXBlID0gdHlwZW9mIHZhbHVlO1xuICAgICAgICAgICAgaWYgKGlzT2JqZWN0KHZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEJldHRlckhUTUxFbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIHsgXCJteWltZ1wiOiBpbWcoLi4uKSB9XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhY2hlKGtleSwgdmFsdWUpXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLy8geyBcIm15ZGl2XCI6IHsgXCJteWltZ1wiOiBpbWcoLi4uKSwgXCJteWlucHV0XCI6IGlucHV0KC4uLikgfSB9XG4gICAgICAgICAgICAgICAgICAgIGxldCBlbnRyaWVzID0gT2JqZWN0LmVudHJpZXModmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZW50cmllc1sxXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYGNhY2hlQ2hpbGRyZW4oKSByZWNlaXZlZCByZWN1cnNpdmUgb2JqIHdpdGggbW9yZSB0aGFuIDEgc2VsZWN0b3IgZm9yIGEga2V5LiBVc2luZyBvbmx5IDB0aCBzZWxlY3RvcmAsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIm11bHRpcGxlIHNlbGVjdG9yc1wiOiBlbnRyaWVzLm1hcChlID0+IGVbMF0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpczogdGhpc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbGV0IFtzZWxlY3Rvciwgb2JqXSA9IGVudHJpZXNbMF07XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0Z1bmN0aW9uKG9iaikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGJoZSBjb25zdHJ1Y3RvclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJoZSA9IHRoaXMuY2hpbGQoc2VsZWN0b3IsIG9iaik7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZShrZXksIGJoZSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZShrZXksIHRoaXMuY2hpbGQoc2VsZWN0b3IpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5XS5jYWNoZUNoaWxkcmVuKG9iaik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgICAgICBsZXQgbWF0Y2ggPSAvPChcXHcrKT4kLy5leGVjKHZhbHVlIGFzIHN0cmluZyk7XG5cbiAgICAgICAgICAgICAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8geyBcIm9wdGlvbnNcIjogXCI8b3B0aW9uPlwiIH1cbiAgICAgICAgICAgICAgICAgICAgbGV0IHRhZ05hbWUgPSBtYXRjaFsxXSBhcyBUYWc7XG4gICAgICAgICAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaHRtbEVsZW1lbnRzID0gWy4uLnRoaXMuX2h0bWxFbGVtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKHRhZ05hbWUpXSBhcyBIVE1MRWxlbWVudFRhZ05hbWVNYXBbdHlwZW9mIHRhZ05hbWVdW107XG4gICAgICAgICAgICAgICAgICAgIGxldCBiaGVzID0gW107XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGh0bWxFbGVtZW50IG9mIGh0bWxFbGVtZW50cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgYmhlcy5wdXNoKHRoaXMuX2NscygpLndyYXBXaXRoQkhFKGh0bWxFbGVtZW50KSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2FjaGUoa2V5LCBiaGVzKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAvLyB7IFwibXlpbnB1dFwiOiBcImlucHV0W3R5cGU9Y2hlY2tib3hdXCIgfVxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZShrZXksIHRoaXMuY2hpbGQodmFsdWUgYXMgVGFnT3JTdHJpbmcpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgY2FjaGVDaGlsZHJlbiwgYmFkIHZhbHVlIHR5cGU6IFwiJHt0eXBlfVwiLiBrZXk6IFwiJHtrZXl9XCIsIHZhbHVlOiBcIiR7dmFsdWV9XCIuIGNoaWxkcmVuT2JqOmAsIGNoaWxkcmVuT2JqLCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG5cbiAgICB9XG5cbiAgICAvKipSZW1vdmUgYWxsIGNoaWxkcmVuIGZyb20gRE9NKi9cbiAgICBlbXB0eSgpOiB0aGlzIHtcbiAgICAgICAgd2hpbGUgKHRoaXMuX2h0bWxFbGVtZW50LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LnJlbW92ZUNoaWxkKHRoaXMuX2h0bWxFbGVtZW50LmZpcnN0Q2hpbGQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8qKlJlbW92ZSBlbGVtZW50IGZyb20gRE9NKi9cbiAgICByZW1vdmUoKTogdGhpcyB7XG4gICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LnJlbW92ZSgpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cblxuICAgIC8vICoqKiBFdmVudHNcbiAgICBvbihldlR5cGVGblBhaXJzOiBUTWFwPEV2ZW50TmFtZTJGdW5jdGlvbj4sIG9wdGlvbnM/OiBBZGRFdmVudExpc3RlbmVyT3B0aW9ucyk6IHRoaXMge1xuICAgICAgICAvLyBjb25zdCBmb28gPSBldlR5cGVGblBhaXJzW1wiYWJvcnRcIl07XG4gICAgICAgIGZvciAobGV0IFtldlR5cGUsIGV2Rm5dIG9mIGVudW1lcmF0ZShldlR5cGVGblBhaXJzKSkge1xuICAgICAgICAgICAgY29uc3QgX2YgPSBmdW5jdGlvbiBfZihldnQpIHtcbiAgICAgICAgICAgICAgICBldkZuKGV2dCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihldlR5cGUsIF9mLCBvcHRpb25zKTtcbiAgICAgICAgICAgIHRoaXMuX2xpc3RlbmVyc1tldlR5cGVdID0gX2Y7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgLypcbiAgICBDaHJvbm9sb2d5OlxuXHRtb3VzZWRvd24gICB0b3VjaHN0YXJ0XHRwb2ludGVyZG93blxuXHRtb3VzZWVudGVyXHRcdCAgICAgICAgcG9pbnRlcmVudGVyXG5cdG1vdXNlbGVhdmVcdFx0ICAgICAgICBwb2ludGVybGVhdmVcblx0bW91c2Vtb3ZlXHR0b3VjaG1vdmVcdHBvaW50ZXJtb3ZlXG5cdG1vdXNlb3V0XHRcdCAgICAgICAgcG9pbnRlcm91dFxuXHRtb3VzZW92ZXJcdFx0ICAgICAgICBwb2ludGVyb3ZlclxuXHRtb3VzZXVwXHQgICAgdG91Y2hlbmQgICAgcG9pbnRlcnVwXG5cdCovXG4gICAgLyoqIEFkZCBhIGB0b3VjaHN0YXJ0YCBldmVudCBsaXN0ZW5lci4gVGhpcyBpcyB0aGUgZmFzdCBhbHRlcm5hdGl2ZSB0byBgY2xpY2tgIGxpc3RlbmVycyBmb3IgbW9iaWxlIChubyAzMDBtcyB3YWl0KS4gKi9cbiAgICB0b3VjaHN0YXJ0KGZuOiAoZXY6IFRvdWNoRXZlbnQpID0+IGFueSwgb3B0aW9ucz86IEFkZEV2ZW50TGlzdGVuZXJPcHRpb25zKTogdGhpcyB7XG4gICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBmdW5jdGlvbiBfZihldjogVG91Y2hFdmVudCkge1xuICAgICAgICAgICAgZXYucHJldmVudERlZmF1bHQoKTsgLy8gb3RoZXJ3aXNlIFwidG91Y2htb3ZlXCIgaXMgdHJpZ2dlcmVkXG4gICAgICAgICAgICBmbihldik7XG4gICAgICAgICAgICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLm9uY2UpIC8vIFRPRE86IG1heWJlIG5hdGl2ZSBvcHRpb25zLm9uY2UgaXMgZW5vdWdoXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGhpcy5yZW1vdmVFdmVudExpc3RlbmVyKCd0b3VjaHN0YXJ0JywgX2YpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LCBvcHRpb25zKTtcbiAgICAgICAgLy8gVE9ETzogdGhpcy5fbGlzdGVuZXJzLCBvciB1c2UgdGhpcy5vbihcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgLyoqIEFkZCBhIGBwb2ludGVyZG93bmAgZXZlbnQgbGlzdGVuZXIgaWYgYnJvd3NlciBzdXBwb3J0cyBgcG9pbnRlcmRvd25gLCBlbHNlIHNlbmQgYG1vdXNlZG93bmAgKHNhZmFyaSkuICovXG4gICAgcG9pbnRlcmRvd24oZm46IChldmVudDogUG9pbnRlckV2ZW50IHwgTW91c2VFdmVudCkgPT4gYW55LCBvcHRpb25zPzogQWRkRXZlbnRMaXN0ZW5lck9wdGlvbnMpOiB0aGlzIHtcblxuICAgICAgICBsZXQgYWN0aW9uO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gVE9ETzogY2hlY2sgaWYgUG9pbnRlckV2ZW50IGV4aXN0cyBpbnN0ZWFkIG9mIHRyeS9jYXRjaFxuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICAgICAgYWN0aW9uID0gd2luZG93LlBvaW50ZXJFdmVudCA/ICdwb2ludGVyZG93bicgOiAnbW91c2Vkb3duJzsgLy8gc2FmYXJpIGRvZXNuJ3Qgc3VwcG9ydCBwb2ludGVyZG93blxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBhY3Rpb24gPSAnbW91c2Vkb3duJ1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IF9mID0gZnVuY3Rpb24gX2YoZXY6IFBvaW50ZXJFdmVudCB8IE1vdXNlRXZlbnQpOiB2b2lkIHtcbiAgICAgICAgICAgIGV2LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICBmbihldik7XG4gICAgICAgICAgICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLm9uY2UpIC8vIFRPRE86IG1heWJlIG5hdGl2ZSBvcHRpb25zLm9uY2UgaXMgZW5vdWdoXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGhpcy5yZW1vdmVFdmVudExpc3RlbmVyKGFjdGlvbiwgX2YpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5hZGRFdmVudExpc3RlbmVyKGFjdGlvbiwgX2YsIG9wdGlvbnMpO1xuICAgICAgICB0aGlzLl9saXN0ZW5lcnMucG9pbnRlcmRvd24gPSBfZjtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgLyoqU2ltdWxhdGUgYSBjbGljayBvZiB0aGUgZWxlbWVudC4gVXNlZnVsIGZvciBgPGE+YCBlbGVtZW50cy4qL1xuICAgIGNsaWNrKCk6IHRoaXM7XG5cbiAgICAvKipBZGQgYSBgY2xpY2tgIGV2ZW50IGxpc3RlbmVyLiBZb3Ugc2hvdWxkIHByb2JhYmx5IHVzZSBgcG9pbnRlcmRvd24oKWAgaWYgb24gZGVza3RvcCwgb3IgYHRvdWNoc3RhcnQoKWAgaWYgb24gbW9iaWxlLiovXG4gICAgY2xpY2soZm46IChldmVudDogTW91c2VFdmVudCkgPT4gYW55LCBvcHRpb25zPzogQWRkRXZlbnRMaXN0ZW5lck9wdGlvbnMpOiB0aGlzO1xuXG4gICAgY2xpY2soZm4/LCBvcHRpb25zPykge1xuICAgICAgICBpZiAoZm4gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuY2xpY2soKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMub24oeyBjbGljazogZm4gfSwgb3B0aW9ucyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipCbHVyICh1bmZvY3VzKSB0aGUgZWxlbWVudC4qL1xuICAgIGJsdXIoKTogdGhpcztcblxuICAgIC8qKkFkZCBhIGBibHVyYCBldmVudCBsaXN0ZW5lciovXG4gICAgYmx1cihmbjogKGV2ZW50OiBGb2N1c0V2ZW50KSA9PiBhbnksIG9wdGlvbnM/OiBBZGRFdmVudExpc3RlbmVyT3B0aW9ucyk6IHRoaXM7XG5cbiAgICBibHVyKGZuPywgb3B0aW9ucz8pIHtcbiAgICAgICAgaWYgKGZuID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmJsdXIoKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMub24oeyBibHVyOiBmbiB9LCBvcHRpb25zKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqRm9jdXMgdGhlIGVsZW1lbnQuKi9cbiAgICBmb2N1cygpOiB0aGlzO1xuXG4gICAgLyoqQWRkIGEgYGZvY3VzYCBldmVudCBsaXN0ZW5lciovXG4gICAgZm9jdXMoZm46IChldmVudDogRm9jdXNFdmVudCkgPT4gYW55LCBvcHRpb25zPzogQWRkRXZlbnRMaXN0ZW5lck9wdGlvbnMpOiB0aGlzO1xuXG4gICAgZm9jdXMoZm4/LCBvcHRpb25zPykge1xuICAgICAgICBpZiAoZm4gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuZm9jdXMoKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMub24oeyBmb2N1czogZm4gfSwgb3B0aW9ucylcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKkFkZCBhIGBjaGFuZ2VgIGV2ZW50IGxpc3RlbmVyKi9cbiAgICBjaGFuZ2UoZm46IChldmVudDogRXZlbnQpID0+IGFueSwgb3B0aW9ucz86IEFkZEV2ZW50TGlzdGVuZXJPcHRpb25zKTogdGhpcyB7XG4gICAgICAgIHJldHVybiB0aGlzLm9uKHsgY2hhbmdlOiBmbiB9LCBvcHRpb25zKTtcbiAgICB9XG5cbiAgICAvKipBZGQgYSBgY29udGV4dG1lbnVgIGV2ZW50IGxpc3RlbmVyKi9cbiAgICBjb250ZXh0bWVudShmbjogKGV2ZW50OiBNb3VzZUV2ZW50KSA9PiBhbnksIG9wdGlvbnM/OiBBZGRFdmVudExpc3RlbmVyT3B0aW9ucyk6IHRoaXMge1xuICAgICAgICByZXR1cm4gdGhpcy5vbih7IGNvbnRleHRtZW51OiBmbiB9LCBvcHRpb25zKTtcbiAgICB9XG5cbiAgICAvKipTaW11bGF0ZSBhIGRvdWJsZSBjbGljayBvZiB0aGUgZWxlbWVudC4qL1xuICAgIGRibGNsaWNrKCk6IHRoaXM7XG5cbiAgICAvKipBZGQgYSBgZGJsY2xpY2tgIGV2ZW50IGxpc3RlbmVyKi9cbiAgICBkYmxjbGljayhmbjogKGV2ZW50OiBNb3VzZUV2ZW50KSA9PiBhbnksIG9wdGlvbnM/OiBBZGRFdmVudExpc3RlbmVyT3B0aW9ucyk6IHRoaXM7XG5cbiAgICBkYmxjbGljayhmbj8sIG9wdGlvbnM/KSB7XG4gICAgICAgIGlmIChmbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBjb25zdCBkYmxjbGljayA9IG5ldyBNb3VzZUV2ZW50KCdkYmxjbGljaycsIHtcbiAgICAgICAgICAgICAgICAndmlldyc6IHdpbmRvdyxcbiAgICAgICAgICAgICAgICAnYnViYmxlcyc6IHRydWUsXG4gICAgICAgICAgICAgICAgJ2NhbmNlbGFibGUnOiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmRpc3BhdGNoRXZlbnQoZGJsY2xpY2spO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5vbih7IGRibGNsaWNrOiBmbiB9LCBvcHRpb25zKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqU2ltdWxhdGUgYSBtb3VzZWVudGVyIGV2ZW50IHRvIHRoZSBlbGVtZW50LiovXG4gICAgbW91c2VlbnRlcigpOiB0aGlzO1xuXG4gICAgLyoqQWRkIGEgYG1vdXNlZW50ZXJgIGV2ZW50IGxpc3RlbmVyKi9cbiAgICBtb3VzZWVudGVyKGZuOiAoZXZlbnQ6IE1vdXNlRXZlbnQpID0+IGFueSwgb3B0aW9ucz86IEFkZEV2ZW50TGlzdGVuZXJPcHRpb25zKTogdGhpcztcblxuICAgIG1vdXNlZW50ZXIoZm4/LCBvcHRpb25zPykge1xuICAgICAgICAvLyBtb3VzZW92ZXI6IGFsc28gY2hpbGQgZWxlbWVudHNcbiAgICAgICAgLy8gbW91c2VlbnRlcjogb25seSBib3VuZCBlbGVtZW50XG5cbiAgICAgICAgaWYgKGZuID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IG1vdXNlZW50ZXIgPSBuZXcgTW91c2VFdmVudCgnbW91c2VlbnRlcicsIHtcbiAgICAgICAgICAgICAgICAndmlldyc6IHdpbmRvdyxcbiAgICAgICAgICAgICAgICAnYnViYmxlcyc6IHRydWUsXG4gICAgICAgICAgICAgICAgJ2NhbmNlbGFibGUnOiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmRpc3BhdGNoRXZlbnQobW91c2VlbnRlcik7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm9uKHsgbW91c2VlbnRlcjogZm4gfSwgb3B0aW9ucylcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKkFkZCBhIGBrZXlkb3duYCBldmVudCBsaXN0ZW5lciovXG4gICAga2V5ZG93bihmbjogKGV2ZW50OiBLZXlib2FyZEV2ZW50KSA9PiBhbnksIG9wdGlvbnM/OiBBZGRFdmVudExpc3RlbmVyT3B0aW9ucyk6IHRoaXMge1xuICAgICAgICByZXR1cm4gdGhpcy5vbih7IGtleWRvd246IGZuIH0sIG9wdGlvbnMpXG4gICAgfVxuXG4gICAgLyoqQWRkIGEgYG1vdXNlb3V0YCBldmVudCBsaXN0ZW5lciovXG4gICAgbW91c2VvdXQoZm46IChldmVudDogTW91c2VFdmVudCkgPT4gYW55LCBvcHRpb25zPzogQWRkRXZlbnRMaXN0ZW5lck9wdGlvbnMpOiB0aGlzIHtcbiAgICAgICAgLy9tb3VzZWxlYXZlIGFuZCBtb3VzZW91dCBhcmUgc2ltaWxhciBidXQgZGlmZmVyIGluIHRoYXQgbW91c2VsZWF2ZSBkb2VzIG5vdCBidWJibGUgYW5kIG1vdXNlb3V0IGRvZXMuXG4gICAgICAgIC8vIFRoaXMgbWVhbnMgdGhhdCBtb3VzZWxlYXZlIGlzIGZpcmVkIHdoZW4gdGhlIHBvaW50ZXIgaGFzIGV4aXRlZCB0aGUgZWxlbWVudCBhbmQgYWxsIG9mIGl0cyBkZXNjZW5kYW50cyxcbiAgICAgICAgLy8gd2hlcmVhcyBtb3VzZW91dCBpcyBmaXJlZCB3aGVuIHRoZSBwb2ludGVyIGxlYXZlcyB0aGUgZWxlbWVudCBvciBsZWF2ZXMgb25lIG9mIHRoZSBlbGVtZW50J3MgZGVzY2VuZGFudHNcbiAgICAgICAgLy8gKGV2ZW4gaWYgdGhlIHBvaW50ZXIgaXMgc3RpbGwgd2l0aGluIHRoZSBlbGVtZW50KS5cbiAgICAgICAgcmV0dXJuIHRoaXMub24oeyBtb3VzZW91dDogZm4gfSwgb3B0aW9ucylcbiAgICB9XG5cbiAgICAvKipBZGQgYSBgbW91c2VvdmVyYCBldmVudCBsaXN0ZW5lciovXG4gICAgbW91c2VvdmVyKGZuOiAoZXZlbnQ6IE1vdXNlRXZlbnQpID0+IHZvaWQsIG9wdGlvbnM/OiBBZGRFdmVudExpc3RlbmVyT3B0aW9ucyk6IHRoaXMge1xuICAgICAgICAvLyBtb3VzZW92ZXI6IGFsc28gY2hpbGQgZWxlbWVudHNcbiAgICAgICAgLy8gbW91c2VlbnRlcjogb25seSBib3VuZCBlbGVtZW50XG4gICAgICAgIC8vIHJldHVybiB0aGlzLm9uKHttb3VzZW92ZXI6IGZufSwgb3B0aW9ucylcbiAgICAgICAgcmV0dXJuIHRoaXMub24oeyBtb3VzZW92ZXI6IGZuIH0pXG4gICAgfVxuXG4gICAgLyoqIFJlbW92ZSB0aGUgZXZlbnQgbGlzdGVuZXIgb2YgYGV2ZW50YCwgaWYgZXhpc3RzLiovXG4gICAgb2ZmKGV2ZW50OiBFdmVudE5hbWUpOiB0aGlzIHtcbiAgICAgICAgLy8gVE9ETzogU2hvdWxkIHJlbW92ZSBsaXN0ZW5lciBmcm9tIHRoaXMuX2xpc3RlbmVycz9cbiAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudCwgdGhpcy5fbGlzdGVuZXJzW2V2ZW50XSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8qKiBSZW1vdmUgYWxsIGV2ZW50IGxpc3RlbmVycyBpbiBgX2xpc3RlbmVyc2AqL1xuICAgIGFsbE9mZigpOiB0aGlzIHtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IE9iamVjdC5rZXlzKHRoaXMuX2xpc3RlbmVycykubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxldCBldmVudCA9IHRoaXMuX2xpc3RlbmVyc1tpXTtcbiAgICAgICAgICAgIHRoaXMub2ZmKGV2ZW50KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8qKiBGb3IgZWFjaCBgW2F0dHIsIHZhbF1gIHBhaXIsIGFwcGx5IGBzZXRBdHRyaWJ1dGVgKi9cbiAgICBhdHRyKGF0dHJWYWxQYWlyczogVE1hcDxzdHJpbmcgfCBib29sZWFuPik6IHRoaXNcblxuICAgIC8vICoqKiBBdHRyaWJ1dGVzXG5cbiAgICAvKiogYXBwbHkgYGdldEF0dHJpYnV0ZWAqL1xuICAgIGF0dHIoYXR0cmlidXRlTmFtZTogc3RyaW5nKTogc3RyaW5nXG5cbiAgICBhdHRyKGF0dHJWYWxQYWlycykge1xuICAgICAgICBpZiAodHlwZW9mIGF0dHJWYWxQYWlycyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9odG1sRWxlbWVudC5nZXRBdHRyaWJ1dGUoYXR0clZhbFBhaXJzKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGZvciAobGV0IFthdHRyLCB2YWxdIG9mIGVudW1lcmF0ZShhdHRyVmFsUGFpcnMpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuc2V0QXR0cmlidXRlKGF0dHIsIHZhbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKiBgcmVtb3ZlQXR0cmlidXRlYCAqL1xuICAgIHJlbW92ZUF0dHIocXVhbGlmaWVkTmFtZTogc3RyaW5nLCAuLi5xdWFsaWZpZWROYW1lczogc3RyaW5nW10pOiB0aGlzIHtcbiAgICAgICAgbGV0IF9yZW1vdmVBdHRyaWJ1dGU7XG4gICAgICAgIGlmICh0aGlzLl9pc1N2Zykge1xuICAgICAgICAgICAgX3JlbW92ZUF0dHJpYnV0ZSA9IChxdWFsaWZpZWROYW1lKSA9PiB0aGlzLl9odG1sRWxlbWVudC5yZW1vdmVBdHRyaWJ1dGVOUyhTVkdfTlNfVVJJLCBxdWFsaWZpZWROYW1lKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIF9yZW1vdmVBdHRyaWJ1dGUgPSAocXVhbGlmaWVkTmFtZSkgPT4gdGhpcy5faHRtbEVsZW1lbnQucmVtb3ZlQXR0cmlidXRlKHF1YWxpZmllZE5hbWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgX3JlbW92ZUF0dHJpYnV0ZShxdWFsaWZpZWROYW1lKTtcbiAgICAgICAgZm9yIChsZXQgcW4gb2YgcXVhbGlmaWVkTmFtZXMpIHtcbiAgICAgICAgICAgIF9yZW1vdmVBdHRyaWJ1dGUocW4pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8qKmBnZXRBdHRyaWJ1dGUoYGRhdGEtJHtrZXl9YClgLiBKU09OLnBhcnNlIGl0IGJ5IGRlZmF1bHQuKi9cbiAgICBnZXRkYXRhKGtleTogc3RyaW5nLCBwYXJzZTogYm9vbGVhbiA9IHRydWUpOiBzdHJpbmcgfCBUTWFwPHN0cmluZz4ge1xuICAgICAgICAvLyBUT0RPOiBqcXVlcnkgZG9lc24ndCBhZmZlY3QgZGF0YS0qIGF0dHJzIGluIERPTS4gaHR0cHM6Ly9hcGkuanF1ZXJ5LmNvbS9kYXRhL1xuICAgICAgICBjb25zdCBkYXRhID0gdGhpcy5faHRtbEVsZW1lbnQuZ2V0QXR0cmlidXRlKGBkYXRhLSR7a2V5fWApO1xuICAgICAgICBpZiAocGFyc2UgPT09IHRydWUpIHtcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKGRhdGEpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIGRhdGFcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgX2NhY2hlKGtleSwgY2hpbGQ6IEJldHRlckhUTUxFbGVtZW50IHwgQmV0dGVySFRNTEVsZW1lbnRbXSk6IHZvaWQge1xuICAgICAgICBjb25zdCBvbGRjaGlsZCA9IHRoaXMuX2NhY2hlZENoaWxkcmVuW2tleV07XG4gICAgICAgIGlmIChvbGRjaGlsZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYE92ZXJ3cml0aW5nIHRoaXMuX2NhY2hlZENoaWxkcmVuWyR7a2V5fV0hYCwgYG9sZCBjaGlsZDogJHtvbGRjaGlsZH1gLFxuICAgICAgICAgICAgICAgIGBuZXcgY2hpbGQ6ICR7Y2hpbGR9YCwgYGFyZSB0aGV5IGRpZmZlcmVudD86ICR7b2xkY2hpbGQgPT0gY2hpbGR9YFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzW2tleV0gPSBjaGlsZDtcbiAgICAgICAgdGhpcy5fY2FjaGVkQ2hpbGRyZW5ba2V5XSA9IGNoaWxkO1xuICAgIH1cblxuXG59XG5cbmV4cG9ydCBjbGFzcyBEaXY8USBleHRlbmRzIFF1ZXJ5U2VsZWN0b3IgPSBRdWVyeVNlbGVjdG9yPiBleHRlbmRzIEJldHRlckhUTUxFbGVtZW50PEhUTUxEaXZFbGVtZW50PiB7XG4gICAgLyoqQ3JlYXRlIGEgSFRNTERpdkVsZW1lbnQuIE9wdGlvbmFsbHksIHNldCBpdHMgYHRleHRgLCBgY2xzYCBvciBgaWRgLiAqL1xuICAgIGNvbnN0cnVjdG9yKHsgY2xzLCBzZXRpZCwgdGV4dCB9OiB7IGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsIHRleHQ/OiBzdHJpbmcgfSk7XG4gICAgLyoqQ3JlYXRlIGEgSFRNTERpdkVsZW1lbnQuIE9wdGlvbmFsbHksIHNldCBpdHMgYGh0bWxgLCBgY2xzYCBvciBgaWRgLiAqL1xuICAgIGNvbnN0cnVjdG9yKHsgY2xzLCBzZXRpZCwgaHRtbCB9OiB7IGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsIGh0bWw/OiBzdHJpbmcgfSk7XG4gICAgLyoqV3JhcCBhbiBleGlzdGluZyBlbGVtZW50IGJ5IGBieWlkYC4gT3B0aW9uYWxseSBjYWNoZSBleGlzdGluZyBgY2hpbGRyZW5gKi9cbiAgICBjb25zdHJ1Y3Rvcih7IGJ5aWQsIGNoaWxkcmVuIH06IHsgYnlpZDogc3RyaW5nLCBjaGlsZHJlbj86IENoaWxkcmVuT2JqIH0pO1xuICAgIC8qKldyYXAgYW4gZXhpc3RpbmcgZWxlbWVudCBieSBgcXVlcnlgLiBPcHRpb25hbGx5IGNhY2hlIGV4aXN0aW5nIGBjaGlsZHJlbmAqL1xuICAgIGNvbnN0cnVjdG9yKHsgcXVlcnksIGNoaWxkcmVuIH06IHsgcXVlcnk6IFF1ZXJ5T3JQcmVjaXNlVGFnPFEsIFwiZGl2XCI+LCBjaGlsZHJlbj86IENoaWxkcmVuT2JqIH0pO1xuICAgIC8qKldyYXAgYW4gZXhpc3RpbmcgSFRNTEVsZW1lbnQuIE9wdGlvbmFsbHkgY2FjaGUgZXhpc3RpbmcgYGNoaWxkcmVuYCovXG4gICAgY29uc3RydWN0b3IoeyBodG1sRWxlbWVudCwgY2hpbGRyZW4gfTogeyBodG1sRWxlbWVudDogSFRNTERpdkVsZW1lbnQ7IGNoaWxkcmVuPzogQ2hpbGRyZW5PYmogfSk7XG4gICAgY29uc3RydWN0b3IoZGl2T3B0cykge1xuICAgICAgICBjb25zdCB7IHNldGlkLCBjbHMsIHRleHQsIGh0bWwsIGJ5aWQsIHF1ZXJ5LCBodG1sRWxlbWVudCwgY2hpbGRyZW4gfSA9IGRpdk9wdHM7XG4gICAgICAgIGlmICh0ZXh0ICE9PSB1bmRlZmluZWQgJiYgaHRtbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTXV0dWFsbHlFeGNsdXNpdmVBcmdzKHsgdGV4dCwgaHRtbCB9KVxuICAgICAgICB9XG4gICAgICAgIGlmIChodG1sRWxlbWVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzdXBlcih7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChieWlkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHN1cGVyKHsgYnlpZCwgY2hpbGRyZW4gfSk7XG4gICAgICAgIH0gZWxzZSBpZiAocXVlcnkgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc3VwZXIoeyBxdWVyeSwgY2hpbGRyZW4gfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzdXBlcih7IHRhZzogXCJkaXZcIiwgc2V0aWQsIGNscywgaHRtbCB9KTtcbiAgICAgICAgICAgIGlmICh0ZXh0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRleHQodGV4dCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgfVxuICAgIH1cblxufVxuXG5leHBvcnQgY2xhc3MgUGFyYWdyYXBoIGV4dGVuZHMgQmV0dGVySFRNTEVsZW1lbnQ8SFRNTFBhcmFncmFwaEVsZW1lbnQ+IHtcblxuICAgIGNvbnN0cnVjdG9yKHBPcHRzKSB7XG4gICAgICAgIC8vIGlmIChub1ZhbHVlKGFyZ3VtZW50c1swXSkpIHtcbiAgICAgICAgLy8gICAgIHRocm93IG5ldyBOb3RFbm91Z2hBcmdzKFsxXSwgYXJndW1lbnRzWzBdKVxuICAgICAgICAvLyB9XG4gICAgICAgIGNvbnN0IHsgc2V0aWQsIGNscywgdGV4dCwgaHRtbCwgYnlpZCwgcXVlcnksIGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9ID0gcE9wdHM7XG4gICAgICAgIGlmICh0ZXh0ICE9PSB1bmRlZmluZWQgJiYgaHRtbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTXV0dWFsbHlFeGNsdXNpdmVBcmdzKHsgdGV4dCwgaHRtbCB9KVxuICAgICAgICB9XG4gICAgICAgIGlmIChodG1sRWxlbWVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzdXBlcih7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChieWlkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHN1cGVyKHsgYnlpZCwgY2hpbGRyZW4gfSk7XG4gICAgICAgIH0gZWxzZSBpZiAocXVlcnkgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc3VwZXIoeyBxdWVyeSwgY2hpbGRyZW4gfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzdXBlcih7IHRhZzogXCJwXCIsIHNldGlkLCBjbHMsIGh0bWwgfSk7XG4gICAgICAgICAgICBpZiAodGV4dCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy50ZXh0KHRleHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgU3BhbiBleHRlbmRzIEJldHRlckhUTUxFbGVtZW50PEhUTUxTcGFuRWxlbWVudD4ge1xuXG5cbiAgICBjb25zdHJ1Y3Rvcih7IGNscywgc2V0aWQsIHRleHQgfTogeyBjbHM/OiBzdHJpbmcsIHNldGlkPzogc3RyaW5nLCB0ZXh0Pzogc3RyaW5nIH0pXG4gICAgY29uc3RydWN0b3IoeyBjbHMsIHNldGlkLCBodG1sIH06IHsgY2xzPzogc3RyaW5nLCBzZXRpZD86IHN0cmluZywgaHRtbD86IHN0cmluZyB9KVxuICAgIGNvbnN0cnVjdG9yKHsgYnlpZCwgY2hpbGRyZW4gfTogeyBieWlkOiBzdHJpbmcsIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmogfSlcbiAgICBjb25zdHJ1Y3Rvcih7IHF1ZXJ5LCBjaGlsZHJlbiB9OiB7XG4gICAgICAgIHF1ZXJ5OiBzdHJpbmcsXG4gICAgICAgIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmpcbiAgICB9KVxuICAgIGNvbnN0cnVjdG9yKHsgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH06IHtcbiAgICAgICAgaHRtbEVsZW1lbnQ6IEhUTUxTcGFuRWxlbWVudDtcbiAgICAgICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxuICAgIH0pXG4gICAgY29uc3RydWN0b3Ioc3Bhbk9wdHMpIHtcbiAgICAgICAgY29uc3QgeyBzZXRpZCwgY2xzLCB0ZXh0LCBodG1sLCBieWlkLCBxdWVyeSwgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH0gPSBzcGFuT3B0cztcbiAgICAgICAgaWYgKHRleHQgIT09IHVuZGVmaW5lZCAmJiBodG1sICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNdXR1YWxseUV4Y2x1c2l2ZUFyZ3MoeyB0ZXh0LCBodG1sIH0pXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGh0bWxFbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHN1cGVyKHsgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKGJ5aWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc3VwZXIoeyBieWlkLCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChxdWVyeSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzdXBlcih7IHF1ZXJ5LCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN1cGVyKHsgdGFnOiBcInNwYW5cIiwgc2V0aWQsIGNscywgaHRtbCB9KTtcbiAgICAgICAgICAgIGlmICh0ZXh0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRleHQodGV4dCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIEltZzxRIGV4dGVuZHMgUXVlcnlTZWxlY3RvciA9IFF1ZXJ5U2VsZWN0b3I+IGV4dGVuZHMgQmV0dGVySFRNTEVsZW1lbnQ8SFRNTEltYWdlRWxlbWVudD4ge1xuXG5cbiAgICBjb25zdHJ1Y3Rvcih7IGNscywgc2V0aWQsIHNyYyB9OiB7XG4gICAgICAgIGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsXG4gICAgICAgIHNyYz86IHN0cmluZ1xuICAgIH0pO1xuICAgIGNvbnN0cnVjdG9yKHsgYnlpZCwgY2hpbGRyZW4gfToge1xuICAgICAgICBieWlkOiBzdHJpbmcsIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmpcbiAgICB9KTtcbiAgICBjb25zdHJ1Y3Rvcih7IHF1ZXJ5LCBjaGlsZHJlbiB9OiB7XG4gICAgICAgIHF1ZXJ5OiBRdWVyeU9yUHJlY2lzZVRhZzxRLCBcImltZ1wiPixcbiAgICAgICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxuICAgIH0pO1xuICAgIGNvbnN0cnVjdG9yKHsgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH06IHtcbiAgICAgICAgaHRtbEVsZW1lbnQ6IEhUTUxJbWFnZUVsZW1lbnQ7XG4gICAgICAgIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmpcbiAgICB9KVxuICAgIGNvbnN0cnVjdG9yKCk7XG4gICAgY29uc3RydWN0b3IoaW1nT3B0cz8pIHtcbiAgICAgICAgY29uc3QgeyBjbHMsIHNldGlkLCBzcmMsIGJ5aWQsIHF1ZXJ5LCBodG1sRWxlbWVudCwgY2hpbGRyZW4gfSA9IGltZ09wdHM7XG4gICAgICAgIGlmIChodG1sRWxlbWVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzdXBlcih7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChieWlkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHN1cGVyKHsgYnlpZCwgY2hpbGRyZW4gfSk7XG4gICAgICAgIH0gZWxzZSBpZiAocXVlcnkgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc3VwZXIoeyBxdWVyeSwgY2hpbGRyZW4gfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzdXBlcih7IHRhZzogXCJpbWdcIiwgc2V0aWQsIGNscyB9KTtcbiAgICAgICAgICAgIGlmIChzcmMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIHRoaXMuc3JjKHNyYyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgIH1cblxuICAgIHNyYyhzcmM6IHN0cmluZyk6IHRoaXM7XG4gICAgc3JjKCk6IHN0cmluZztcbiAgICBzcmMoc3JjPykge1xuICAgICAgICBpZiAoc3JjID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9odG1sRWxlbWVudC5zcmNcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LnNyYyA9IHNyYztcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgfVxuXG5cbn1cblxuZXhwb3J0IGNsYXNzIEFuY2hvciBleHRlbmRzIEJldHRlckhUTUxFbGVtZW50PEhUTUxBbmNob3JFbGVtZW50PiB7XG5cblxuICAgIGNvbnN0cnVjdG9yKHsgc2V0aWQsIGNscywgdGV4dCwgaHRtbCwgaHJlZiwgdGFyZ2V0LCBieWlkLCBxdWVyeSwgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH0pIHtcbiAgICAgICAgaWYgKHRleHQgIT09IHVuZGVmaW5lZCAmJiBodG1sICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNdXR1YWxseUV4Y2x1c2l2ZUFyZ3MoeyB0ZXh0LCBodG1sIH0pXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGh0bWxFbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHN1cGVyKHsgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKGJ5aWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc3VwZXIoeyBieWlkLCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChxdWVyeSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzdXBlcih7IHF1ZXJ5LCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN1cGVyKHsgdGFnOiBcImFcIiwgc2V0aWQsIGNscywgaHRtbCB9KTtcbiAgICAgICAgICAgIGlmICh0ZXh0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRleHQodGV4dCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaHJlZiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ocmVmKGhyZWYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRhcmdldCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy50YXJnZXQodGFyZ2V0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgfVxuXG4gICAgaHJlZigpOiBzdHJpbmdcbiAgICBocmVmKHZhbDogc3RyaW5nKTogdGhpc1xuICAgIGhyZWYodmFsPykge1xuICAgICAgICBpZiAodmFsID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmF0dHIoJ2hyZWYnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmF0dHIoeyBocmVmOiB2YWwgfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHRhcmdldCgpOiBzdHJpbmdcbiAgICB0YXJnZXQodmFsOiBzdHJpbmcpOiB0aGlzXG4gICAgdGFyZ2V0KHZhbD8pIHtcbiAgICAgICAgaWYgKHZhbCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5hdHRyKCd0YXJnZXQnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmF0dHIoeyB0YXJnZXQ6IHZhbCB9KVxuICAgICAgICB9XG4gICAgfVxufVxuXG5pbnRlcmZhY2UgRmxhc2hhYmxlIHtcbiAgICBmbGFzaEJhZCgpOiBQcm9taXNlPHZvaWQ+O1xuXG4gICAgZmxhc2hHb29kKCk6IFByb21pc2U8dm9pZD47XG59XG5cbmV4cG9ydCB0eXBlIEZvcm1pc2hIVE1MRWxlbWVudCA9IEhUTUxCdXR0b25FbGVtZW50IHwgSFRNTElucHV0RWxlbWVudCB8IEhUTUxTZWxlY3RFbGVtZW50O1xuZXhwb3J0IHR5cGUgSW5wdXRUeXBlID0gXCJjaGVja2JveFwiIHwgXCJudW1iZXJcIiB8IFwicmFkaW9cIiB8IFwidGV4dFwiIHwgXCJ0aW1lXCIgfCBcImRhdGV0aW1lLWxvY2FsXCJcblxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEZvcm08R2VuZXJpYyBleHRlbmRzIEZvcm1pc2hIVE1MRWxlbWVudD5cbiAgICBleHRlbmRzIEJldHRlckhUTUxFbGVtZW50PEdlbmVyaWM+IGltcGxlbWVudHMgRmxhc2hhYmxlIHtcblxuXG4gICAgZ2V0IGRpc2FibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5faHRtbEVsZW1lbnQuZGlzYWJsZWQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgIEJ1dHRvbiA8IElucHV0XG4gICAgIFNlbGVjdCAtIElucHV0OiBhZGQoKSwgaXRlbSgpLCBsZW5ndGgsIG5hbWVkSXRlbSgpLCBvcHRpb25zLCByZW1vdmUoKSwgc2VsZWN0ZWRJbmRleCwgc2VsZWN0ZWRPcHRpb25zLCBJVEVSQVRPUlxuICAgICBTZWxlY3QgLSBCdXR0b246IGFkZCgpIGF1dG9jb21wbGV0ZSBpdGVtKCkgbGVuZ3RoIG11bHRpcGxlIG5hbWVkSXRlbSgpIG9wdGlvbnMgcmVtb3ZlKCkgcmVxdWlyZWQgc2VsZWN0ZWRJbmRleCBzZWxlY3RlZE9wdGlvbnMgc2l6ZSBJVEVSQVRPUlxuICAgICBCdXR0b24gLSBTZWxlY3Q6IGZvcm1BY3Rpb24gZm9ybUVuY3R5cGUgZm9ybU1ldGhvZCBmb3JtTm9WYWxpZGF0ZSBmb3JtVGFyZ2V0XG5cbiAgICAgSW5wdXQgdW5pcXVlczpcbiAgICAgYWNjZXB0IGNoZWNrZWQgZGVmYXVsdENoZWNrZWQgZGVmYXVsdFZhbHVlIGRpck5hbWUgZmlsZXMgaW5kZXRlcm1pbmF0ZSBsaXN0IG1heCBtYXhMZW5ndGggbWluIG1pbkxlbmd0aCBwYXR0ZXJuIHBsYWNlaG9sZGVyIHJlYWRPbmx5IHNlbGVjdCgpIHNlbGVjdGlvbkRpcmVjdGlvbiBzZWxlY3Rpb25FbmQgc2VsZWN0aW9uU3RhcnQgc2V0UmFuZ2VUZXh0KCkgc2V0U2VsZWN0aW9uUmFuZ2UoKSBzcmMgc3RlcCBzdGVwRG93bigpIHN0ZXBVcCgpIHVzZU1hcCB2YWx1ZUFzRGF0ZSB2YWx1ZUFzTnVtYmVyXG5cbiAgICAgU2VsZWN0IHVuaXF1ZXM6XG4gICAgIGFkZCgpIGl0ZW0oKSBsZW5ndGggbmFtZWRJdGVtKCkgb3B0aW9ucyByZW1vdmUoKSBzZWxlY3RlZEluZGV4IHNlbGVjdGVkT3B0aW9ucyBJVEVSQVRPUlxuXG4gICAgIFNoYXJlZCBhbW9uZyBCdXR0b24sIFNlbGVjdCBhbmQgSW5wdXQ6IChvciBCdXR0b24gYW5kIFNlbGVjdCwgc2FtZSlcbiAgICAgY2hlY2tWYWxpZGl0eSgpIGRpc2FibGVkIGZvcm0gbGFiZWxzIG5hbWUgcmVwb3J0VmFsaWRpdHkoKSBzZXRDdXN0b21WYWxpZGl0eSgpIHR5cGUgdmFsaWRhdGlvbk1lc3NhZ2UgdmFsaWRpdHkgdmFsdWUgd2lsbFZhbGlkYXRlXG5cbiAgICAgU2hhcmVkIGFtbW9uZyBTZWxlY2N0IGFuZCBJbnB1dDpcbiAgICAgYXV0b2NvbXBsZXRlIGNoZWNrVmFsaWRpdHkoKSBkaXNhYmxlZCBmb3JtIGxhYmVscyBtdWx0aXBsZSBuYW1lIHJlcG9ydFZhbGlkaXR5KCkgcmVxdWlyZWQgc2V0Q3VzdG9tVmFsaWRpdHkoKSB0eXBlIHZhbGlkYXRpb25NZXNzYWdlIHZhbGlkaXR5IHZhbHVlIHdpbGxWYWxpZGF0ZVxuXG4gICAgICovXG4gICAgZGlzYWJsZSgpOiB0aGlzIHtcbiAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuZGlzYWJsZWQgPSB0cnVlO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBlbmFibGUoKTogdGhpcyB7XG4gICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LmRpc2FibGVkID0gZmFsc2U7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8qKkRpc2FibGVzLiovXG4gICAgdG9nZ2xlRW5hYmxlZChvbjogbnVsbCB8IHVuZGVmaW5lZCB8IDApOiB0aGlzXG4gICAgLyoqQ2FsbHMgYGVuYWJsZSgpYCBvciBgZGlzYWJsZSgpYCBhY2NvcmRpbmdseS4gKi9cbiAgICB0b2dnbGVFbmFibGVkKG9uOiBib29sZWFuKTogdGhpc1xuICAgIC8qKkVuYWJsZXMgaWYgYG9uYCBpcyB0cnV0aHksIG90aGVyd2lzZSBkaXNhYmxlcy5cbiAgICAgRXJyb3JzIGlmIGBvbmAgaXMgbm9uLXByaW1pdGl2ZSAob2JqZWN0LCBhcnJheSkuKi9cbiAgICB0b2dnbGVFbmFibGVkKG9uKTogdGhpcyB7XG4gICAgICAgIGlmIChpc09iamVjdChvbikpIHtcbiAgICAgICAgICAgIHRoaXMuX3NvZnRFcnIobmV3IEJIRVR5cGVFcnJvcih7IGZhdWx0eVZhbHVlOiB7IG9uIH0sIGV4cGVjdGVkOiBcInByaW1pdGl2ZVwiLCB3aGVyZTogXCJ0b2dnbGVFbmFibGVkKClcIiB9KSk7XG4gICAgICAgICAgICByZXR1cm4gdGhpc1xuICAgICAgICB9XG4gICAgICAgIGlmIChib29sKG9uKSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5hYmxlKClcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRpc2FibGUoKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqUmV0dXJucyB1bmRlZmluZWQgaWYgYF9odG1sRWxlbWVudC52YWx1ZWAgaXMgbnVsbCBvciB1bmRlZmluZWQsIG90aGVyd2lzZSByZXR1cm5zIGBfaHRtbEVsZW1lbnQudmFsdWVgKi9cbiAgICB2YWx1ZSgpOiBhbnk7XG4gICAgLyoqUmV0dXJucyB1bmRlZmluZWQgaWYgYF9odG1sRWxlbWVudC52YWx1ZWAgaXMgbnVsbCBvciB1bmRlZmluZWQsIG90aGVyd2lzZSByZXR1cm5zIGBfaHRtbEVsZW1lbnQudmFsdWVgKi9cbiAgICB2YWx1ZSh2YWw6IHVuZGVmaW5lZCk6IGFueTtcbiAgICAvKipSZXNldHMgYHZhbHVlYC4gKi9cbiAgICB2YWx1ZSh2YWw6IG51bGwgfCAnJyk6IHRoaXM7XG4gICAgLyoqU2V0cyBgdmFsdWVgICovXG4gICAgdmFsdWUodmFsOiBhbnkpOiB0aGlzO1xuICAgIHZhbHVlKHZhbD8pIHtcbiAgICAgICAgaWYgKHZhbCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faHRtbEVsZW1lbnQudmFsdWUgPz8gdW5kZWZpbmVkO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKGlzT2JqZWN0KHZhbCkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9zb2Z0RXJyKG5ldyBCSEVUeXBlRXJyb3IoeyBmYXVsdHlWYWx1ZTogeyB2YWwgfSwgZXhwZWN0ZWQ6IFwicHJpbWl0aXZlXCIsIHdoZXJlOiBcInZhbHVlKClcIiB9KSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9odG1sRWxlbWVudC52YWx1ZSA9IHZhbDtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgYXN5bmMgZmxhc2hCYWQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgICAgIHRoaXMuYWRkQ2xhc3MoJ2JhZCcpO1xuICAgICAgICBhd2FpdCB3YWl0KDIwMDApO1xuICAgICAgICB0aGlzLnJlbW92ZUNsYXNzKCdiYWQnKTtcblxuICAgIH1cblxuICAgIGFzeW5jIGZsYXNoR29vZCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICAgICAgdGhpcy5hZGRDbGFzcygnZ29vZCcpO1xuICAgICAgICBhd2FpdCB3YWl0KDIwMDApO1xuICAgICAgICB0aGlzLnJlbW92ZUNsYXNzKCdnb29kJyk7XG4gICAgfVxuXG4gICAgY2xlYXIoKTogdGhpcyB7XG4gICAgICAgIHJldHVybiB0aGlzLnZhbHVlKG51bGwpXG4gICAgfVxuXG4gICAgLy8gKiogRXZlbnQgSG9va3NcbiAgICBfYmVmb3JlRXZlbnQoKTogdGhpcztcbiAgICAvKipDYWxscyBgc2VsZi5kaXNhYmxlKClgLiovXG4gICAgX2JlZm9yZUV2ZW50KHRoaXNBcmc6IHRoaXMpOiB0aGlzXG4gICAgX2JlZm9yZUV2ZW50KHRoaXNBcmc/OiB0aGlzKTogdGhpcyB7XG4gICAgICAgIGxldCBzZWxmID0gdGhpcyA9PT0gdW5kZWZpbmVkID8gdGhpc0FyZyA6IHRoaXM7XG4gICAgICAgIHJldHVybiBzZWxmLmRpc2FibGUoKVxuICAgIH1cblxuICAgIF9vbkV2ZW50U3VjY2VzcyhyZXQ6IGFueSk6IHRoaXNcbiAgICBfb25FdmVudFN1Y2Nlc3MocmV0OiBhbnksIHRoaXNBcmc6IHRoaXMpOiB0aGlzXG4gICAgLyoqQ2FsbHMgYHNlbGYuZmxhc2hHb29kKClgLiovXG4gICAgX29uRXZlbnRTdWNjZXNzKHJldDogYW55LCB0aGlzQXJnPzogdGhpcyk6IHRoaXMge1xuICAgICAgICBsZXQgc2VsZiA9IHRoaXMgPT09IHVuZGVmaW5lZCA/IHRoaXNBcmcgOiB0aGlzO1xuICAgICAgICBpZiAoc2VsZi5mbGFzaEdvb2QpIHtcbiAgICAgICAgICAgIHNlbGYuZmxhc2hHb29kKClcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2VsZlxuICAgIH1cblxuICAgIGFzeW5jIF9zb2Z0RXJyKGU6IEVycm9yKTogUHJvbWlzZTx0aGlzPjtcbiAgICBhc3luYyBfc29mdEVycihlOiBFcnJvciwgdGhpc0FyZzogdGhpcyk6IFByb21pc2U8dGhpcz47XG4gICAgLyoqTG9ncyBlcnJvciB0byBjb25zb2xlIGFuZCBjYWxscyBgc2VsZi5mbGFzaEJhZCgpYC4qL1xuICAgIGFzeW5jIF9zb2Z0RXJyKGU6IEVycm9yLCB0aGlzQXJnPzogdGhpcyk6IFByb21pc2U8dGhpcz4ge1xuICAgICAgICBjb25zb2xlLmVycm9yKGAke2UubmFtZX06XFxuJHtlLm1lc3NhZ2V9YCk7XG4gICAgICAgIGxldCBzZWxmID0gdGhpcyA9PT0gdW5kZWZpbmVkID8gdGhpc0FyZyA6IHRoaXM7XG4gICAgICAgIGlmIChzZWxmLmZsYXNoQmFkKSB7XG4gICAgICAgICAgICBhd2FpdCBzZWxmLmZsYXNoQmFkKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNlbGZcbiAgICB9XG5cbiAgICBhc3luYyBfc29mdFdhcm4oZTogRXJyb3IpOiBQcm9taXNlPHRoaXM+O1xuICAgIGFzeW5jIF9zb2Z0V2FybihlOiBFcnJvciwgdGhpc0FyZzogdGhpcyk6IFByb21pc2U8dGhpcz47XG4gICAgLyoqTG9ncyB3YXJuaW5nIHRvIGNvbnNvbGUgYW5kIGNhbGxzIGBzZWxmLmZsYXNoQmFkKClgLiovXG4gICAgYXN5bmMgX3NvZnRXYXJuKGU6IEVycm9yLCB0aGlzQXJnPzogdGhpcyk6IFByb21pc2U8dGhpcz4ge1xuICAgICAgICBjb25zb2xlLndhcm4oYCR7ZS5uYW1lfTpcXG4ke2UubWVzc2FnZX1gKTtcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzID09PSB1bmRlZmluZWQgPyB0aGlzQXJnIDogdGhpcztcbiAgICAgICAgaWYgKHNlbGYuZmxhc2hCYWQpIHtcbiAgICAgICAgICAgIGF3YWl0IHNlbGYuZmxhc2hCYWQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2VsZlxuICAgIH1cblxuICAgIF9hZnRlckV2ZW50KCk6IHRoaXM7XG4gICAgX2FmdGVyRXZlbnQodGhpc0FyZzogdGhpcyk6IHRoaXM7XG4gICAgLyoqQ2FsbHMgYHNlbGYuZW5hYmxlKClgLiovXG4gICAgX2FmdGVyRXZlbnQodGhpc0FyZz86IHRoaXMpOiB0aGlzIHtcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzID09PSB1bmRlZmluZWQgPyB0aGlzQXJnIDogdGhpcztcbiAgICAgICAgcmV0dXJuIHNlbGYuZW5hYmxlKCk7XG4gICAgfVxuXG4gICAgLyoqVXNlZCBieSBlLmcuIGBjbGljayhmbilgIHRvIHdyYXAgcGFzc2VkIGBmbmAgc2FmZWx5IGFuZCB0cmlnZ2VyIGBfW2JlZm9yZXxhZnRlcnxvbl1FdmVudFtTdWNjZXNzfEVycm9yXWAuKi9cbiAgICBwcm90ZWN0ZWQgYXN5bmMgX3dyYXBGbkluRXZlbnRIb29rczxGIGV4dGVuZHMgKGV2ZW50OiBFdmVudCkgPT4gUHJvbWlzZTxhbnk+Pihhc3luY0ZuOiBGLCBldmVudDogRXZlbnQpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMuX2JlZm9yZUV2ZW50KCk7XG4gICAgICAgICAgICBjb25zdCByZXQgPSBhd2FpdCBhc3luY0ZuKGV2ZW50KTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuX29uRXZlbnRTdWNjZXNzKHJldCk7XG5cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5fc29mdEVycihlKTtcblxuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgdGhpcy5fYWZ0ZXJFdmVudCgpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5cbmV4cG9ydCBjbGFzcyBCdXR0b248USBleHRlbmRzIFF1ZXJ5U2VsZWN0b3IgPSBRdWVyeVNlbGVjdG9yPiBleHRlbmRzIEZvcm08SFRNTEJ1dHRvbkVsZW1lbnQ+IHtcbiAgICBjb25zdHJ1Y3Rvcih7IGNscywgc2V0aWQsIHRleHQsIGNsaWNrIH06IHtcbiAgICAgICAgY2xzPzogc3RyaW5nLCBzZXRpZD86IHN0cmluZywgdGV4dD86IHN0cmluZywgY2xpY2s/OiAoZXZlbnQ6IE1vdXNlRXZlbnQpID0+IGFueVxuICAgIH0pO1xuICAgIGNvbnN0cnVjdG9yKHsgY2xzLCBzZXRpZCwgaHRtbCwgY2xpY2sgfToge1xuICAgICAgICBjbHM/OiBzdHJpbmcsIHNldGlkPzogc3RyaW5nLCBodG1sPzogc3RyaW5nLCBjbGljaz86IChldmVudDogTW91c2VFdmVudCkgPT4gYW55XG4gICAgfSk7XG4gICAgY29uc3RydWN0b3IoeyBieWlkLCBjaGlsZHJlbiB9OiB7XG4gICAgICAgIGJ5aWQ6IHN0cmluZywgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxuICAgIH0pO1xuICAgIGNvbnN0cnVjdG9yKHsgcXVlcnksIGNoaWxkcmVuIH06IHtcbiAgICAgICAgcXVlcnk6IFF1ZXJ5T3JQcmVjaXNlVGFnPFEsIFwiYnV0dG9uXCI+LFxuICAgICAgICBjaGlsZHJlbj86IENoaWxkcmVuT2JqXG4gICAgfSlcbiAgICBjb25zdHJ1Y3Rvcih7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9OiB7XG4gICAgICAgIGh0bWxFbGVtZW50OiBIVE1MQnV0dG9uRWxlbWVudDtcbiAgICAgICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxuICAgIH0pXG4gICAgY29uc3RydWN0b3IoKTtcbiAgICBjb25zdHJ1Y3RvcihidXR0b25PcHRzPykge1xuICAgICAgICBjb25zdCB7IHNldGlkLCBjbHMsIHRleHQsIGh0bWwsIGJ5aWQsIHF1ZXJ5LCBodG1sRWxlbWVudCwgY2hpbGRyZW4sIGNsaWNrIH0gPSBidXR0b25PcHRzO1xuICAgICAgICBpZiAodGV4dCAhPT0gdW5kZWZpbmVkICYmIGh0bWwgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE11dHVhbGx5RXhjbHVzaXZlQXJncyh7IHRleHQsIGh0bWwgfSlcbiAgICAgICAgfVxuICAgICAgICBpZiAoaHRtbEVsZW1lbnQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc3VwZXIoeyBodG1sRWxlbWVudCwgY2hpbGRyZW4gfSk7XG4gICAgICAgIH0gZWxzZSBpZiAoYnlpZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzdXBlcih7IGJ5aWQsIGNoaWxkcmVuIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKHF1ZXJ5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHN1cGVyKHsgcXVlcnksIGNoaWxkcmVuIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc3VwZXIoeyB0YWc6IFwiYnV0dG9uXCIsIHNldGlkLCBjbHMsIGh0bWwgfSk7XG4gICAgICAgICAgICBpZiAodGV4dCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy50ZXh0KHRleHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNsaWNrICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNsaWNrKGNsaWNrKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9XG5cbiAgICB9XG5cbiAgICBjbGljayhfZm4/OiAoX2V2ZW50OiBNb3VzZUV2ZW50KSA9PiBQcm9taXNlPGFueT4pOiB0aGlzIHtcbiAgICAgICAgaWYgKF9mbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBjb25zdCBmbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuX3dyYXBGbkluRXZlbnRIb29rcyhfZm4sIGV2ZW50KTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHJldHVybiBzdXBlci5jbGljayhmbik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN1cGVyLmNsaWNrKClcbiAgICB9XG5cblxufVxuXG5leHBvcnQgY2xhc3MgSW5wdXQ8VElucHV0VHlwZSBleHRlbmRzIElucHV0VHlwZSxcbiAgICBHZW5lcmljIGV4dGVuZHMgRm9ybWlzaEhUTUxFbGVtZW50ID0gSFRNTElucHV0RWxlbWVudCxcbiAgICBRIGV4dGVuZHMgUXVlcnlTZWxlY3RvciA9IFF1ZXJ5U2VsZWN0b3I+XG4gICAgZXh0ZW5kcyBGb3JtPEdlbmVyaWM+IHtcbiAgICB0eXBlOiBUSW5wdXRUeXBlO1xuXG4gICAgY29uc3RydWN0b3IoeyBjbHMsIHNldGlkLCB0eXBlIH06IHtcbiAgICAgICAgY2xzPzogc3RyaW5nLCBzZXRpZD86IHN0cmluZyxcbiAgICAgICAgdHlwZT86IFRJbnB1dFR5cGVcbiAgICB9KTtcblxuICAgIGNvbnN0cnVjdG9yKHsgYnlpZCwgY2hpbGRyZW4gfTogeyBieWlkOiBzdHJpbmcsIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmogfSk7XG4gICAgY29uc3RydWN0b3IoeyBxdWVyeSwgY2hpbGRyZW4gfToge1xuICAgICAgICBxdWVyeTogUXVlcnlPclByZWNpc2VUYWc8USwgXCJpbnB1dFwiPixcbiAgICAgICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxuICAgIH0pO1xuXG4gICAgY29uc3RydWN0b3IoeyBodG1sRWxlbWVudCwgY2hpbGRyZW4gfToge1xuICAgICAgICBodG1sRWxlbWVudDogR2VuZXJpYztcbiAgICAgICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxuICAgIH0pO1xuXG4gICAgY29uc3RydWN0b3IoKTtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dE9wdHM/KSB7XG4gICAgICAgIGNvbnN0IHsgc2V0aWQsIGNscywgdHlwZSwgYnlpZCwgcXVlcnksIGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9ID0gaW5wdXRPcHRzO1xuXG5cbiAgICAgICAgaWYgKGh0bWxFbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHN1cGVyKHsgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKGJ5aWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc3VwZXIoeyBieWlkLCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChxdWVyeSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzdXBlcih7IHF1ZXJ5LCBjaGlsZHJlbiB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN1cGVyKHsgdGFnOiBcImlucHV0XCIgYXMgRWxlbWVudDJUYWc8R2VuZXJpYz4sIGNscywgc2V0aWQgfSk7XG4gICAgICAgICAgICBpZiAodHlwZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICAgICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LnR5cGUgPSB0eXBlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cblxuICAgIH1cblxuXG59XG5cbmV4cG9ydCBjbGFzcyBUZXh0SW5wdXQ8USBleHRlbmRzIFF1ZXJ5U2VsZWN0b3IgPSBRdWVyeVNlbGVjdG9yPiBleHRlbmRzIElucHV0PFwidGV4dFwiPiB7XG4gICAgY29uc3RydWN0b3IoeyBjbHMsIHNldGlkLCBwbGFjZWhvbGRlciB9OiB7XG4gICAgICAgIGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsXG4gICAgICAgIHBsYWNlaG9sZGVyPzogc3RyaW5nXG4gICAgfSk7XG5cbiAgICBjb25zdHJ1Y3Rvcih7IGJ5aWQsIGNoaWxkcmVuIH06IHsgYnlpZDogc3RyaW5nLCBjaGlsZHJlbj86IENoaWxkcmVuT2JqIH0pO1xuICAgIGNvbnN0cnVjdG9yKHsgcXVlcnksIGNoaWxkcmVuIH06IHtcbiAgICAgICAgcXVlcnk6IFF1ZXJ5T3JQcmVjaXNlVGFnPFEsIFwiaW5wdXRcIj4sXG4gICAgICAgIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmpcbiAgICB9KTtcblxuICAgIGNvbnN0cnVjdG9yKHsgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH06IHtcbiAgICAgICAgaHRtbEVsZW1lbnQ6IEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgICAgIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmpcbiAgICB9KTtcblxuICAgIGNvbnN0cnVjdG9yKCk7XG4gICAgY29uc3RydWN0b3Iob3B0cz8pIHtcbiAgICAgICAgb3B0cy50eXBlID0gJ3RleHQnO1xuICAgICAgICBzdXBlcihvcHRzKTtcbiAgICAgICAgY29uc3QgeyBwbGFjZWhvbGRlciB9ID0gb3B0cztcbiAgICAgICAgaWYgKHBsYWNlaG9sZGVyICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRoaXMucGxhY2Vob2xkZXIocGxhY2Vob2xkZXIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcGxhY2Vob2xkZXIodmFsOiBzdHJpbmcpOiB0aGlzO1xuICAgIHBsYWNlaG9sZGVyKCk6IHN0cmluZztcbiAgICBwbGFjZWhvbGRlcih2YWw/KSB7XG4gICAgICAgIGlmICh2YWwgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2h0bWxFbGVtZW50LnBsYWNlaG9sZGVyO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQucGxhY2Vob2xkZXIgPSB2YWw7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuXG4gICAgfVxuXG4gICAga2V5ZG93bihfZm46IChfZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IFByb21pc2U8YW55Pik6IHRoaXMge1xuICAgICAgICBjb25zdCBmbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGV2ZW50LmtleSAhPT0gJ0VudGVyJykge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCB2YWwgPSB0aGlzLnZhbHVlKCk7XG4gICAgICAgICAgICBpZiAoIWJvb2wodmFsKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuX3NvZnRXYXJuKG5ldyBWYWx1ZUVycm9yKHsgZmF1bHR5VmFsdWU6IHsgdmFsIH0sIGV4cGVjdGVkOiBcInRydXRoeVwiLCB3aGVyZTogXCJrZXlkb3duKClcIiB9KSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYXdhaXQgdGhpcy5fd3JhcEZuSW5FdmVudEhvb2tzKF9mbiwgZXZlbnQpO1xuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gc3VwZXIua2V5ZG93bihmbik7XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgQ2hhbmdhYmxlPFRJbnB1dFR5cGUgZXh0ZW5kcyBJbnB1dFR5cGUsIEdlbmVyaWMgZXh0ZW5kcyBGb3JtaXNoSFRNTEVsZW1lbnQ+IGV4dGVuZHMgSW5wdXQ8VElucHV0VHlwZSwgR2VuZXJpYz4ge1xuICAgIGNoYW5nZShfZm46IChfZXZlbnQ6IEV2ZW50KSA9PiBQcm9taXNlPGFueT4pOiB0aGlzIHtcblxuICAgICAgICBjb25zdCBmbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5fd3JhcEZuSW5FdmVudEhvb2tzKF9mbiwgZXZlbnQpO1xuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gc3VwZXIuY2hhbmdlKGZuKTtcbiAgICB9XG59XG5cbi8qKlBhdGNoZXMgRm9ybSdzIGB2YWx1ZSgpYCB0byBzZXQvZ2V0IGBfaHRtbEVsZW1lbnQuY2hlY2tlZGAsIGFuZCBgY2xlYXIoKWAgdG8gdW5jaGVjay4gKi9cbmV4cG9ydCBjbGFzcyBDaGVja2JveElucHV0IGV4dGVuZHMgQ2hhbmdhYmxlPFwiY2hlY2tib3hcIiwgSFRNTElucHV0RWxlbWVudD4ge1xuICAgIGNvbnN0cnVjdG9yKG9wdHMpIHtcbiAgICAgICAgb3B0cy50eXBlID0gJ2NoZWNrYm94JztcbiAgICAgICAgc3VwZXIob3B0cyk7XG4gICAgfVxuXG4gICAgZ2V0IGNoZWNrZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9odG1sRWxlbWVudC5jaGVja2VkO1xuICAgIH1cblxuICAgIGNoZWNrKCk6IHRoaXMge1xuICAgICAgICB0aGlzLl9odG1sRWxlbWVudC5jaGVja2VkID0gdHJ1ZTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgdW5jaGVjaygpOiB0aGlzIHtcbiAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuY2hlY2tlZCA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cblxuICAgIC8qKkRpc2FibGVzLiovXG4gICAgdG9nZ2xlQ2hlY2tlZChvbjogbnVsbCB8IHVuZGVmaW5lZCB8IDApOiB0aGlzXG4gICAgLyoqQ2FsbHMgYGNoZWNrKClgIG9yIGB1bmNoZWNrKClgIGFjY29yZGluZ2x5LiAqL1xuICAgIHRvZ2dsZUNoZWNrZWQob246IGJvb2xlYW4pOiB0aGlzXG5cbiAgICAvKipjaGVja3Mgb24gaWYgYG9uYCBpcyB0cnV0aHksIG90aGVyd2lzZSB1bmNoZWNrcy5cbiAgICAgRXJyb3JzIGlmIGBvbmAgaXMgbm9uLXByaW1pdGl2ZSAob2JqZWN0LCBhcnJheSkuKi9cbiAgICB0b2dnbGVDaGVja2VkKG9uKSB7XG4gICAgICAgIGlmIChpc09iamVjdChvbikpIHtcbiAgICAgICAgICAgIHRoaXMuX3NvZnRFcnIobmV3IEJIRVR5cGVFcnJvcih7IGZhdWx0eVZhbHVlOiB7IG9uIH0sIGV4cGVjdGVkOiBcInByaW1pdGl2ZVwiLCB3aGVyZTogXCJ0b2dnbGVDaGVja2VkKClcIiB9KSk7XG4gICAgICAgICAgICByZXR1cm4gdGhpc1xuICAgICAgICB9XG4gICAgICAgIGlmIChib29sKG9uKSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY2hlY2soKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMudW5jaGVjaygpXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipSZXR1cm5zIHVuZGVmaW5lZCBpZiBgX2h0bWxFbGVtZW50LnZhbHVlYCBpcyBudWxsIG9yIHVuZGVmaW5lZCwgb3RoZXJ3aXNlIHJldHVybnMgYF9odG1sRWxlbWVudC52YWx1ZWAqL1xuICAgIHZhbHVlKCk6IGFueTtcbiAgICAvKipSZXR1cm5zIHVuZGVmaW5lZCBpZiBgX2h0bWxFbGVtZW50LnZhbHVlYCBpcyBudWxsIG9yIHVuZGVmaW5lZCwgb3RoZXJ3aXNlIHJldHVybnMgYF9odG1sRWxlbWVudC52YWx1ZWAqL1xuICAgIHZhbHVlKHZhbDogdW5kZWZpbmVkKTogYW55O1xuICAgIC8qKlJlc2V0cyBgdmFsdWVgLiAqL1xuICAgIHZhbHVlKHZhbDogbnVsbCB8ICcnKTogdGhpcztcbiAgICAvKipTZXRzIGB2YWx1ZWAgKi9cbiAgICB2YWx1ZSh2YWw6IGFueSk6IHRoaXM7XG4gICAgdmFsdWUodmFsPykge1xuICAgICAgICBpZiAodmFsID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9odG1sRWxlbWVudC5jaGVja2VkID8/IHVuZGVmaW5lZDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmIChpc09iamVjdCh2YWwpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fc29mdEVycihuZXcgQkhFVHlwZUVycm9yKHsgZmF1bHR5VmFsdWU6IHsgdmFsIH0sIGV4cGVjdGVkOiBcInByaW1pdGl2ZVwiLCB3aGVyZTogXCJ2YWx1ZSgpXCIgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5faHRtbEVsZW1lbnQuY2hlY2tlZCA9IHZhbDtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY2xlYXIoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnVuY2hlY2soKTtcbiAgICB9XG5cbiAgICBhc3luYyBfc29mdEVycihlOiBFcnJvciwgdGhpc0FyZz86IHRoaXMpOiBQcm9taXNlPHRoaXM+IHtcbiAgICAgICAgdGhpcy50b2dnbGVDaGVja2VkKCF0aGlzLmNoZWNrZWQpO1xuICAgICAgICByZXR1cm4gc3VwZXIuX3NvZnRFcnIoZSk7XG4gICAgfVxufVxuXG5cbmV4cG9ydCBjbGFzcyBTZWxlY3QgZXh0ZW5kcyBDaGFuZ2FibGU8dW5kZWZpbmVkLCBIVE1MU2VsZWN0RWxlbWVudD4ge1xuXG4gICAgLy8gU2VsZWN0IHVuaXF1ZXM6XG4gICAgLy8gYWRkKCkgaXRlbSgpIGxlbmd0aCBuYW1lZEl0ZW0oKSBvcHRpb25zIHJlbW92ZSgpIHNlbGVjdGVkSW5kZXggc2VsZWN0ZWRPcHRpb25zIElURVJBVE9SXG4gICAgY29uc3RydWN0b3Ioc2VsZWN0T3B0cykge1xuICAgICAgICBzdXBlcihzZWxlY3RPcHRzKTtcbiAgICB9XG5cbiAgICBnZXQgc2VsZWN0ZWRJbmRleCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5faHRtbEVsZW1lbnQuc2VsZWN0ZWRJbmRleFxuICAgIH1cblxuICAgIHNldCBzZWxlY3RlZEluZGV4KHZhbDogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX2h0bWxFbGVtZW50LnNlbGVjdGVkSW5kZXggPSB2YWxcbiAgICB9XG5cbiAgICBnZXQgc2VsZWN0ZWQoKTogSFRNTE9wdGlvbkVsZW1lbnQge1xuICAgICAgICByZXR1cm4gdGhpcy5pdGVtKHRoaXMuc2VsZWN0ZWRJbmRleClcbiAgICB9XG5cbiAgICAvKipAcGFyYW0gdmFsIC0gRWl0aGVyIGEgc3BlY2lmaWMgSFRNTE9wdGlvbkVsZW1lbnQsIG51bWJlciAoaW5kZXgpKi9cbiAgICBzZXQgc2VsZWN0ZWQodmFsKSB7XG4gICAgICAgIGlmICh2YWwgaW5zdGFuY2VvZiBIVE1MT3B0aW9uRWxlbWVudCkge1xuICAgICAgICAgICAgbGV0IGluZGV4ID0gdGhpcy5vcHRpb25zLmZpbmRJbmRleChvID0+IG8gPT09IHZhbCk7XG4gICAgICAgICAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fc29mdFdhcm4obmV3IFZhbHVlRXJyb3IoeyBmYXVsdHlWYWx1ZTogeyB2YWwgfSwgd2hlcmU6IFwic2V0IHNlbGVjdGVkKHZhbClcIiwgbWVzc2FnZTogYG5vIG9wdGlvbiBlcXVhbHMgcGFzc2VkIHZhbGAgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZEluZGV4ID0gaW5kZXg7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRJbmRleCA9IHZhbFxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZEluZGV4ID0gdGhpcy5vcHRpb25zLmZpbmRJbmRleChvID0+IG8udmFsdWUgPT09IHZhbCk7XG4gICAgICAgIH1cblxuICAgIH1cblxuICAgIGdldCBvcHRpb25zKCk6IEhUTUxPcHRpb25FbGVtZW50W10ge1xuICAgICAgICByZXR1cm4gWy4uLnRoaXMuX2h0bWxFbGVtZW50Lm9wdGlvbnMgYXMgdW5rbm93biBhcyBJdGVyYWJsZTxIVE1MT3B0aW9uRWxlbWVudD5dXG4gICAgfVxuXG4gICAgaXRlbShpbmRleDogbnVtYmVyKTogSFRNTE9wdGlvbkVsZW1lbnQge1xuICAgICAgICByZXR1cm4gdGhpcy5faHRtbEVsZW1lbnQuaXRlbShpbmRleCkgYXMgSFRNTE9wdGlvbkVsZW1lbnRcbiAgICB9XG5cbiAgICAvKipSZXR1cm5zIHVuZGVmaW5lZCBpZiBgdGhpcy5zZWxlY3RlZC52YWx1ZWAgaXMgbnVsbCBvciB1bmRlZmluZWQsIG90aGVyd2lzZSByZXR1cm5zIGB0aGlzLnNlbGVjdGVkLnZhbHVlYCovXG4gICAgdmFsdWUoKTogYW55O1xuICAgIC8qKlJldHVybnMgdW5kZWZpbmVkIGlmIGB0aGlzLnNlbGVjdGVkLnZhbHVlYCBpcyBudWxsIG9yIHVuZGVmaW5lZCwgb3RoZXJ3aXNlIHJldHVybnMgYHRoaXMuc2VsZWN0ZWQudmFsdWVgKi9cbiAgICB2YWx1ZSh2YWw6IHVuZGVmaW5lZCk6IGFueTtcbiAgICAvKipSZXNldHMgYHNlbGVjdGVkYCB0byBibGFuayovXG4gICAgdmFsdWUodmFsOiBudWxsIHwgJycgfCBib29sZWFuKTogdGhpcztcbiAgICAvKipTZXRzIGBzZWxlY3RlZGAgdG8gYHZhbGAgaWYgZmluZHMgYSBtYXRjaCAqL1xuICAgIHZhbHVlKHZhbDogSFRNTE9wdGlvbkVsZW1lbnQgfCBudW1iZXIgfCBhbnkpOiB0aGlzO1xuICAgIHZhbHVlKHZhbD8pIHtcbiAgICAgICAgaWYgKHZhbCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZC52YWx1ZSA/PyB1bmRlZmluZWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkID0gdmFsO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipTZXRzIGBzZWxlY3RlZGAgdG8gMHRoIGVsZW1lbnQuIEVxdWl2YWxlbnQgdG8gYHZhbHVlKDApYC4qL1xuICAgIGNsZWFyKCkge1xuICAgICAgICB0aGlzLnNlbGVjdGVkSW5kZXggPSAwO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICAvKltTeW1ib2wuaXRlcmF0b3JdKCkge1xuICAgICAgICBsZXQgb3B0aW9ucyA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgbGV0IGN1cnJlbnRJbmRleCA9IDA7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBuZXh0KCkge1xuICAgICAgICAgICAgICAgIGN1cnJlbnRJbmRleCArPSAxO1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgIGRvbmU6IHRydWVcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9Ki9cbn1cblxuXG4vKmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnYmV0dGVyLWh0bWwtZWxlbWVudCcsIEJldHRlckhUTUxFbGVtZW50KTtcbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnYmV0dGVyLWRpdicsIERpdiwge2V4dGVuZHM6ICdkaXYnfSk7XG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2JldHRlci1pbnB1dCcsIElucHV0LCB7ZXh0ZW5kczogJ2lucHV0J30pO1xuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdiZXR0ZXItcCcsIFBhcmFncmFwaCwge2V4dGVuZHM6ICdwJ30pO1xuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdiZXR0ZXItc3BhbicsIFNwYW4sIHtleHRlbmRzOiAnc3Bhbid9KTtcbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnYmV0dGVyLWltZycsIEltZywge2V4dGVuZHM6ICdpbWcnfSk7XG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2JldHRlci1hJywgQW5jaG9yLCB7ZXh0ZW5kczogJ2EnfSk7Ki9cblxuLy8gY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdiZXR0ZXItc3ZnJywgU3ZnLCB7ZXh0ZW5kczogJ3N2Zyd9KTtcblxuLyoqQ3JlYXRlIGFuIGVsZW1lbnQgb2YgYGNyZWF0ZWAuIE9wdGlvbmFsbHksIHNldCBpdHMgYHRleHRgIGFuZCAvIG9yIGBjbHNgKi9cbmV4cG9ydCBmdW5jdGlvbiBlbGVtPFQgZXh0ZW5kcyBUYWc+KHsgdGFnLCBjbHMsIHNldGlkLCBodG1sIH06IHsgdGFnOiBULCBjbHM/OiBzdHJpbmcsIHNldGlkPzogc3RyaW5nLCBodG1sPzogc3RyaW5nIH0pOlxuICAgIFQgZXh0ZW5kcyBUYWcgPyBCZXR0ZXJIVE1MRWxlbWVudDxIVE1MRWxlbWVudFRhZ05hbWVNYXBbVF0+IDogbmV2ZXI7XG4vKipHZXQgYW4gZXhpc3RpbmcgZWxlbWVudCBieSBgaWRgLiBPcHRpb25hbGx5LCBzZXQgaXRzIGB0ZXh0YCwgYGNsc2Agb3IgY2FjaGUgYGNoaWxkcmVuYCovXG5leHBvcnQgZnVuY3Rpb24gZWxlbSh7IGJ5aWQsIGNoaWxkcmVuIH06IHsgYnlpZDogc3RyaW5nLCBjaGlsZHJlbj86IENoaWxkcmVuT2JqIH0pOlxuICAgIEJldHRlckhUTUxFbGVtZW50O1xuLyoqR2V0IGFuIGV4aXN0aW5nIGVsZW1lbnQgYnkgYHF1ZXJ5YC4gT3B0aW9uYWxseSwgc2V0IGl0cyBgdGV4dGAsIGBjbHNgIG9yIGNhY2hlIGBjaGlsZHJlbmAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVsZW08USBleHRlbmRzIFF1ZXJ5U2VsZWN0b3I+KHsgcXVlcnksIGNoaWxkcmVuIH06IHsgcXVlcnk6IFEsIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmogfSk6XG4gICAgUSBleHRlbmRzIFRhZyA/IEJldHRlckhUTUxFbGVtZW50PEhUTUxFbGVtZW50VGFnTmFtZU1hcFtRXT4gOiBCZXR0ZXJIVE1MRWxlbWVudDtcbi8qKldyYXAgYW4gZXhpc3RpbmcgSFRNTEVsZW1lbnQuIE9wdGlvbmFsbHksIHNldCBpdHMgYHRleHRgLCBgY2xzYCBvciBjYWNoZSBgY2hpbGRyZW5gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbGVtPEUgZXh0ZW5kcyBIVE1MRWxlbWVudD4oeyBodG1sRWxlbWVudCwgY2hpbGRyZW4gfTogeyBodG1sRWxlbWVudDogRTsgY2hpbGRyZW4/OiBDaGlsZHJlbk9iaiB9KTpcbiAgICBCZXR0ZXJIVE1MRWxlbWVudDxFPjtcblxuZXhwb3J0IGZ1bmN0aW9uIGVsZW0oZWxlbU9wdGlvbnMpIHtcbiAgICByZXR1cm4gbmV3IEJldHRlckhUTUxFbGVtZW50KGVsZW1PcHRpb25zKTtcbn1cblxuXG5leHBvcnQgZnVuY3Rpb24gc3Bhbih7IGNscywgc2V0aWQsIHRleHQgfTogeyBjbHM/OiBzdHJpbmcsIHNldGlkPzogc3RyaW5nLCB0ZXh0Pzogc3RyaW5nIH0pOiBTcGFuO1xuZXhwb3J0IGZ1bmN0aW9uIHNwYW4oeyBjbHMsIHNldGlkLCBodG1sIH06IHsgY2xzPzogc3RyaW5nLCBzZXRpZD86IHN0cmluZywgaHRtbD86IHN0cmluZyB9KTogU3BhbjtcbmV4cG9ydCBmdW5jdGlvbiBzcGFuKHsgYnlpZCwgY2hpbGRyZW4gfTogeyBieWlkOiBzdHJpbmcsIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmogfSk6IFNwYW47XG5leHBvcnQgZnVuY3Rpb24gc3BhbjxRIGV4dGVuZHMgUXVlcnlTZWxlY3Rvcj4oeyBxdWVyeSwgY2hpbGRyZW4gfToge1xuICAgIHF1ZXJ5OiBRdWVyeU9yUHJlY2lzZVRhZzxRLCBcInNwYW5cIj4sXG4gICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IFNwYW47XG5leHBvcnQgZnVuY3Rpb24gc3BhbjxFIGV4dGVuZHMgSFRNTFNwYW5FbGVtZW50Pih7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9OiB7XG4gICAgaHRtbEVsZW1lbnQ6IEU7XG4gICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IFNwYW47XG5leHBvcnQgZnVuY3Rpb24gc3BhbigpOiBTcGFuXG5leHBvcnQgZnVuY3Rpb24gc3BhbihzcGFuT3B0cz8pOiBTcGFuIHtcbiAgICBpZiAoIWJvb2woc3Bhbk9wdHMpKSB7XG4gICAgICAgIHNwYW5PcHRzID0ge31cbiAgICB9XG4gICAgcmV0dXJuIG5ldyBTcGFuKHNwYW5PcHRzKVxufVxuXG4vKipDcmVhdGUgYSBEaXYgZWxlbWVudCwgb3Igd3JhcCBhbiBleGlzdGluZyBvbmUgYnkgcGFzc2luZyBodG1sRWxlbWVudC4gT3B0aW9uYWxseSBzZXQgaXRzIGlkLCB0ZXh0IG9yIGNscy4qL1xuZXhwb3J0IGZ1bmN0aW9uIGRpdih7IGNscywgc2V0aWQsIHRleHQgfToge1xuICAgIGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsIHRleHQ/OiBzdHJpbmdcbn0pOiBEaXY7XG5leHBvcnQgZnVuY3Rpb24gZGl2KHsgY2xzLCBzZXRpZCwgaHRtbCB9OiB7XG4gICAgY2xzPzogc3RyaW5nLCBzZXRpZD86IHN0cmluZywgaHRtbD86IHN0cmluZ1xufSk6IERpdjtcbmV4cG9ydCBmdW5jdGlvbiBkaXYoeyBieWlkLCBjaGlsZHJlbiB9OiB7XG4gICAgYnlpZDogc3RyaW5nLCBjaGlsZHJlbj86IENoaWxkcmVuT2JqXG59KTogRGl2O1xuZXhwb3J0IGZ1bmN0aW9uIGRpdjxRIGV4dGVuZHMgUXVlcnlTZWxlY3Rvcj4oeyBxdWVyeSwgY2hpbGRyZW4gfToge1xuICAgIHF1ZXJ5OiBRdWVyeU9yUHJlY2lzZVRhZzxRLCBcImRpdlwiPixcbiAgICBjaGlsZHJlbj86IENoaWxkcmVuT2JqXG59KTogRGl2O1xuZXhwb3J0IGZ1bmN0aW9uIGRpdih7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9OiB7XG4gICAgaHRtbEVsZW1lbnQ6IEhUTUxEaXZFbGVtZW50O1xuICAgIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmpcbn0pOiBEaXY7XG5leHBvcnQgZnVuY3Rpb24gZGl2KCk6IERpdlxuZXhwb3J0IGZ1bmN0aW9uIGRpdihkaXZPcHRzPyk6IERpdiB7XG4gICAgaWYgKCFib29sKGRpdk9wdHMpKSB7XG4gICAgICAgIGRpdk9wdHMgPSB7fVxuICAgIH1cbiAgICByZXR1cm4gbmV3IERpdihkaXZPcHRzKVxufVxuXG5cbmV4cG9ydCBmdW5jdGlvbiBidXR0b24oeyBjbHMsIHNldGlkLCB0ZXh0IH06IHtcbiAgICBjbHM/OiBzdHJpbmcsIHNldGlkPzogc3RyaW5nLCB0ZXh0Pzogc3RyaW5nLCBjbGljaz86IChldmVudDogTW91c2VFdmVudCkgPT4gYW55XG59KTogQnV0dG9uO1xuZXhwb3J0IGZ1bmN0aW9uIGJ1dHRvbih7IGNscywgc2V0aWQsIGh0bWwgfToge1xuICAgIGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsIGh0bWw/OiBzdHJpbmcsIGNsaWNrPzogKGV2ZW50OiBNb3VzZUV2ZW50KSA9PiBhbnlcbn0pOiBCdXR0b247XG5leHBvcnQgZnVuY3Rpb24gYnV0dG9uKHsgYnlpZCwgY2hpbGRyZW4gfToge1xuICAgIGJ5aWQ6IHN0cmluZywgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IEJ1dHRvbjtcbmV4cG9ydCBmdW5jdGlvbiBidXR0b248USBleHRlbmRzIFF1ZXJ5U2VsZWN0b3I+KHsgcXVlcnksIGNoaWxkcmVuIH06IHtcbiAgICBxdWVyeTogUXVlcnlPclByZWNpc2VUYWc8USwgXCJidXR0b25cIj4sXG4gICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IEJ1dHRvbjtcbmV4cG9ydCBmdW5jdGlvbiBidXR0b24oeyBodG1sRWxlbWVudCwgY2hpbGRyZW4gfToge1xuICAgIGh0bWxFbGVtZW50OiBIVE1MQnV0dG9uRWxlbWVudDtcbiAgICBjaGlsZHJlbj86IENoaWxkcmVuT2JqXG59KTogQnV0dG9uO1xuZXhwb3J0IGZ1bmN0aW9uIGJ1dHRvbigpOiBCdXR0b25cbmV4cG9ydCBmdW5jdGlvbiBidXR0b24oYnV0dG9uT3B0cz8pOiBCdXR0b24ge1xuICAgIGlmICghYm9vbChidXR0b25PcHRzKSkge1xuICAgICAgICBidXR0b25PcHRzID0ge31cbiAgICB9XG4gICAgcmV0dXJuIG5ldyBCdXR0b24oYnV0dG9uT3B0cylcbn1cblxuXG5leHBvcnQgZnVuY3Rpb24gaW5wdXQ8VElucHV0VHlwZSBleHRlbmRzIElucHV0VHlwZSwgR2VuZXJpYyBleHRlbmRzIEZvcm1pc2hIVE1MRWxlbWVudCA9IEhUTUxJbnB1dEVsZW1lbnQ+KHsgY2xzLCBzZXRpZCwgdHlwZSwgcGxhY2Vob2xkZXIgfToge1xuICAgIGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsXG4gICAgdHlwZT86IFRJbnB1dFR5cGUsXG4gICAgcGxhY2Vob2xkZXI/OiBzdHJpbmdcbn0pOiBJbnB1dDxUSW5wdXRUeXBlLCBHZW5lcmljPjtcbmV4cG9ydCBmdW5jdGlvbiBpbnB1dDxUSW5wdXRUeXBlIGV4dGVuZHMgSW5wdXRUeXBlID0gSW5wdXRUeXBlLCBHZW5lcmljIGV4dGVuZHMgRm9ybWlzaEhUTUxFbGVtZW50ID0gSFRNTElucHV0RWxlbWVudD4oeyBieWlkLCBjaGlsZHJlbiB9OiB7IGJ5aWQ6IHN0cmluZywgY2hpbGRyZW4/OiBDaGlsZHJlbk9iaiB9KTogSW5wdXQ8VElucHV0VHlwZSwgR2VuZXJpYz47XG5leHBvcnQgZnVuY3Rpb24gaW5wdXQ8USBleHRlbmRzIFF1ZXJ5U2VsZWN0b3IsIFRJbnB1dFR5cGUgZXh0ZW5kcyBJbnB1dFR5cGUgPSBJbnB1dFR5cGUsIEdlbmVyaWMgZXh0ZW5kcyBGb3JtaXNoSFRNTEVsZW1lbnQgPSBIVE1MSW5wdXRFbGVtZW50Pih7IHF1ZXJ5LCBjaGlsZHJlbiB9OiB7XG4gICAgcXVlcnk6IFF1ZXJ5T3JQcmVjaXNlVGFnPFEsIFwiaW5wdXRcIj4sXG4gICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IElucHV0PFRJbnB1dFR5cGUsIEdlbmVyaWM+O1xuZXhwb3J0IGZ1bmN0aW9uIGlucHV0PFRJbnB1dFR5cGUgZXh0ZW5kcyBJbnB1dFR5cGUgPSBJbnB1dFR5cGUsIEdlbmVyaWMgZXh0ZW5kcyBGb3JtaXNoSFRNTEVsZW1lbnQgPSBIVE1MSW5wdXRFbGVtZW50Pih7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9OiB7XG4gICAgaHRtbEVsZW1lbnQ6IEdlbmVyaWM7XG4gICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IElucHV0PFRJbnB1dFR5cGUsIEdlbmVyaWM+O1xuZXhwb3J0IGZ1bmN0aW9uIGlucHV0PFRJbnB1dFR5cGUgZXh0ZW5kcyBJbnB1dFR5cGUgPSBJbnB1dFR5cGUsIEdlbmVyaWMgZXh0ZW5kcyBGb3JtaXNoSFRNTEVsZW1lbnQgPSBIVE1MSW5wdXRFbGVtZW50PigpOiBJbnB1dDxUSW5wdXRUeXBlLCBHZW5lcmljPlxuZXhwb3J0IGZ1bmN0aW9uIGlucHV0KGlucHV0T3B0cz8pIHtcbiAgICBpZiAoIWJvb2woaW5wdXRPcHRzKSkge1xuICAgICAgICBpbnB1dE9wdHMgPSB7fVxuICAgIH1cbiAgICByZXR1cm4gbmV3IElucHV0KGlucHV0T3B0cylcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdChzZWxlY3RPcHRzKTogU2VsZWN0IHtcbiAgICBpZiAoIWJvb2woc2VsZWN0T3B0cykpIHtcbiAgICAgICAgc2VsZWN0T3B0cyA9IHt9XG4gICAgfVxuICAgIHJldHVybiBuZXcgU2VsZWN0KHNlbGVjdE9wdHMpXG59XG5cbi8qKkNyZWF0ZSBhbiBJbWcgZWxlbWVudCwgb3Igd3JhcCBhbiBleGlzdGluZyBvbmUgYnkgcGFzc2luZyBodG1sRWxlbWVudC4gT3B0aW9uYWxseSBzZXQgaXRzIGlkLCBzcmMgb3IgY2xzLiovXG5leHBvcnQgZnVuY3Rpb24gaW1nKHsgY2xzLCBzZXRpZCwgc3JjIH06IHtcbiAgICBjbHM/OiBzdHJpbmcsIHNldGlkPzogc3RyaW5nLFxuICAgIHNyYz86IHN0cmluZ1xufSk6IEltZztcbmV4cG9ydCBmdW5jdGlvbiBpbWcoeyBieWlkLCBjaGlsZHJlbiB9OiB7XG4gICAgYnlpZDogc3RyaW5nLCBjaGlsZHJlbj86IENoaWxkcmVuT2JqXG59KTogSW1nO1xuZXhwb3J0IGZ1bmN0aW9uIGltZzxRIGV4dGVuZHMgUXVlcnlTZWxlY3Rvcj4oeyBxdWVyeSwgY2hpbGRyZW4gfToge1xuICAgIHF1ZXJ5OiBRdWVyeU9yUHJlY2lzZVRhZzxRLCBcImltZ1wiPixcbiAgICBjaGlsZHJlbj86IENoaWxkcmVuT2JqXG59KTogSW1nO1xuZXhwb3J0IGZ1bmN0aW9uIGltZyh7IGh0bWxFbGVtZW50LCBjaGlsZHJlbiB9OiB7XG4gICAgaHRtbEVsZW1lbnQ6IEhUTUxJbWFnZUVsZW1lbnQ7XG4gICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IEltZztcbmV4cG9ydCBmdW5jdGlvbiBpbWcoKTogSW1nXG5leHBvcnQgZnVuY3Rpb24gaW1nKGltZ09wdHM/KTogSW1nIHtcbiAgICBpZiAoIWJvb2woaW1nT3B0cykpIHtcbiAgICAgICAgaW1nT3B0cyA9IHt9XG4gICAgfVxuICAgIHJldHVybiBuZXcgSW1nKGltZ09wdHMpXG59XG5cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcmFncmFwaCh7IGNscywgc2V0aWQsIHRleHQgfTogeyBjbHM/OiBzdHJpbmcsIHNldGlkPzogc3RyaW5nLCB0ZXh0Pzogc3RyaW5nIH0pOiBQYXJhZ3JhcGg7XG5leHBvcnQgZnVuY3Rpb24gcGFyYWdyYXBoKHsgY2xzLCBzZXRpZCwgaHRtbCB9OiB7IGNscz86IHN0cmluZywgc2V0aWQ/OiBzdHJpbmcsIGh0bWw/OiBzdHJpbmcgfSk6IFBhcmFncmFwaDtcbmV4cG9ydCBmdW5jdGlvbiBwYXJhZ3JhcGgoeyBieWlkLCBjaGlsZHJlbiB9OiB7IGJ5aWQ6IHN0cmluZywgY2hpbGRyZW4/OiBDaGlsZHJlbk9iaiB9KTogUGFyYWdyYXBoO1xuZXhwb3J0IGZ1bmN0aW9uIHBhcmFncmFwaDxRIGV4dGVuZHMgUXVlcnlTZWxlY3Rvcj4oeyBxdWVyeSwgY2hpbGRyZW4gfToge1xuICAgIHF1ZXJ5OiBRdWVyeU9yUHJlY2lzZVRhZzxRLCBcInBcIj4sXG4gICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IFBhcmFncmFwaDtcbmV4cG9ydCBmdW5jdGlvbiBwYXJhZ3JhcGgoeyBodG1sRWxlbWVudCwgY2hpbGRyZW4gfToge1xuICAgIGh0bWxFbGVtZW50OiBIVE1MUGFyYWdyYXBoRWxlbWVudDtcbiAgICBjaGlsZHJlbj86IENoaWxkcmVuT2JqXG59KTogUGFyYWdyYXBoO1xuZXhwb3J0IGZ1bmN0aW9uIHBhcmFncmFwaCgpOiBQYXJhZ3JhcGhcbmV4cG9ydCBmdW5jdGlvbiBwYXJhZ3JhcGgocE9wdHM/KTogUGFyYWdyYXBoIHtcbiAgICBpZiAoIWJvb2wocE9wdHMpKSB7XG4gICAgICAgIHBPcHRzID0ge31cbiAgICB9XG4gICAgcmV0dXJuIG5ldyBQYXJhZ3JhcGgocE9wdHMpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhbmNob3IoeyBjbHMsIHNldGlkLCBocmVmLCB0YXJnZXQsIHRleHQgfToge1xuICAgIGNscz86IHN0cmluZyxcbiAgICBzZXRpZD86IHN0cmluZyxcbiAgICBocmVmPzogc3RyaW5nXG4gICAgdGFyZ2V0Pzogc3RyaW5nLFxuICAgIHRleHQ/OiBzdHJpbmcsXG59KTogQW5jaG9yO1xuZXhwb3J0IGZ1bmN0aW9uIGFuY2hvcih7IGNscywgc2V0aWQsIGhyZWYsIHRhcmdldCwgaHRtbCB9OiB7XG4gICAgY2xzPzogc3RyaW5nLFxuICAgIHNldGlkPzogc3RyaW5nLFxuICAgIGhyZWY/OiBzdHJpbmdcbiAgICB0YXJnZXQ/OiBzdHJpbmcsXG4gICAgaHRtbD86IHN0cmluZyxcbn0pOiBBbmNob3I7XG5leHBvcnQgZnVuY3Rpb24gYW5jaG9yKHsgYnlpZCwgY2hpbGRyZW4gfToge1xuICAgIGJ5aWQ6IHN0cmluZywgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IEFuY2hvcjtcbmV4cG9ydCBmdW5jdGlvbiBhbmNob3I8USBleHRlbmRzIFF1ZXJ5U2VsZWN0b3I+KHsgcXVlcnksIGNoaWxkcmVuIH06IHtcbiAgICBxdWVyeTogUXVlcnlPclByZWNpc2VUYWc8USwgXCJhXCI+LFxuICAgIGNoaWxkcmVuPzogQ2hpbGRyZW5PYmpcbn0pOiBBbmNob3I7XG5leHBvcnQgZnVuY3Rpb24gYW5jaG9yKHsgaHRtbEVsZW1lbnQsIGNoaWxkcmVuIH06IHtcbiAgICBodG1sRWxlbWVudDogSFRNTEFuY2hvckVsZW1lbnQ7XG4gICAgY2hpbGRyZW4/OiBDaGlsZHJlbk9ialxufSk6IEFuY2hvcjtcbmV4cG9ydCBmdW5jdGlvbiBhbmNob3IoKTogQW5jaG9yXG5leHBvcnQgZnVuY3Rpb24gYW5jaG9yKGFuY2hvck9wdHM/KTogQW5jaG9yIHtcbiAgICBpZiAoIWJvb2woYW5jaG9yT3B0cykpIHtcbiAgICAgICAgYW5jaG9yT3B0cyA9IHt9XG4gICAgfVxuICAgIHJldHVybiBuZXcgQW5jaG9yKGFuY2hvck9wdHMpXG59XG5cblxuXG4iXX0=