/*
 import { str } from "../str";
 
 class List<T> extends Array<T> {
 last(): T {
 return this[this.length - 1];
 }
 
 lowerAll() {
 return this.map(s => str(s).lower());
 }
 }
 */
